import boto3
import json
import os
# import jwt
import uuid
import traceback
import logging
import time
import botocore.exceptions
from botocore.exceptions import EventStreamError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

bedrock = boto3.client('bedrock-runtime')
bedagent = boto3.client('bedrock-agent-runtime',region_name='us-east-1')
dynamodb = boto3.resource('dynamodb')
ssm_client=boto3.client('ssm')
ddb_users_table= dynamodb.Table(os.environ.get('USERS_TABLE_NAME'))

userpool_clientid=os.environ.get('USER_POOL_CLIENT')
api_endpoint=os.environ.get('API_ENDPOINT_URL')
comprehend = boto3.client('comprehend')
agent_id = os.environ.get('AGENT_ID')
agent_alias_id = os.environ.get('AGENT_ALIAS_ID')
agent_id_=ssm_client.get_parameter(Name=agent_id)['Parameter']['Value']
agent_alias_id_=ssm_client.get_parameter(Name=agent_alias_id)['Parameter']['Value']
agent_alias_id_=agent_alias_id_.split('|')[-1]
api_endpoint= ssm_client.get_parameter(Name=api_endpoint)['Parameter']['Value']
api_client = boto3.client(
    'apigatewaymanagementapi',
    endpoint_url=api_endpoint
)


# def ui_guide(event):
#     ui_description = ""
#     prompt= json.loads(event["body"])
#     system_prompt = f"You are an assistant guiding users on how to use this application asset tracker. Explain what each UI option does in simple terms based on {ui_description}. Based on the user's prompt, determine where does user needs help and help him/her."

#     user_prompt = prompt

#     payload = json.dumps({
#     'prompt':  f"{system_prompt}, following is the user prompt: , {user_prompt}",
#     'max_tokens_to_sample': 4000
#     })

#     response = bedrock.invoke_model(
#         modelId="anthropic.claude-3-5-sonnet-20240620-v1:0",  
#         contentType="application/json",
#         accept="application/json",
#         body= payload
#     )

#     response_body = json.loads(response['body'].read()) 

#     return {
#         "statusCode": 200,
#         "body": json.dumps({
#             "message": "guide for users on how to use the application:",
#             "guide": response_body.get("completion") or response_body.get("generation") 
#         })
#     }

# def ui_management(event):
#     print(event)
#     bedruntime_agent = boto3.client('bedrock-agent-runtime')
#     bedagent = boto3.client('bedrock-agent')
#     KBID= '6HJ9I0DRSV'
#     raw_body = event.get('body', '{}')
#     body_dict = json.loads(raw_body)
#     p1 = body_dict.get("prompt")
#     p2 = "Go through contents of each json record thoroughly and completely.It is really important that you do analysis completely. and fetch the results accurately based on the given prompt: "
#     p= p2 + p1 
#     res= " "
#     if event['httpMethod'] == 'POST':
#         print("prompt testing :", p)
#         try:
#             res=bedruntime_agent.retrieve_and_generate(
#                     input={
#                         "text": p
#                     },
#                     retrieveAndGenerateConfiguration={
#                             'type': 'KNOWLEDGE_BASE',
#                             'knowledgeBaseConfiguration': {
#                                 'knowledgeBaseId': KBID,
#                                 'modelArn': 'arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-sonnet-20240620-v1:0'
#                             }
#                     }
#                     )
#             print(res)
#             return {
#                 'statusCode': 200,
#                 'body': json.dumps(res.get("output"))
#             }
#         except Exception as e:
#             return {
#                 'statusCode': 500,
#                 'body': json.dumps({'error': str(e)})
#             }

#     return {
#         'statusCode': 400,
#         'body': json.dumps('Invalid request')
#     }


# def mask_pii_for_agent(input_text):
#     print("masking the PIIs")
#     response = comprehend.detect_pii_entities(Text=input_text, LanguageCode='en')
#     redacted_text = input_text
#     pii_map = []
#     print(response)
#     for entity in sorted(response.get("Entities", []), key=lambda e: e["BeginOffset"], reverse=True):
#         start, end = entity["BeginOffset"], entity["EndOffset"]
#         if entity['Type'] in ['DATE','TIME','DATE_TIME']:
#             continue
#         print("entity type:", entity['Type'])
#         placeholder = f"<PII_{entity['Type']}_{len(pii_map)}>"
#         pii_map.append({"placeholder": placeholder, "value": redacted_text[start:end]})
#         redacted_text = redacted_text[:start] + placeholder + redacted_text[end:]

#     print("redacted text:", redacted_text)
#     return redacted_text, pii_map

def mask_pii_for_agent(input_text):
    print("masking the PIIs")
    response = comprehend.detect_pii_entities(Text=input_text, LanguageCode='en')
    redacted_text = input_text
    pii_map = {}
    print(response)
    
    for idx, entity in enumerate(sorted(response.get("Entities", []), key=lambda e: e["BeginOffset"], reverse=True)):
    # for entity in sorted(response.get("Entities", []), key=lambda e: e["BeginOffset"], reverse=True):
        start, end = entity["BeginOffset"], entity["EndOffset"]
        if entity['Type'] in ['DATE', 'TIME', 'DATE_TIME', 'URL', 'CREDIT_DEBIT_EXPIRY', 'MAC_ADDRESS']:
            continue
        print("entity type:", entity['Type'])
        
        placeholder = f"<PII_{entity['Type']}_{idx}>"
        original_value = redacted_text[start:end]
        pii_map[placeholder] = original_value
        redacted_text = redacted_text[:start] + placeholder + redacted_text[end:]
    print("redacted text:", redacted_text)
    return redacted_text, pii_map

def restore_pii(text, pii_map):
    if not isinstance(text, str):
        print("not a string so cannot restore")
        return text  
    for placeholder, real_value in pii_map.items():
        print(f"replacing {placeholder} with {real_value}" )
        text = text.replace(placeholder, real_value)
        print(f"replaced {placeholder} with {real_value}" )
    return text


# def jwt_decode(token):
#     try:
#         decoded = jwt.decode(token, options={"verify_signature": False})
#         print(decoded)
#         if decoded.get('aud') != userpool_clientid or decoded.get('exp', 0) < time.time():
#             return None
#         return {
#             'username': decoded.get('cognito:username'),
#             'email': decoded.get('email'),
#             'role': decoded.get('custom:role'),
#             'exp': decoded.get('exp')
#         }
#     except Exception as e:
#         logger.error(f"JWT decode failed: {str(e)}")
#         raise Exception("Error",str(e))
        
def agent_analysis(event, user_details,session_id):
    body= json.loads(event.get('body', '{}'))
    connection_id = event['requestContext']['connectionId']
    print(connection_id)
    print(session_id)
    try:
        prompt = body.get('prompt', None)
        print(prompt)
        print(f"invoking agent")
        print("detecting PIIs in prompt...")
        redacted_prompt, pii_map = mask_pii_for_agent(prompt)
        print("prompt after redacting pii:", redacted_prompt)
        print("pii map:", pii_map)
        try:
            response_stream = bedagent.invoke_agent(
                agentAliasId=agent_alias_id_,
                agentId=agent_id_,
                bedrockModelConfigurations={
                    'performanceConfig': {
                        'latency': 'standard'
                    }
                },
                enableTrace=True,
                endSession=False,
                inputText=redacted_prompt,
                sessionId=session_id,
                sessionState={
                    "sessionAttributes": {
                        "user_details": json.dumps(user_details),
                        "original_pii": json.dumps(pii_map)
                    }
                }
            )
            print(response_stream)
            full_response = ""
            i=0
            try:
                for event in response_stream.get("completion"):
                    print(event)
                    if "chunk" in event:
                        data = event["chunk"]["bytes"].decode("utf-8")
                        data = data.replace('\n', "")
                        full_response += data
            except botocore.exceptions.EventStreamError as e:
                print(f"EventStreamError while reading completion: {e}")
                # Handle or retry accordingly
                raise

            #         api_client.post_to_connection(ConnectionId=connection_id, Data=data)

            # api_client.post_to_connection(ConnectionId=connection_id, Data="Do you want anything else?")
            print(full_response)
            full_response = full_response.replace("```", "")
            completed_response=""
            for i in range(0, len(full_response)):
                completed_response+= full_response[i]
            print("Type:", type(full_response))
            print("full_resp: ",completed_response)
            pii_maps_ssm= os.environ.get('PII_MAPS')
            ssm_pii=ssm_client.get_parameter(Name=pii_maps_ssm)['Parameter']['Value']
            pii_map2=json.loads(ssm_pii)
            restored_response=restore_pii(completed_response, pii_map2)
            print("restored response with pii_map2:", restored_response)
            restored_response= restore_pii(restored_response, pii_map)
            print("restored response with pii_map:", restored_response)
            api_client.post_to_connection(ConnectionId=connection_id, Data=restored_response)

            api_client.post_to_connection(ConnectionId=connection_id, Data="Do you want anything else?")
            return {
                "statusCode": 200,
                "body": json.dumps({
                    "message": restored_response
                })
            }
        except Exception as e:
            traceback.print_exc()
            print(e)
            api_client.post_to_connection(ConnectionId=connection_id, Data=f"Error: {str(e)}")
            return {
                "statusCode": 500,
                "body": json.dumps({
                    "message": "Error during agent invocation",
                    "error": str(e)
                })
            }
    except Exception as e:
        traceback.print_exc()
        print(e)
        api_client.post_to_connection(ConnectionId=connection_id, Data=f"Error: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error during agent invocation",
                "error": str(e)
            })
        }


# def lambda_handler(event, context):
#     print("Received event:", event)

#     print("Processing new request")
#     token_details=event['requestContext']['authorizer']['claims']
#     user_details={
#         'username': token_details.get('cognito:username'),
#         'role': token_details.get('custom:role', 'unknown'),
#         'email': token_details.get('email', 'unknown')
#     }
#     print(f"Request from user {user_details['username']} with role {user_details['role']}")
#     print(agent_alias_id_)

#     http_method = event['httpMethod']
#     path = event['path']    

#     response=ddb_users_table.get_item(Key={'UserName': user_details['username']},ProjectionExpression='RoleName').get('Item')
#     print(response)
#     if response == None:
#         return {
#             "statusCode": 404,
#             "body": json.dumps({"message": "Accessing user is not found"})
#         }

#     user_details['role']=response.get('RoleName')  
#     if http_method == 'POST' and path == '/chat':
#         query_params = event.get('queryStringParameters', {})
#         action = query_params.get('action')
#         try:
#             body = json.loads(event.get('body') or '{}')
#             if action == 'analysis':
#                 return agent_analysis(event, user_details)
#             elif action == 'user-management':
#                 return ui_management(event)
#             else:
#                 return {
#                     "statusCode": 400,
#                     "body": json.dumps({"message": "Invalid action"})
#                 }
#         except Exception as e:
#             traceback.print_exc()
#             return {
#                 "statusCode": 500,
#                 "body": json.dumps({"message": "Error during agent invocation", "error": str(e)})
#             }
#     return {
#         "statusCode": 404,
#         "body": json.dumps({"message": "Unsupported path or method"})
#     }


def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    route_key = event.get('requestContext', {}).get('routeKey')
    connection_id = event['requestContext']['connectionId']

    if route_key == '$connect':
        # auth_header = event.get('headers', {}).get('Authorization')
        # if not auth_header or not auth_header.startswith('Bearer '):
        #     return {"statusCode": 401, "body": json.dumps({"message": "Unauthorized"})}
        # print(auth_header)
        # user_details = jwt_decode(auth_header.split(" ")[1])
        # print(user_details)
        # if not user_details:
        #     return {"statusCode": 403, "body": json.dumps({"message": "Invalid or expired token."})}
        # session_id = str(uuid.uuid4())
        # try:
        #     ddb_connections_table.put_item(Item={
        #         'UserName': user_details['username'],
        #         'RoleName': user_details['role'],
        #         'Email': user_details['email'],
        #         'ExpirationTime': user_details['exp'],
        #         'ConnectionId': connection_id,
        #         'Sessionid': session_id
        #     })
        #     logger.info(f"User {user_details['username']} connected with connectionId {connection_id}")
        return {"statusCode": 200, "body": json.dumps({"message": "Connected"})}
        # except Exception as e:
        #     logger.exception("Error saving connection to DynamoDB")
        #     return {"statusCode": 500, "body": json.dumps({"message": "Failed to store connection."})}

    elif route_key == 'analysis':
        try:
            item=event['requestContext']['authorizer']

            user_details = {
                'username': item['username'],
                'role': item['role'],
                'email': item['email']
            }
            print(user_details)
            response = ddb_users_table.get_item(Key={'UserName': user_details['username']}, ProjectionExpression='RoleName,UserStatus').get('Item')
            print(response)
            if response == None or response.get('UserStatus')=='Inactive':
                api_client.post_to_connection(ConnectionId=connection_id, Data="Unauthorized:Accessing User not found.")
                return
            session_id = connection_id[:-1]
            return agent_analysis(event, user_details,session_id)

        except Exception as e:
            logger.exception("Error during analysis route")
            api_client.post_to_connection(ConnectionId=connection_id, Data=f"Error: {str(e)}")

    elif route_key == '$disconnect':
        # try:
        #     ddb_connections_table.delete_item(Key={'ConnectionId': connection_id})
        #     logger.info(f"Disconnected: {connection_id}")
        return {"statusCode": 200, "body": json.dumps({"message": "Disconnected"})}
        # except Exception as e:
        #     logger.exception("Error on disconnect")
