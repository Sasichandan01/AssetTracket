import os
import json
import logging
import boto3

# import methods from util files


# initialize logging
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

# initialize cognito client
cognito_client = boto3.client("cognito-idp")


def generate_policy(principal_id, effect, resource, context=None):
    """function to generate an IAM policy document to control access to the API Gateway endpoint
        Args: 
            principal_id (str) : The user id of the user
            effect (str) : The effect of the policy it can be Allow or Deny
            resource (str) : The arn of the api gateway method
            context (dict) : Key value pair of the user attributes
        Returns:
            dict : A dictionary containing the principal id, policy document and context
    """
    return {
        "principalId": principal_id,
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [{
                "Action": "execute-api:Invoke",
                "Effect": effect,
                "Resource": resource
            }]
        },
        "context": context or {}
    }

def lambda_handler(event, context):
    """This function is the entry point for the lambda function
        Args:
            event (dict) : A dictionary containing the event data
            context (LambdaContext): The context in which the Lambda function is run.
        Returns:
            dict : A dictionary containing the Status code and Message
    """
    try:
        LOGGER.info(f"Event received: {event}")
        # extract the headers from the event
        headers = event.get("headers", {})
        # extract the authorization header from the headers
        auth_header = headers.get("Authorization", "")
        # extract the method arn from the event
        method_arn = event.get("methodArn", "*")
        # if the method arn is not found deny the request
        if not method_arn:
            LOGGER.error("Missing methodArn in event")
            return generate_policy("unauthorized", "Deny", "*")
        # if the authorization header is not a bearer token deny the request
        if not auth_header.startswith("Bearer "):
            LOGGER.warning("Authorization header is missing")
            return generate_policy("unauthorized", "Deny", method_arn)
        # if the authorization header is a guest token allow the request
        if auth_header.strip() == "Bearer guest":
            LOGGER.info("Guest token detected.")
            return generate_policy("guest", "Allow", method_arn, {"role": "guest"})

        # extract the access token from the authorization header
        access_token = auth_header.split(" ")[1]
        # get the user details from cognito
        user = cognito_client.get_user(AccessToken=access_token)
        print(user)
        UserName=user.get('Username')
        userAttributes=user.get('UserAttributes')
        email=""
        role=""
        for list in userAttributes:
            if list.get('Name')=='email':
                email=list.get('Value')
            if list.get('Name')=='custom:role':
                role=list.get('Value')

        return generate_policy(UserName, "Allow", method_arn, {
            'username': UserName,
            'email': email,
            'role': role
        })
    except Exception as e:
        LOGGER.exception(f"Unhandled exception: {e}")
        return generate_policy("unauthorized", "Deny", method_arn)