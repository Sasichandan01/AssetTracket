import json
import boto3
import datetime
import os
import logging


logger = logging.getLogger()
logger.setLevel(logging.INFO)

cognito_client = boto3.client('cognito-idp')
ssm_client = boto3.client('ssm')
dynamodb_resource = boto3.resource('dynamodb')
ses_client=boto3.client('ses')
user_pool_id = os.environ['USER_POOL_ID']
users_table = os.environ['USERS_TABLE_NAME']
ssm_flag_name = os.environ['MANAGER_FLAG']
dynamodb_table = dynamodb_resource.Table(users_table)
user_pool=ssm_client.get_parameter(Name=user_pool_id)['Parameter']['Value']

def post_confirmation(event, context):
    print(event)
    """
    Handles the PostConfirmation Cognito trigger by assigning a role to the user,
    updating Cognito custom attributes, and inserting the user into DynamoDB.

    Args:
        event (dict): The event payload from Cognito.
        context (LambdaContext): The runtime information provided by AWS Lambda.

    Returns:
        dict: The unchanged event dictionary.
    """
    logger.info("Entered post_confirmation trigger.")
    manager_flag = ssm_client.get_parameter(Name=ssm_flag_name)['Parameter']['Value']
    logger.info(f'Manager flag value retrieved from SSM: {manager_flag}')
    try:
        username = event['userName']
        user_attributes = event['request']['userAttributes']
        email = user_attributes.get('email', '')
        phone = user_attributes.get('phone_number', '')
        name = user_attributes.get('name', '')
        logger.info(f"Processing user: {username}, Email: {email}, Name: {name}")

        role = 'Manager' if manager_flag == '0' else 'User'
        logger.info(f"Assigned role: {role} based on manager_flag = {manager_flag}")

        timestamp = str((datetime.datetime.now() + datetime.timedelta(hours=5, minutes=30)).strftime("%Y-%m-%d %H:%M:%S.%f"))
        logger.info(f"Generated timestamp: {timestamp}")

        logger.info("Updating Cognito custom:role attribute.")
        cognito_client.admin_update_user_attributes(
            UserPoolId=user_pool,
            Username=username,
            UserAttributes=[{'Name': 'custom:role', 'Value': role}]
        )

        logger.info("Inserting user record into DynamoDB.")
        dynamodb_table.put_item(
            Item={
                'UserName': username,
                'Name': name,
                'RoleName': role,
                'Email': email,
                'Phone': phone,
                'CreatedBy': username,
                'CreatedAt': timestamp,
                'LastModifiedBy': username,
                'LastModifiedAt': timestamp,
                'ConfirmationStatus': "confirmed",
                'UserType':'Employee',
                'UserStatus':'Active',
                'Groups': []
            }
        )
        response=ses_client.verify_email_identity(
            EmailAddress=email
        )
        if manager_flag == '0':
            logger.info("First manager detected. Updating SSM flag to 1.")
            ssm_client.put_parameter(Name=ssm_flag_name, Value='1', Type='String', Overwrite=True)
        logger.info("post_confirmation completed successfully.")
        return event

    except Exception as e:
        logger.error(f"PostConfirmation error: {str(e)}")
        raise e

def pre_signup(event, context):
    """
    Handles the PreSignUp Cognito trigger by checking if a user with the same email already exists.

    Args:
        event (dict): The event payload from Cognito.
        context (LambdaContext): The runtime information provided by AWS Lambda.

    Returns:
        dict: The unchanged event dictionary.
    """
    logger.info(f"Entered pre_signup trigger.",event)
    print(event)
    
    email = event['request']['userAttributes']['email']
    username=event['userName']
    if not email.endswith('@cloudwick.com'):
        logger.info("Email does not end with @cloudwick.com. Skipping pre_signup.")
        raise Exception("Only cloudwick.com emails are allowed.")

    response=dynamodb_table.get_item(Key={'UserName': username},ProjectionExpression='UserStatus')
    print(response)
    if response.get('Item'):
        raise Exception('UserName already exists in the system')
    logger.info(f"Checking if user already exists with email: {email}")
    response=dynamodb_table.query(
        IndexName='Email-index',
        KeyConditionExpression='Email=:email',
        ExpressionAttributeValues={':email': email}
    )
    if response.get('Items'):
        logger.info("User already exists with the given email.")
        raise Exception("Email already exists in the system")
    else:
        logger.info("No user found with the given email.")
    return event

def post_authentication(event, context):
    """
    Handles the PostAuthentication Cognito trigger by updating the confirmation status
    and last modified timestamp in DynamoDB.

    Args:
        event (dict): The event payload from Cognito.
        context (LambdaContext): The runtime information provided by AWS Lambda.

    Returns:
        dict: The unchanged event dictionary.
    """
    logger.info("Entered post_authentication trigger.")
    try:
        logger.info(f"Received event: {event}")
        username = event['userName']
        role = event['request']['userAttributes']['custom:role']
        logger.info(f"Authenticating user: {username}, Role: {role}")

        timestamp = str((datetime.datetime.utcnow() + datetime.timedelta(hours=5, minutes=30)).strftime("%Y-%m-%d %H:%M:%S.%f"))
        logger.info(f"Generated update timestamp: {timestamp}")

        response = dynamodb_table.get_item(
            Key={'UserName': username},
            ProjectionExpression='ConfirmationStatus'
        ).get('Item', {})
        logger.info(f"DynamoDB fetch result: {response}")

        if response and response.get('ConfirmationStatus') == 'confirmed':
            logger.info("User already confirmed. Skipping update.")
            return event

        logger.info("Updating ConfirmationStatus in DynamoDB.")
        dynamodb_table.update_item(
            Key={'UserName': username},
            UpdateExpression="""
                SET ConfirmationStatus = :status,
                    LastModifiedBy = :modified_by,
                    LastModifiedAt = :modified_time
            """,
            ExpressionAttributeValues={
                ':status': 'confirmed',
                ':modified_by': username,
                ':modified_time': timestamp
            }
        )
        response=ses_client.verify_email_identity(
            EmailAddress=event['request']['userAttributes']['email']
        )
        logger.info("DynamoDB update successful.")
        return event
    except Exception as e:
        logger.error(f"PostAuthentication error: {str(e)}")
        raise e

def lambda_handler(event, context):
    """
    Main Lambda entry point for handling different Cognito triggers and routing to the appropriate function.

    Args:
        event (dict): The event payload from Cognito.
        context (LambdaContext): The runtime information provided by AWS Lambda.

    Returns:
        dict: The result of the invoked trigger function or the unchanged event.
    """
    logger.info(f"Lambda invoked with triggerSource: {event.get('triggerSource')}")
    try:
        trigger = event['triggerSource']
        if trigger == 'PreSignUp_SignUp':
            logger.info("Routing to pre_signup handler.")
            return pre_signup(event, context)
        elif trigger == 'PostConfirmation_ConfirmSignUp':
            logger.info("Routing to post_confirmation handler.")
            return post_confirmation(event, context)
        elif trigger == 'PostAuthentication_Authentication':
            logger.info("Routing to post_authentication handler.")
            return post_authentication(event, context)
      
        logger.warning("Unrecognized trigger source. Returning event as-is.")
        return event
    except Exception as e:
        logger.error(f"Lambda handler error: {str(e)}")
        raise e

