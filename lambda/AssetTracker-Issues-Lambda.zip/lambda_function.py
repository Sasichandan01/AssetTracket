import json
import boto3
import os
import uuid
import datetime
import logging
from botocore.config import Config


logger = logging.getLogger()
logger.setLevel(logging.INFO)

assets_table_name=os.environ['ASSETS_TABLE_NAME']
groups_table_name=os.environ['GROUPS_TABLE_NAME']
issues_table_name=os.environ['ISSUES_TABLE_NAME']
users_table_name=os.environ['USERS_TABLE_NAME']
assigned_table_name=os.environ['ASSIGNMENT_TABLE_NAME']
bucket_name=os.environ['S3_FILES_BUCKET']


dynamodb = boto3.resource('dynamodb')
assets_table = dynamodb.Table(assets_table_name)
groups_table = dynamodb.Table(groups_table_name)
issues_table = dynamodb.Table(issues_table_name)
users_table = dynamodb.Table(users_table_name)
assigned_table = dynamodb.Table(assigned_table_name)

ses_client=boto3.client('ses')
s3_client = boto3.client('s3')

def generate_presigned_url(bucket_name, object_key, item=None, operation='get_object', expiration=3600):
    """
    Generates a pre-signed URL for the given object in the specified S3 bucket.

    Args:
        bucket_name (str): The name of the S3 bucket.
        object_key (str): The key (path) of the object within the bucket.
        item (dict, optional): Metadata for PUT operations. Defaults to None.
        operation (str, optional): The S3 operation to perform ('get_object' or 'put_object'). Defaults to 'get_object'.
        expiration (int, optional): The expiration time in seconds for the pre-signed URL. Defaults to 3600.

    Returns:
        str: The pre-signed URL for the object.
    """
    try:
        params = {
            'Bucket': bucket_name,
            'Key': object_key
        }
        
        if operation == 'put_object' and item:
            item['ContentType'] = 'application/zip'
            params['Metadata'] = item
            
        response = s3_client.generate_presigned_url(
            ClientMethod=operation,
            Params=params,
            ExpiresIn=expiration
        )
        return response
    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }


def get_all_issues(user_details):
    """
    Fetch all issues from the system

    Retrieves all issues stored in DynamoDB. Available to Admin and Manager roles only.
    Regular Users receive a 403 Forbidden response.

    Args:
        user_details (dict): User details containing role and username

    Returns:
        dict: API Gateway response object with:
            - statusCode (int): HTTP status code
            - body (str): JSON string of issues or error message

    Raises:
        Exception: Captures any unexpected errors and returns 500 status
    """
    try:
        if user_details.get('role') in ['Admin','Manager']:
            logger.info(f"User role is: {user_details.get('role')}")
            response=issues_table.scan()
            logger.info(f"Items: {(response.get('Items', []))}")
            output_items=response.get('Items',[])
            if output_items==[]:
                return {
                    'statusCode':200,
                    'body':'No issues exist in the system'
                }
            output=[]
            for item in output_items:
                output.append({
                    "IssueId":item.get('IssueId'),
                    "AssetId":item.get('AssetId'),
                    "IssueDescription":item.get("IssueDescription"),
                    "IssueStatus":item.get("IssueStatus","Missing"),
                    "Notes":item.get("Notes","None")
                })
            return {
                'statusCode': 200,
                'body': json.dumps(output)
            }
        elif user_details.get('role')=='User':
            logger.warning(f"Unauthorized access attempt by user: {user_details.get('username')} ")
            return {
                'statusCode': 403,
                'body': json.dumps("Not authorized to view all issues!!")
            }
        else:
            logger.warning(f"Unauthorized access attempt:{user_details.get('role')}")
            return {
                'statusCode': 403,
                'body': json.dumps("Not authorized to view all issues!!")
            }
    except Exception as e:
        logger.error(f"Error in get_all_issues function: {str(e)} ")
        return {
            'statusCode':500,
            'body': f'{str(e)}'
        }
    

def get_issue_status(event,user_details):
    """
    Retrieve issues by status

    Gets issues filtered by their status. Admins/Managers get all issues with the status,
    Users only get their own issues with the specified status.

    Args:
        event (dict): Lambda event containing query parameters
        user_details (dict): Authenticated user details

    Returns:
        dict: Response object with filtered issues or error message
    """
    status=event.get('queryStringParameters').get('status')
    logger.info(f"Status is: {status}")    
    try:
        if user_details.get('role')in ['Admin','Manager']:
            response=issues_table.query(
                IndexName="IssueStatus-CreatedBy-index",
                KeyConditionExpression="IssueStatus = :status",
                ExpressionAttributeValues={
                    ":status": status
                    }
                )
            logger.info(f"Admin Response is: {response}")
        elif user_details.get('role')=='User':
            response=issues_table.query(
                IndexName="IssueStatus-CreatedBy-index",
                KeyConditionExpression="IssueStatus = :status AND CreatedBy = :raised",
                ExpressionAttributeValues={
                    ":raised": user_details.get('username'),
                    ":status": status
                    }
                )
            logger.info(f"User response is: {response}")
        else:
            logger.warning(f"Not authorized to view all issues!!")
            return {
                'statusCode':403,
                'body':json.dumps("Not authorized to view all issues!!")
            }
        output_items=response.get('Items',[])
        if output_items==[]:
            return {
                'statusCode':200,
                'body':'No issues exist in the system'
            }
        output=[]
        for item in output_items:
            output.append({
                "IssueId":item.get('IssueId'),
                "AssetId":item.get('AssetId'),
                "IssueDescription":item.get("IssueDescription"),
                "Notes":item.get("Notes","None")
            })
        return {
            'statusCode': 200,
            'body': json.dumps(output)
        }
    except Exception as e:
        logger.error(f"Error in get_issue_status function: {str(e)} ")
        print("Error: ",str(e))
        return {
            'statusCode':500,
            'body':json.dumps(str(e))
        }
    

def get_delete_status(event,user_details):
    """
    Retrieve issues with delete requests

    Fetches issues that have delete requests pending. Admins/Managers see all requests,
    Users only see their own delete requests.

    Args:
        event (dict): Lambda event object
        user_details (dict): Authenticated user details

    Returns:
        dict: Response with delete requested issues or error
    """
    try:
        if user_details.get('role')=='Admin' or user_details.get('role')=='Manager':
            response=issues_table.query(
                IndexName="DeleteRequest-CreatedBy-index",
                KeyConditionExpression="DeleteRequest = :delete_request",
                ExpressionAttributeValues={
                    ":delete_request": "True"
                    }
                )
            logger.info(f"Admin Response is: {response}")
        elif user_details.get('role')=='User':
            response=issues_table.query(
                IndexName="DeleteRequest-CreatedBy-index",
                KeyConditionExpression="DeleteRequest = :delete_request AND CreatedBy = :raised_by",
                ExpressionAttributeValues={
                    ":delete_request": "True",
                    ":raised_by": user_details.get('username')
                    }
                )
            logger.info(f"User Response is: {response}")
        else:
            logger.warning("Not authorized to get delete status of issues!!")
            return{
                'statusCode':403,
                'body':json.dumps("Not authorized to get delete status of issues!!")
            }
        output_items=response.get('Items',[])
        if output_items==[]:
            return {
                'statusCode':200,
                'body':'No issues exist in the system'
            }
        output=[]
        for item in output_items:
            output.append({
                "IssueId":item.get('IssueId'),
                "AssetId":item.get('AssetId'),
                "IssueDescription":item.get("IssueDescription"),
                "Notes":item.get("Notes","None")
            })
        return {
            'statusCode': 200,
            'body': json.dumps(output)
        }
        
    except Exception as e:
        logger.error("Error in get_delete_status function")
        return {
            'statusCode':500,
            'body':json.dumps(str(e))
        }

    
def add_issue(event,user_details,sender_email,admin_emails):
    """
    Create a new issue entry

    Handles issue creation with validation for asset ownership and assignment status.
    Sends notifications to admins via SNS when new issues are created.

    Args:
        event (dict): Lambda event containing issue details
        user_details (dict): Authenticated user information

    Returns:
        dict: Creation result with issue data or error messages
    """
    #if the asset is assigned admin or manager wont be able to add an issue to it, but if unassigned then can raise an issue 
    logger.info(f"body: {event.get('body')}")
    body=json.loads(event.get('body'))
    asset_id=body.get('AssetId')
    logger.info(f"Asset id is: {asset_id}")
    asset_response = assets_table.get_item(
        Key={
            'AssetId': asset_id
        }
    )
    logger.info(f"Asset response is: {asset_response.get('Item')}")
    if asset_response.get('Item')==None:
        logger.info("No asset with that asset id")
        return {
            'statusCode':200,
            'body':'No asset with that asset-id'
        }

    asset_status=asset_response['Item']['AssetStatus']
    user_name=user_details.get('username')
    users_asset=False

    # If asset is unassigned, only allow admins/managers to create issues
    if asset_status=='Unassigned' or asset_status=='Missing':
        if user_details['role'] in ['Admin', 'Manager']:
            users_asset=True
            logger.info("Admin/Manager can add issue to unassigned or missing assets")
        else:
            logger.warning("Users cannot add an issue to an unassigned asset")
            return {
                'statusCode': 200,
                'body': 'Users cannot add an issue to an unassigned/missing asset. Only admins and managers can.'
            }
    else:
        # Only check assigned table if asset is not unassigned
        response = assigned_table.query(
            IndexName="AssetId-index",
            KeyConditionExpression="AssetId = :asset_id",
            FilterExpression="AssignedStatus=:status",
            ExpressionAttributeValues={
                ":asset_id": asset_id,
                ":status": "Active"
            }
        )
        logger.info(f"assigned table query response:{response}")

        items = response.get('Items', [])
        if items:
            first_item = items[0]
            # If assigned to a group
            if first_item.get('HolderId', '').startswith('GRP_'):
                logger.info("asset is assigned to a group")
                group_id = first_item.get('HolderId')
                
                # Get user's groups from users table
                user_response = users_table.get_item(
                    Key={
                        'UserName': user_name
                    },
                    ProjectionExpression='Groups'
                )
                
                user_groups = user_response.get('Item', {}).get('Groups', [])
                logger.info(f"User groups: {user_groups}")
                
                if group_id in user_groups:
                    logger.info("user is a member of the group")
                    users_asset = True
                else:
                    logger.warning("User is not a group member and is unauthorized")
                    return {
                        'statusCode': 200,
                        'body': json.dumps({
                            'message': 'User is not a member of the group. Not Authorized to add an issue for this asset'
                        })
                    }
            # If assigned to individual users
            else:
                for item in items:
                    if item.get('HolderId') == user_name:
                        users_asset = True
                        break

            if not users_asset:
                logger.warning("Asset is not assigned to the requester.")
                return {
                    'statusCode': 200,
                    'body': 'Asset is not assigned to you. Cannot raise an issue.'
                }

    utc_time=datetime.datetime.now()
    offset= datetime.timedelta(hours=5,minutes=30)
    curr_time=str((utc_time+offset).strftime("%Y-%m-%d %H:%M:%S.%f"))
    s3_time=event.get('requestContext').get('requestTimeEpoch')
    myuuid=str(uuid.uuid4())[:16]

    if event.get('queryStringParameters')==None:
        item_url={
            'IssueId':myuuid,
            'IssueDescription':body['IssueDescription'],
            'IssueStatus':"Pending",
            'CreatedBy': user_name,
            'CreatedAt':curr_time,
            'AssetId':body['AssetId'],
            'DeleteRequest':"False",
            'IssuePriority':"Low",
            'HttpMethod':'POST'
        }
        try:
            is_b64_encode=event.get('isBase64Encoded', False)
            object_key=f"issues/{asset_id}/{myuuid}/issue_{s3_time}.zip"
            put_url=generate_presigned_url(bucket_name,object_key,item_url,operation='put_object',expiration=3600)
            logger.info("Pre-signed url has been generated")
            return {
                    "statusCode": 200,
                    "body": json.dumps({
                        "preSignedUrl": put_url,
                    })
                } 
        except Exception as e:
            logger.error("Error has occured while raising issue")
            print("Error: ",str(e))
            return {
                'statusCode': 500,
                'body': f'Error has occured while raising issue: {str(e)}'
            }
    elif event.get('queryStringParameters').get('type')=='report':
        asset_response=assets_table.get_item(
            Key={
                'AssetId': body.get('AssetId')
            },
            ProjectionExpression="AssetId, AssetStatus, Type"
        )
        if asset_response.get('Item').get('AssetStatus') =='Missing':
            logger.warning("Issue cannot be raised for missing assets")
            return {
                'statusCode': 200,
                'body': 'Asset is missing. Cannot raise an issue.'
            }
        if asset_response.get('Item').get('Type')=='Digital':
            logger.warning('Cannot report a digital asset missing')
            return {
                'statusCode':200,
                'body':'Digital assets cannot be reported missing'
            }
        try:
            Item={
                'IssueId': myuuid,
                'IssueDescription': body.get('IssueDescription'),
                'CreatedBy': user_name,
                'CreatedAt': curr_time,
                'AssetId': asset_id,
                'IssueStatus':'Pending',
                'LastModifiedBy': user_name,
                'LastModifiedAt': curr_time,
                'DeleteRequest':'False',
                'Report': 'Missing'
            }
            dynamodb_response=issues_table.put_item(
                Item=Item
            )
            logger.info(f"Dynamodb response is: {dynamodb_response}")
            
            try:
                #sending mail to all admins about reported asset
                ses_response=ses_client.send_email(
                    Source=sender_email,
                    Destination={'ToAddresses': admin_emails},
                    Message={
                        'Subject': {'Data': f"Asset reported missing"},
                        'Body': {'Text': {'Data': f"The asset with id: {asset_id} has been reported missing"}}
                    }
                )
                logger.info(f"SES response is: {ses_response}")
            except Exception as e:
                logger.error("Error has occured while sending mail to admins")
                print("Error: ", str(e))

            return {
                'statusCode':200,
                'body':'Asset report made'
            }
        except Exception as e:
            logger.error("Error has occured while raising issue")
            print("Error: ",str(e))
            return {
                'statusCode': 500,
                'body': f'Error has occured while raising issue: {str(e)}'
            }

def s3_object_ddb_creation(event,sender_email,admin_emails):
    object_key=event.get('Records')[0].get('s3').get('object').get('key')
    object_key=object_key.replace('%3A',':')
    object_key=object_key.replace('+', ' ')
    logger.info(f"obect key:{object_key}")
    response=s3_client.head_object(Bucket=bucket_name, Key=object_key)
    metadata=response.get('Metadata', {})
    logger.info(f"metadata: {metadata}")
    if metadata.get('httpmethod')=='POST':
        response=issues_table.put_item(
            Item={
                'IssueId': metadata.get('issueid'),
                'IssueStatus': metadata.get('issuestatus'),
                'IssueDescription': metadata.get('issuedescription'),
                'CreatedBy': metadata.get('createdby'),
                'CreatedAt': metadata.get('createdat'),
                'AssetId': metadata.get('assetid'),
                'DeleteRequest': metadata.get('deleterequest'),
                'IssuePriority': metadata.get('issuepriority'),
                'LastModifiedBy': metadata.get('createdby'),
                'LastModifiedAt': metadata.get('createdat')
            }
        )
        logger.info(f"Sender Email: {sender_email}")
        logger.info(f"Admin Emails: {admin_emails}")
        try:
            response=ses_client.send_email(
                Source=sender_email,
                Destination={
                    'BccAddresses': admin_emails
                },
                Message={
                    'Subject': {'Data': "Issue Raised Alert", 'Charset': 'UTF-8'},
                    'Body': {
                        'Text': {'Data': "An issue has been raised by the user", 'Charset': 'UTF-8'}
                    }
                }
            )
        except Exception as e:
            logger.error("Error has occured while sending mail to admins")
            print("Error: ", str(e))

        return {
            'statusCode':200,
            'body':json.dumps(response)
        } 
    else:
        return {
            'statusCode':200,
            'body':'Triggered by PUT method, ignore'
        }


def get_by_image_id(event,id,user_details):
    logger.info('Getting by image id')
    file_name=event.get('queryStringParameters').get('file-name')
    try:
        issue_response=issues_table.get_item(
            Key={
                'IssueId': id
            }
        )
        logger.info(f"Issue response : {issue_response}")
        if not issue_response.get('Item',{}):
            logger.warning("Issue not found")
            return {
                'statusCode': 404,
                'body': json.dumps('Issue not found')
            }
        asset_id=issue_response.get('Item').get('AssetId')
        object_key=f"issues/{asset_id}/{id}/{file_name}"
        
            
        if user_details.get('role')=='User':
            issue_creator=issue_response.get('Item').get('CreatedBy')
            if issue_creator!=user_details.get('username'):
                logger.warning(f"Unauthorized: User {user_details.get('username')} is not the creator of issue {issue_id}")
                return {
                    'statusCode': 403,
                    'body': json.dumps('Not authorized to view this image')
                }     
        try:
            url = generate_presigned_url(bucket_name=bucket_name,object_key=object_key,operation='get_object',expiration=3600)
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'preSignedUrl': url
                })
            }
        except Exception as e:
            logger.error(f"Error generating presigned URL: {str(e)}")
            return {
                'statusCode': 500,
                'body': json.dumps('Error generating image URL')
            }
            
    except Exception as e:
        logger.error(f"Error in get_by_image_id function: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error retrieving image: {str(e)}')
        }


def get_by_issue_id(event,id,user_details):
    """
    Retrieve specific issue by ID

    Returns issue details if authorized. Admins can see any,
    users only their own issues.

    Args:
        event (dict): Lambda event
        issue_id (str): Target issue ID
        user_details (dict): User authentication details

    Returns:
        dict: Response containing HTTP status code and either issue data (JSON) or error message
    """
    try:
        response=issues_table.get_item(
            Key={
                'IssueId': id
            }
        )
        if response.get('Item')==None:
            logger.info("No issue with that issue id")
            return {
                'statusCode':200,
                'body':'No issue with that issue id'
            }
        asset_id=response.get('Item').get('AssetId')
        logger.info(f"Asset id is: {asset_id}")
        s3_prefix=f"issues/{asset_id}/{id}/"
        logger.info(f"s3 prefix is {s3_prefix}")
        s3_issue_image_list=s3_client.list_objects(
                Bucket=bucket_name,
                Prefix=s3_prefix
            )
        logger.info(f"S3 list is {s3_issue_image_list}")
        contents=[item.get('Key') for item in s3_issue_image_list.get('Contents')]
        logger.info(f"Image key list is {contents}")
        if user_details.get('role') in ['Admin','Manager']:
            logger.info("Issue details are available for admin")
            return {
                'statusCode':200,
                'body':json.dumps({
                    "message":json.dumps(response.get('Item')),
                    "imageKeys":contents
                    })
            }

        elif user_details.get('role')=='User':
            if response.get('Item').get('CreatedBy')==user_details.get('username'):
                logger.info("Issue details are available for user")
                return {
                    'statusCode':200,
                    'body':json.dumps({
                        "issues":json.dumps(response.get('Item')),
                        "imageKeys":contents
                        })
                }
            else:
                logger.warning("Not authorized to view this issue!!!")
                return {
                    'statusCode': 403,
                    'body': "Not authorized to view this issue!!"
                }        
    except Exception as e:
        logger.error(f"Error occured in get_issue_by_id function: {str(e)}")
        return {
            'statusCode':500,
            'body': json.dumps(str(e))
        }
    

def get_by_asset_id(event,id,user_details):
    """
    Retrieve issues by asset ID

    Returns issues for specified asset. Admins see all,
    users only their own issues.

    Args:
        event (dict): Lambda event
        asset_id (str): Target asset ID
        user_details (dict): User authentication details

    Returns:
        dict: Response containing HTTP status code and either asset-related issues (JSON) or error details
    """
    try:
        asset_response= assets_table.get_item(
            Key={
                'AssetId': id
            }
        )
        if asset_response.get('Item')==None:
            logger.info("No asset with that asset id")
            return {
                'statusCode':200,
                'body':'No asset with that asset-id'
            }
            
        if user_details.get('role') in ['Admin','Manager']:
            response=issues_table.query(
                IndexName='AssetId-CreatedBy-index',
                KeyConditionExpression="AssetId = :asset_id",
                ExpressionAttributeValues={
                    ":asset_id": id
                }
            )

            if not response.get('Items'):
                logger.info("No issues for this asset")
                return {
                    'statusCode':200,
                    'body':'No issues for this asset'
                }
            logger.info(f"Issue details of the asset are: {response.get('Items')}")
        elif user_details.get('role')=='User':
            response=issues_table.query(
                IndexName='AssetId-CreatedBy-index',
                KeyConditionExpression="AssetId = :asset_id AND CreatedBy = :raised_by",
                ExpressionAttributeValues={
                    ":asset_id": id,
                    ":raised_by": user_details.get('username')
                }
            )
            logger.info(f"Issue details of the asset are: {response['Items']}")
        else:
            logger.warning('Unauthorized')
            return {
                'statusCode': 403,
                'body': "Not authorized to view this issue!!"
            }
        output_items=response.get('Items',[])
        if output_items==[]:
            return {
                'statusCode':200,
                'body':'No issues exist in the system for that asset'
            }
        output=[]
        for item in output_items:
            output.append({
                "IssueId":item.get('IssueId'),
                "AssetId":item.get('AssetId'),
                "IssueDescription":item.get("IssueDescription"),
                "Notes":item.get("Notes","None"),
                "IssueStatus":item.get("IssueStatus")
            })
        return {
            'statusCode': 200,
            'body': json.dumps(output)
        }
    except Exception as e:
        logger.error(f"Error occured in get_issue_by_asset_id function: {str(e)}")
        return {
            'statusCode':500,
            'body': json.dumps(str(e))
        }

def get_report_status(event,user_details):
    logger.info("Getting report status")
    if user_details.get('role') in ['Admin','Manager']:
        try:
            response=issues_table.query(
                IndexName='Report-CreatedBy-index',
                KeyConditionExpression='Report=:report',
                ExpressionAttributeValues={':report': 'Missing'}
            )
            logger.info(f"Report status response is: {response}")

            asset_ids = list(set(item.get('AssetId') for item in response.get('Items', [])))
            if asset_ids:
                assets_response = assets_table.scan(
                    FilterExpression='AssetStatus = :status',
                    ExpressionAttributeValues={
                        ':status': 'Missing'
                    },
                    ProjectionExpression='AssetId, AssetStatus'
                )
                missing_asset_ids = {item['AssetId'] for item in assets_response.get('Items', [])}
                output_items = [
                    item for item in response.get('Items', [])
                    if item.get('AssetId') in missing_asset_ids
                ]
            else:
                output_items = []
                    
        except Exception as e:
            logger.error(f"Error in get_report_status function: {str(e)}")
            return {
                'statusCode':500,
                'body': f'Error retrieving report status: {str(e)}'
            }
    elif user_details.get('role')=='User':
        try:
            response=issues_table.query(
                IndexName='Report-CreatedBy-index',
                KeyConditionExpression='Report=:report AND CreatedBy=:createdby',
                ExpressionAttributeValues={
                    ':report': 'Missing', 
                    ':createdby': user_details.get('username')
                }
            )
            logger.info(f"Report status response is: {response}")
            asset_ids = list(set(item.get('AssetId') for item in response.get('Items', [])))
            if asset_ids:
                assets_response = assets_table.scan(
                    FilterExpression='AssetStatus = :status',
                    ExpressionAttributeValues={
                        ':status': 'Missing'
                    },
                    ProjectionExpression='AssetId, AssetStatus'
                )
                missing_asset_ids = {item['AssetId'] for item in assets_response.get('Items', [])}
                output_items = [
                    item for item in response.get('Items', [])
                    if item.get('AssetId') in missing_asset_ids
                ]
            else:
                output_items = []
                    
        except Exception as e:
            logger.error(f"Error in get_report_status function: {str(e)}")
            return {
                'statusCode':500,
                'body': f'Error retrieving report status: {str(e)}'
            }
            
    if not output_items:
        return {
            'statusCode':200,
            'body':'No reports exist for currently missing assets'
        }
    output=[]
    for item in output_items:
        output.append({
            "IssueId":item.get('IssueId'),
            "AssetId":item.get('AssetId'),
            "IssueDescription":item.get("IssueDescription"),
            "Notes":item.get("Notes","None")
        })
    return {
        'statusCode': 200,
        'body': json.dumps(output)
    }


def delete_issue(event,id,user_details):
    """
    Delete an issue record

    Allows deletion by Admins/Managers. Sends user notification.

    Args:
        event (dict): Lambda event
        issue_id (str): Target issue ID
        user_details (dict): User authentication details

    Returns:
        dict: Response containing HTTP status code and either success message or error details
    """
    try:
        if user_details.get('role') in ['Admin','Manager']:
            item=issues_table.get_item(
                Key={
                    "IssueId": id
                }
            )
            if item.get('Item')==None:
                logger.info('No issue with that ID')
                return {
                    'statusCode':400,
                    'body':'No issue with that id'
                }
            asset_id=item.get('Item').get('AssetId')
            s3_prefix=f"issues/{asset_id}/{id}/"
            s3_issue_image_list=s3_client.list_objects(
                Bucket=bucket_name,
                Prefix=s3_prefix
            )
            logger.info(f"S3 list is {s3_issue_image_list}")
            contents=[item.get('Key') for item in s3_issue_image_list.get('Contents')]
            logger.info(f"Issue image contents are: {contents}")
            response=issues_table.delete_item(
                Key={
                    "IssueId": id
                }
            )
            logger.info("Issue deleted")
            for key in contents:
                s3_client.delete_object(
                    Bucket=bucket_name,
                    Key=key
                )
            logger.info("Images deleted")
            return {
                'statusCode': 200,
                'body': 'Issue has been deleted'
            }
        elif user_details.get('role')=='User':
            logger.warning("Not authorized to delete the issue")
            return {
                'statusCode': 403,
                'body': 'Not authorized to delete this issue!!'
            }
    except Exception as e:
        logger.error(f"Error in delete_issue function: {str(e)}")
        return {
            'statusCode':500,
            'body': f'Error has occured {str(e)}'
        }
    
def delete_image(event,id,user_details):
    try:
        file_name=event.get('queryStringParameters').get('file-name')
        
        issue_response=issues_table.get_item(
            Key={
                "IssueId": id
            },
            ProjectionExpression="CreatedBy, AssetId"
        )
        logger.info(f"Issue response is {issue_response}")
        key=f"issues/{issue_response.get('Item').get('AssetId')}/{id}/{file_name}"
        logger.info(f"Key is {key}")
        if user_details.get('role') in ['Admin','Manager']:
            s3_client.delete_object(
                Bucket=bucket_name,
                Key=key
            )
            return {
                'statusCode':200,
                'body':'Image deleted'
            }
        elif user_details.get('role')=='User':
            if user_details.get('username')==issue_response.get('Item').get('CreatedBy'):
                logger.info("User is authorized to delete the image")
                s3_client.delete_object(
                    Bucket=bucket_name,
                    Key=key
                )
                return {
                    'statusCode':200,
                    'body':'Image deleted'
                }
    except Exception as e:
        logger.error(f"Error in delete_image function: {str(e)}")
        return {
            'statusCode':500,
            'body':'Error in delete image function'
        }
def update_issue(event,id,user_details,sender_email,admin_emails):
    """
    Update existing issue record

    Handles partial updates to issue fields with role-based validation.
    Sends notifications for status changes and delete requests.

    Args:
        event (dict): Lambda event containing update data
        issue_id (str): Target issue ID to update
        user_details (dict): Authenticated user details

    Returns:
        dict: Response containing HTTP status code and either success confirmation or error information
    """
    body=json.loads(event.get("body"))
    logger.info(f"Body: {body}")
    logger.info(f"Id: {id}")
    #to check if delete-request raised for the already existing delete request
    item=issues_table.get_item(
        Key={
            "IssueId": id
        }
    )
    logger.info(f"Item is {item}")
    if body.get("DeleteRequest") and user_details['role'] in ['Manager', 'Admin']:
        logger.warning("Admin or Manager cannot edit a delete request")
        return {
                'statusCode':200,
                'body':'Admin or manager cannot change a delete request. Only a user can raise a request.'
        }
    if body.get('DeleteRequest')=="True" and item.get('Item').get('DeleteRequest')=="True" :
        logger.warning("Delete request is already raised")
        return {
            'statusCode':200,
            'body':'Delete request already raised'
        }
    
    utc_time=datetime.datetime.now()
    offset= datetime.timedelta(hours=5,minutes=30)
    curr_time=str((utc_time+offset).strftime("%Y-%m-%d %H:%M:%S.%f"))
    expression=["LastModifiedBy = :LastModifiedBy","LastModifiedAt = :LastModifiedAt"]
    #update user to the current logged in user
    attributes={":LastModifiedBy": user_details.get('username'),":LastModifiedAt": curr_time}

    #To check user is updating anything other than delete-request
    user_flag=True
    admin_flag=True

    for text in body:
        if text!='DeleteRequest' and text!="IssueDescription":
            user_flag=False
        if text=='AssetId' or text=='DeleteRequest' or text=='IssueDescription':
            logger.info(item)
            if text=='IssueDescription':
                if item.get('Item').get('CreatedBy')==user_details.get('username'):
                    admin_flag=True
            else:
                admin_flag=False
        column=text[0].upper() + text[1:]
        temp=f":{column}"
        expression.append(f"{column}={temp}")
        attributes[temp]= body[text]
    update_expression="SET "+", ".join(expression)
    try: 
        if user_details.get('role') in ['Admin','Manager']:
            if admin_flag:
                response=issues_table.update_item(
                    Key={
                        "IssueId": id
                    },
                    UpdateExpression=update_expression,
                    ExpressionAttributeValues=attributes
                ) 
                if body.get("IssueStatus")=='Resolved':
                    
                    #to notify the user who raised the issue
                    user=item.get('Item').get('CreatedBy')
                    response=users_table.get_item(
                        Key={'UserName': user}, 
                        ProjectionExpression='Email'
                    )
                    user_email=response['Item']['Email']
                    message=f"Issue is resolved"
                    res=ses_client.send_email(
                        Source=sender_email,
                        Destination={'ToAddresses': [user_email]},
                        Message={
                            'Subject': {'Data': 'Issue Notification'},
                            'Body': {
                                'Text': {'Data': message},
                            }
                        }
                    )
                logger.info("Issue details updated")
                return {
                    'statusCode': 200,
                    'body': 'Issue updated'
                }
            
            else:
                logger.warning("Cannot update AssetId or Delete Request")
                return{
                    'statusCode': 400,
                    'body': "Cannot update AssetId or DeleteRequest of an issue!!"
                }
        elif user_details.get('role')=='User':
            if user_flag:
                if item.get('Item').get('CreatedBy')!= user_details['username']:
                    logger.warning("Cannot edit other's issues")
                    return {
                        'statusCode':200,
                        'body':"you cannot update other's issues"
                    }
                response=issues_table.update_item(
                    Key={
                        "IssueId": id
                    },
                    UpdateExpression=update_expression,
                    ExpressionAttributeValues=attributes
                )
                logger.info("Issue updated")

                #send mail to admin
                if body.get('DeleteRequest'):
                    message=f"Issue delete requested by user: {user_details.get('username')}"
                    response=ses_client.send_email(
                        Source=sender_email,
                        Destination={
                            'BccAddresses': admin_emails
                        },
                        Message={
                            'Subject': {'Data': 'Issue Delete Request Notification'},
                            'Body': {
                                'Text': {'Data': message},
                            }
                        }
                    )
                return {
                    'statusCode': 200,
                    'body': 'Issue updated'
                }
            else:
                logger.warning("Cannot update these details")
                return {
                    'statusCode': 403,
                    'body': 'Cannot update these details!!'
                }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode':500,
            'body': f'{str(e)}'
        }


def image_upload(event,id,user_details):
    logger.info("Adding new images") 
    try:
        # First get the issue details
        response=issues_table.get_item(
            Key={
                'IssueId': id
            }
        )
        
        if not response.get('Item'):
            logger.warning("No issue found with the given ID")
            return {
                'statusCode': 404,
                'body': json.dumps('Issue not found')
            }
            
        # Check if the current user is the one who raised the issue
        issue_creator=response.get('Item').get('CreatedBy')
        if issue_creator!=user_details.get('username'):
            logger.warning(f"Unauthorized: User {user_details.get('username')} is not the creator of issue {id}")
            return {
                'statusCode': 403,
                'body': json.dumps('Only the issue creator can add images to this issue')
            }
            
        s3_time=event.get('requestContext').get('requestTimeEpoch')
        
        # Prepare metadata for the image
        asset_id=response.get('Item').get('AssetId')
        item={
            "IssueId": id,
            "AssetId": asset_id,
            "CreatedBy": response.get('Item').get('CreatedBy'),
            "CreatedAt": response.get('Item').get('CreatedAt'),
            "DeleteRequest": response.get('Item').get('DeleteRequest'),
            "IssuePriority": response.get('Item').get('IssuePriority'),
            "IssueStatus": response.get('Item').get('IssueStatus'),
            "HttpMethod":"PUT"
        }
        logger.info(f"Item is {item}")
        # Generate a unique key for the image
        object_key=f"issues/{asset_id}/{id}/issue_{s3_time}.zip"

        
        # Generate presigned URL for image upload
        put_url=generate_presigned_url(bucket_name, object_key, item, operation='put_object', expiration=3600)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'preSignedUrl': put_url,
            })
        }
    except Exception as e:
        logger.error(f"Error in image_upload function: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Error occurred while generating image upload URL: {str(e)}'
        }



def lambda_handler(event, context):
    """
    Main Lambda entry point

    Routes incoming requests to appropriate handler functions based on
    HTTP method and resource path. Handles authorization and errors.

    Args:
        event (dict): AWS Lambda event
        context (object): AWS Lambda context

    Returns:
        dict: Final response object
    """
    
    logger.info("Event: "+str(event))
    try:
        verified_mails=ses_client.list_verified_email_addresses()
        sender_email='noreply@cloudwick.com'
        logger.info(f"Sender Email: {sender_email}")
        admin_mails_response=users_table.query(
            IndexName='RoleName-index',
            KeyConditionExpression='RoleName = :role',
            ExpressionAttributeValues={':role': 'Admin'},
            ProjectionExpression='Email'
        )
        logger.info(f"Admin Query Response: {admin_mails_response}")
        admin_emails=[item.get('Email') for item in admin_mails_response['Items'] if item.get('Email') in verified_mails.get('VerifiedEmailAddresses')]
        logger.info(f"Admin Emails: {admin_emails}")
        if event.get('resource'):
            token_details=event['requestContext']['authorizer']['claims']
            user_details={
                'username': token_details.get('cognito:username'),
                'role': token_details.get('custom:role', 'unknown'),
                'email': token_details.get('email', 'unknown')
            }
            logger.info(f"User details are: {user_details}")
            response=users_table.get_item(
                Key={
                    'UserName': user_details['username'] 
                },
                ProjectionExpression='RoleName'
            )
            if response=={} or response.get('UserStatus')=='Inactive':
                return{ 
                    'statusCode':404,
                    'body':'Access in user not found'
                }
            logger.info(f"Response: {response}")
            user_details['role']=response.get('Item').get('RoleName')

            logger.info(f"Event: {event}")
            if event.get('resource')=="/issues" and event.get('path')=="/issues":
                logger.info("Getting all issues")
                if event.get('httpMethod')=="GET":
                    logger.info("Getting all issues get")
                    if event.get('queryStringParameters')==None:
                        return get_all_issues(user_details)
                    elif event.get('queryStringParameters').get('type')=='issue-status':
                        print("getting issue status")
                        return get_issue_status(event,user_details)
                    elif event.get('queryStringParameters').get('type')=='delete-request':
                        return get_delete_status(event,user_details)
                    elif event.get('queryStringParameters').get('type')=='report':
                        return get_report_status(event,user_details)
                    
                    
                elif event.get('httpMethod')=="POST":
                    return add_issue(event,user_details,sender_email,admin_emails)
                
                
            elif event.get('resource')=="/issues/{id}" and "/issues/" in event.get('path'):
                id=event.get('pathParameters').get('id')
                print(id)
                if event.get('httpMethod')=="GET":
                    if event.get('queryStringParameters').get('get-by')=='issue-id':
                        return get_by_issue_id(event,id,user_details)
                    elif event.get('queryStringParameters').get('get-by')=='asset-id':
                        return get_by_asset_id(event,id,user_details)
                    elif event.get('queryStringParameters').get('get-by')=='image-id':
                        return get_by_image_id(event,id,user_details)
                    
                    
                elif event.get('httpMethod')=="DELETE":
                    if event.get('queryStringParameters',None)==None:
                        return delete_issue(event,id,user_details)
                    elif event.get('queryStringParameters').get('type')=='image':
                        return delete_image(event,id,user_details)
                    
                    
                    
                elif event.get('httpMethod')=="PUT":
                    if event.get('queryStringParameters'): 
                        if event.get('queryStringParameters').get('update')=='issue-image':
                            return image_upload(event,id,user_details)
                        elif event.get('queryStringParameters').get('update')=='issue-details':
                            for text in json.loads(event.get('body')).keys():
                                if text not in ['DeleteRequest', 'IssueDescription','IssueStatus','Notes','IssuePriority','IssueCost']:
                                    logger.warning("These are invalid updations")
                                    return {
                                        'statusCode':400,
                                        'body':'Please give valid updations!!'
                                    }
                            return update_issue(event,id,user_details,sender_email,admin_emails)
                        else:
                            return {
                                'statusCode':500,
                                'body':'Invalid query parameter'
                            }
        elif event.get('Records'):
            print("s3 event")
            return s3_object_ddb_creation(event,sender_email,admin_emails)
        else:
            return {
                'statusCode':200,
                'body':'Not valid event'
            }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode':500,
            'body': 'An error has occured'
        }        