import json
import boto3
import random
import string
import datetime
import os
import logging
from boto3.dynamodb.conditions import Key, Attr


logger=logging.getLogger()
logger.setLevel(logging.INFO)

cognito_client=boto3.client('cognito-idp')
dynamodb_client=boto3.client('dynamodb')
dynamodb_resource=boto3.resource('dynamodb')
ssm_client=boto3.client('ssm')

assets_table_name=os.environ['ASSETS_TABLE_NAME']
groups_table_name=os.environ['GROUPS_TABLE_NAME']
users_table_name=os.environ['USERS_TABLE_NAME']
assignment_table_name=os.environ['ASSIGNMENT_TABLE_NAME']
USER_POOL=os.environ['USER_POOL_ID']
USER_POOL_ID=ssm_client.get_parameter(Name=USER_POOL)['Parameter']['Value']
ddb_users_table=dynamodb_resource.Table(users_table_name)
ddb_groups_table=dynamodb_resource.Table(groups_table_name)
ddb_assignment_table=dynamodb_resource.Table(assignment_table_name)
ddb_assets_table=dynamodb_resource.Table(assets_table_name)



def generate_temporary_password():
    """
    Generates a temporary password that meets AWS Cognito password requirements.
    
    Returns:
        str: A randomly generated password containing uppercase, lowercase, digits, and special characters.
        None: If an error occurs during password generation.
    """
    logger.info("Generating temporary password...")
    try:
        password=[
            random.choice(string.ascii_uppercase),
            random.choice(string.ascii_lowercase),
            random.choice(string.digits),
            random.choice(string.punctuation),
        ]
        characters=string.ascii_letters + string.digits + string.punctuation
        password += random.choices(characters, k=4)
        random.shuffle(password)
        return ''.join(password)
    except Exception as e:
        logger.error(f"Error generating temporary password: {e}")
        return None

def handle_response(message, status=500):
    """
    Handles error responses by logging the response and returning a formatted response.
    
    Args:
        message (str): The error message to be logged and returned.
        status (int, optional): HTTP status code. Defaults to 500.
    
    Returns:
        dict: A dictionary containing the status code and body message.
    """
    logger.info(message)
    body={
        "Response": message
    }
    return {
        "statusCode": status,
        "body": json.dumps(body)
    }

def admin_create_user(event, context, user_details):
    """
    Creates a new user in both Cognito and DynamoDB.
    
    Args:
        event (dict): The event data containing user creation details.
        context (dict): The Lambda context.
        user_details (dict): Details of the user performing the action.
    
    Returns:
        dict: Response containing status code and either success message or error details.
    """
    logger.info(f"Attempting to create new user by {user_details['user']} with role {user_details['role']}")
    if user_details['role'] not in ['Admin', 'Manager']:
        logger.warning(f"Unauthorized attempt to create user by {user_details['user']} with role {user_details['role']}")
        return handle_response('Unauthorized, user has no permissions in creating an user', 403)

    try:
        body=json.loads(event['body'])
        required_fields=['UserName', 'Email', 'Phone', 'Name', 'RoleName', 'UserType']
        logger.info(f"Validating required fields for user creation: {required_fields}")
        
        missing_fields=[]
        for field in required_fields:
            if field not in body:
                missing_fields.append(field)
        
        if missing_fields==[]:
            if body['RoleName'] not in ['Admin', 'Manager', 'User']:
                logger.error(f"Invalid role attempted: {body['RoleName']}")
                return handle_response('Invalid RoleName', 400)
        else:
            logger.error(f"Missing required fields: {missing_fields}")
            return handle_response(f'Missing required fields: {missing_fields}', 400)

        invalid_fields=[field for field in body if field not in required_fields]
        if invalid_fields:
            logger.error(f"Invalid fields provided: {invalid_fields}")
            return handle_response(f'Invalid fields: {invalid_fields}', 400)

        if user_details['role']=='Manager' and body['RoleName']=='Manager':
            logger.error("Attempt to create second manager")
            return handle_response('Only one manager can be present in system', 403)

        if body['UserType'] != 'Employee':
            if body['RoleName'] != 'User':
                return handle_response('External user cannot be a Manager or Admin', 403)
            if body['Email'].endswith('@cloudwick.com'):
                return handle_response('Invalid email domain for external user', 403)

        if body['UserType']=='Employee':
            if not body['Email'].endswith('@cloudwick.com'):
                logger.error("Invalid email domain for employee")
                return handle_response('Invalid email domain for employee', 400)


        password=generate_temporary_password()
        
        timestamp=str((datetime.datetime.now() + datetime.timedelta(hours=5, minutes=30)).strftime("%Y-%m-%d %H:%M:%S.%f"))

        response=ddb_users_table.get_item(Key={'UserName': body['UserName']})
        if response.get('Item'):
            logger.error(f"User {body['UserName']} already exists")
            return handle_response('User already exists', 400)

        if not body['Email'].endswith('@cloudwick.com'):
            return handle_response('Invalid email domain',200)

        response=ddb_users_table.query(  
            IndexName='Email-index',
            KeyConditionExpression='Email=:email',
            ExpressionAttributeValues={':email': body['Email']}
        )
        if len(response.get('Items'))>0:
            logger.info("Email already exists with the given email.")
            raise Exception("Email already exists in the system")
        else:
            logger.info("No user found with the given email.")

        try:
            logger.info(f"Creating user {body['UserName']} in Cognito user pool")
            cognito_client.admin_create_user(
                UserPoolId=USER_POOL_ID,
                Username=body['UserName'],
                TemporaryPassword=password,
                UserAttributes=[
                    {'Name': 'email', 'Value': body['Email']},
                    {'Name': 'phone_number', 'Value': body['Phone']},
                    {'Name': 'name', 'Value': body['Name']},
                    {'Name': 'custom:role', 'Value': body['RoleName']},
                    {'Name': 'email_verified', 'Value': 'true'}
                ],
                DesiredDeliveryMediums=['EMAIL']
            )
            logger.info(f"Successfully created user {body['UserName']} in Cognito")
        except Exception as e:
            logger.error(f"Failed to create user in Cognito: {str(e)}")
            return handle_response(str(e), 200)


        try:
            
            logger.info(f"Creating user {body['UserName']} in DynamoDB")
            ddb_users_table.put_item(Item={
                'UserName': body['UserName'],
                'Name': body['Name'],
                'Email': body['Email'],
                'Phone': body['Phone'],
                'RoleName': body['RoleName'],
                'CreatedBy': user_details['user'],
                'CreatedAt': timestamp,
                'LastModifiedBy': user_details['user'],
                'LastModifiedAt': timestamp,
                'ConfirmationStatus': 'unconfirmed',
                'Groups':[],
                'UserType': body['UserType'],
                'UserStatus': 'Active'
            })
            logger.info(f"Successfully created user {body['UserName']} in DynamoDB")
        except Exception as e:
            logger.error(f"Failed to create user in DynamoDB: {str(e)}")
            try:
                logger.info(f"Attempting to rollback Cognito user creation for {body['UserName']}")
                cognito_client.admin_delete_user(UserPoolId=USER_POOL_ID, UserName=body['UserName'])
            except Exception as rollback_error:
                logger.error(f"Failed to rollback Cognito user creation: {str(rollback_error)}")
                return handle_response('DynamoDB operation failed and Cognito operation failed', 500)
            
            return handle_response('DynamoDB operation failed', 500)

        logger.info(f"Successfully created user {body['UserName']}")
        return handle_response(f'User created successfully by {user_details["user"]}', 200)

    except Exception as e:
        logger.error(f"Unexpected error in user creation: {str(e)}")
        return handle_response(f'User creation failed {str(e)}', 500)

def admin_update_user_attributes(event, context, user_details):
    try:
        body = json.loads(event['body'])
        user_name = event['pathParameters']['searchParam']
        if not user_name:
            return handle_response('Invalid user name', 400)
        if event.get('queryStringParameters') is None:
            return handle_response('No action parameter', 400)
        action = event['queryStringParameters'].get('action')
        # if action != 'user-name':
        #     logger.error(f"Invalid action parameter: {action}")
        #     return handle_response('Invalid action parameter', 400)
        logger.info(f"Initiating update for user '{user_name}' by '{user_details['user']}'")

        if not body:
            return handle_response('Empty request body', 400)

        if 'RoleName' in body:
            return handle_response('Cannot update role directly', 400)
        
        if 'UserStatus' in body:
            if len(body) > 1:
                return handle_response('Cannot update UserStatus along with other attributes', 400)
            if body['UserStatus'] != 'Active':
                return handle_response(f'Invalid Operation, Cant update UserStatus as {body['UserStatus']}', 400)

        if 'UserType' in body and user_details['role'] != 'Manager':
            return handle_response('Cannot update UserType directly by Admin/User', 400)

        invalid_fields = [f for f in body if f not in ['Name', 'Phone', 'UserStatus']]
        if invalid_fields:
            return handle_response(f'Invalid fields: {invalid_fields}', 400)

        try:
            user_data = ddb_users_table.get_item(Key={'UserName': user_name}).get('Item')
            if not user_data:
                return handle_response('User not found', 404)
        except Exception as e:
            return handle_response(f'Failed to fetch user data {str(e)}', 500)

        if user_details['role'] == 'User' and user_details['user'] != user_name:
            return handle_response('Unauthorized, User has no permissions to update other users', 403)

        if user_details['role'] == 'Admin' and user_data['RoleName'] == 'Manager':
            return handle_response('Admin cannot update Manager details', 403)

        if 'UserStatus' in body:
            if user_data['UserStatus'] == 'Inactive' and user_details['role'] != 'Manager':
                return handle_response('Cannot deactivate user directly by Admin/User, This action can be done by Manager', 403)
            if user_data['UserStatus'] != 'Inactive':
                return handle_response('Invalid Operation,User Status cannot be not modified if user is Active', 400)
        elif user_data['UserStatus'] == 'Inactive':
            return handle_response('Cannot update Inactive user Details', 403)

        user_attributes = []
        update_expression = []
        expression_values = {}
        attribute_names = {}

        if 'Name' in body:
            user_attributes.append({'Name': 'name', 'Value': body['Name']})
            update_expression.append('#name = :name')
            expression_values[':name'] = body['Name']
            attribute_names['#name'] = 'Name'

        if 'Phone' in body:
            user_attributes.append({'Name': 'phone_number', 'Value': body['Phone']})
            update_expression.append('Phone = :Phone')
            expression_values[':Phone'] = body['Phone']

        timestamp = (datetime.datetime.now() + datetime.timedelta(hours=5, minutes=30)).strftime("%Y-%m-%d %H:%M:%S.%f")
        update_expression.extend([
            'LastModifiedAt = :time',
            'LastModifiedBy = :modifier'
        ])
        expression_values[':time'] = timestamp
        expression_values[':modifier'] = user_details['user']

        if 'UserStatus' in body:
            try:
                password = generate_temporary_password()
                cognito_client.admin_create_user(
                    UserPoolId=USER_POOL_ID,
                    Username=user_name,
                    TemporaryPassword=password,
                    UserAttributes=[
                        {'Name': 'email', 'Value': user_data['Email']},
                        {'Name': 'phone_number', 'Value': user_data['Phone']},
                        {'Name': 'name', 'Value': user_data['Name']},
                        {'Name': 'custom:role', 'Value': user_data['RoleName']},
                        {'Name': 'email_verified', 'Value': 'true'}
                    ],
                    DesiredDeliveryMediums=['EMAIL']
                )

                ddb_users_table.update_item(
                    Key={'UserName': user_name},
                    UpdateExpression="SET UserStatus = :status, ConfirmationStatus = :unconfirmed",
                    ExpressionAttributeValues={
                        ":status": "Active",
                        ":unconfirmed": "unconfirmed"
                    },
                    ConditionExpression="attribute_exists(UserName)"
                )

                ddb_users_table.update_item(
                    Key={'UserName': user_name},
                    UpdateExpression="REMOVE #UserExpirationTime",
                    ExpressionAttributeNames={"#UserExpirationTime": "UserExpirationTime"},
                    ConditionExpression="attribute_exists(UserName)"
                )
            except Exception as e:
                return handle_response(f'Cognito/DynamoDB update failed: {str(e)}', 500)
        else:
            try:
                cognito_client.admin_update_user_attributes(
                    UserPoolId=USER_POOL_ID,
                    Username=user_name,
                    UserAttributes=user_attributes
                )
            except Exception as e:
                return handle_response(f'Cognito update failed: {str(e)}', 500)

            try:
                update_kwargs = {
                    'Key': {'UserName': user_name},
                    'UpdateExpression': f"SET {', '.join(update_expression)}",
                    'ExpressionAttributeValues': expression_values,
                    'ConditionExpression': "attribute_exists(UserName)"
                }
                if attribute_names:
                    update_kwargs['ExpressionAttributeNames'] = attribute_names

                ddb_users_table.update_item(**update_kwargs)
            except Exception as e:
                return handle_response(f'DynamoDB update failed: {str(e)}', 500)

        return {'statusCode': 200, 'body': json.dumps('Update successful')}

    except Exception as e:
        return handle_response(f'Update failed: {str(e)}', 500)

def get_users(event, context, user_details):
    """
    Retrieves a list of users with pagination support.
    
    Args:
        event (dict): The event data containing query parameters.
        context (dict): The Lambda context.
        user_details (dict): Details of the user performing the action.
    
    Returns:
        dict: Response containing status code and list of users or error details.
    """
    try:
        if user_details.get('role') not in ['Admin', 'Manager']:
            return handle_response('Unauthorized, user has no permissions to fetch all user details', 403)

        limit=10
        last_evaluated_key=None

        scan_kwargs={
            'Limit': limit,
            'ProjectionExpression': 'UserName, RoleName'
        }
        if event.get('queryStringParameters') and event['queryStringParameters'].get('lastKey'):
            last_evaluated_key=event['queryStringParameters']['lastKey']
            last_key={'UserName':last_evaluated_key}
            scan_kwargs['ExclusiveStartKey']=last_key
        logger.info(f"Scan parameters: {scan_kwargs}")
        response=ddb_users_table.scan(**scan_kwargs)
        items=response.get('Items', [])

        users=[
            {
                "UserName": user.get("UserName"),
                "RoleName": user.get("RoleName")
            }
            for user in items
        ]

        result={
            'Users': users,
            'lastKey': response.get('LastEvaluatedKey')
        }

        if result['lastKey']:
            result['lastKey']=json.dumps(result['lastKey'])

        return handle_response(result, 200)

    except Exception as e:
        return handle_response(f'Fetching user details failed, Try again, {str(e)}', 500)

def get_user_by_search_param(event, context, user_details):
    """
    Retrieves user details based on search parameters.
    
    Args:
        event (dict): The event data containing search parameters.
        context (dict): The Lambda context.
        user_details (dict): Details of the user performing the action.
    
    Returns:
        dict: Response containing status code and user details or error message.
    """
    try:
        search_param=event['pathParameters']['searchParam']
        search_by=""
        if event.get('queryStringParameters') and event['queryStringParameters'].get('search-by'):
            search_by=event['queryStringParameters']['search-by']
            if search_by not in ['user-name', 'role']:
                return handle_response('search-by must be either user-name or role', 400)
        if search_by=='user-name':
            if user_details['role']=='User' and search_param != user_details['user']:
                return handle_response('Unauthorized', 403)
            
            try:
                item=ddb_users_table.get_item(Key={'UserName': search_param}).get('Item')
                if user_details['role'] == 'User':
                    item.pop('CreatedBy', None)
                    item.pop('CreatedAt', None)
                    item.pop('LastModifiedAt', None)
                    item.pop('LastModifiedBy', None)
                    item.pop('UserStatus',None)
                    item.pop('ConfirmationStatus', None)


                if not item:
                    return handle_response('User not found', 404)

                if user_details['role']!='Manager' and item['RoleName']=='Manager':
                    return handle_response('Unauthorized', 403)
                return handle_response(item, 200)
            except Exception:
                return handle_response('Server Issues ,Try again', 500)

        elif search_by=='role':
            if user_details['role'] not in ['Admin', 'Manager']:
                return handle_response('Unauthorized', 403)

            if search_param not in ['Admin', 'Manager', 'User']:
                return handle_response('Invalid role', 400)

       
            query_kwargs = {
                'IndexName': "RoleName-index",
                'KeyConditionExpression': Key("RoleName").eq(search_param),
                'ProjectionExpression': 'UserName, RoleName',
                'Limit': 10
            }

            if event.get('queryStringParameters') and event['queryStringParameters'].get('lastKey'):
                try:
                    last_key_str = event['queryStringParameters']['lastKey']

                    query_kwargs['ExclusiveStartKey'] = {
                        'UserName': last_key_str,
                        'RoleName': search_param
                    }
                except Exception as e:
                    logger.warning(f"Failed to parse lastKey: {str(e)}")

            try:
                response = ddb_users_table.query(**query_kwargs)
                items = response.get('Items', [])
                last_evaluated_key = response.get('LastEvaluatedKey')

                result = {'Users': items}
                if last_evaluated_key:
                    last_send_key=last_evaluated_key.get('UserName')
                    result['lastKey'] = json.dumps({'UserName':last_send_key}) 

                logger.info(f"Query results for role {search_param}: {items}")
                return handle_response(result, 200)

            except Exception as e:
                logger.exception("Error during DDB query")
                return handle_response(f'Query failed: {str(e)}', 500)


        return handle_response('Invalid action', 400)
    except Exception:
        return handle_response('Search failed', 500)

def admin_delete_user(event, context, user_details):
    """
    Deletes a user from both Cognito and DynamoDB, including cleanup of related resources.
    
    Args:
        event (dict): The event data containing user deletion details.
        context (dict): The Lambda context.
        user_details (dict): Details of the user performing the action.
    
    Returns:
        dict: Response containing status code and success/error message.
    """
    try:

        path_parameters=event['pathParameters']
        user_name=path_parameters.get('searchParam')
        if not user_name:
            return handle_response('Invalid user name', 400)
        if event.get('queryStringParameters') is None:
            return handle_response('No action parameter', 400)
        # action = event['queryStringParameters'].get('action')
        # if action != 'user-name':
        #     logger.error(f"Invalid action parameter: {action}")
        #     return handle_response('Invalid action parameter', 400)
        groups=[]
       
        try:
            user_data=ddb_users_table.get_item(
                Key={'UserName': user_name},
                ProjectionExpression='RoleName,Groups'
            ).get('Item', {})
            
            logger.info(f"User data: {user_data}")    
            if not user_data:
                return handle_response('User not found', 404)

            groups=user_data.get('Groups', [])
            
        except Exception as e:
            return handle_response(f'Failed to fetch user: {str(e)}', 500)
        
        if user_details['role']=='User':
            return handle_response('Unauthorized, user has no permissions to delete user', 403)
        if user_details['user']==user_name:
            return handle_response('Cannot delete self', 403)
        if user_details['role']=='Manager' and user_data['RoleName']=='Manager':
            return handle_response('Manager cannot delete other Managers', 403)
        if user_details['role']=='Admin' and user_data['RoleName'] != 'User':
            return handle_response('Admin cannot delete Managers and Admins, can only delete Users', 403)
        
        
        try:
            active_assets=ddb_assignment_table.query(
                IndexName="HolderId-index",
                KeyConditionExpression=Key("HolderId").eq(user_name),
                FilterExpression=Attr("assignmentStatus").eq("Active"),
                ProjectionExpression='AssignmentId,AssetId'
            )
            active_assets=active_assets.get('Items', [])
            logger.info(active_assets)
            logger.info(f"Found {len(active_assets)} active assets for user {user_name}")
            timestamp = str((datetime.datetime.now() + datetime.timedelta(hours=5, minutes=30)).strftime("%Y-%m-%d %H:%M:%S.%f"))
            for assignment in active_assets:
                if not isinstance(assignment, dict):
                    logger.error(f"Unexpected assignment type: {type(assignment)}")
                    continue
                try:
                    ddb_assignment_table.update_item(
                        Key={'AssignmentId': assignment['AssignmentId']},
                        UpdateExpression="SET assignmentStatus=:status,LastModifiedBy=:modifer,LastModifiedAt=:modifiedtime",
                        ExpressionAttributeValues={':status': 'Inactive',':modifier':user_details['user'],':modifiedtime':timestamp}
                    )
                except Exception as e:
                    logger.error(f"Failed to update assignment {assignment['AssignmentId']}: {str(e)}")
                    return handle_response(f'Failed to update assignment {assignment["AssignmentId"]}: {str(e)}', 500)

            for asset in active_assets:
                try:
                    ddb_assets_table.update_item(
                        Key={'AssetId': asset['AssetId']},
                        UpdateExpression="SET AssetStatus=:status,LastModifiedBy=:modifer,LastModifiedAt=:modifiedtime",
                        ExpressionAttributeValues={':status': 'Unassignment',':modifier':user_details['user'],':modifiedtime':timestamp}
                    )
                except Exception as e:
                    logging.error(f"Failed to update asset {asset['AssetId']}: {str(e)}")
                    return handle_response(f'Failed to update asset {asset["AssetId"]}: {str(e)}', 500)
        
        except Exception as e:
            logger.error(f"Failed to fetch assignment assets: {str(e)}")
            return handle_response(f'Failed to fetch assignment assets: {str(e)}', 500)

        logger.info(f"Processing group {groups}")

        keys = [{'GroupId': {'S': group_id}} for group_id in groups]
        if keys :
            try:
                response = dynamodb_client.batch_get_item(
                    RequestItems={
                        groups_table_name: {
                            'Keys': keys,
                            'ProjectionExpression':'GroupId,#user',
                            'ExpressionAttributeNames': {
                                '#user': 'Users'
                            }
                        }
                        
                    }
                )
                group_items = response['Responses'].get(groups_table_name, [])
                
                logger.info(f"Retrieved {len(group_items)} groups from DynamoDB")
            except Exception as e:
                logger.error(f"Batch get failed: {str(e)}")
                return handle_response(f"Batch get failed: {str(e)}", 500)


            for group in group_items:
                group_id = group['GroupId']['S']
                users = group.get('Users', {}).get('M', {})

                if user_name in users:
                    try:
                        logger.info(f"Removing user {user_name} from group {group_id}")
                        ddb_groups_table.update_item(
                            Key={'GroupId': group_id},
                            UpdateExpression='REMOVE #users.#uname ',
                            ExpressionAttributeNames={
                                '#users': 'Users',
                                '#uname': user_name
                            },
                        )
                        ddb_groups_table.update_item(
                            Key={'GroupId': group_id},
                            UpdateExpression='SET LastModifiedBy = :modifier, LastModifiedAt = :modifiedtime',
                            ExpressionAttributeValues={
                                ':modifier': user_details['user'],
                                ':modifiedtime': timestamp
                            }
                        )
                        logger.info(f"Successfully removed user {user_name} from group {group_id}")
                    except Exception as e:
                        logger.error(f"Failed to update group {group_id}: {str(e)}")
                        return handle_response(f"Update failed for group {group_id}: {str(e)}", 500)
                else:
                    logger.debug(f"User {user_name} not in group {group_id}, skipping")
                    
        
        expiry_time=int((datetime.datetime.now()+datetime.timedelta(days=730)).timestamp())
        try:
            ddb_users_table.update_item(
                Key={'UserName': user_name},
                UpdateExpression='SET UserStatus=:status, LastModifiedBy=:modifer,LastModifiedAt=:modifiedtime, UserExpirationTime=:expirytime',
                ExpressionAttributeValues={
                    ':status': 'Inactive',
                    ':modifer':user_details['user'],
                    ':modifiedtime':timestamp,
                    ':expirytime':expiry_time
                }
            )

        except Exception as e:
            return handle_response(f'Failed to delete user record: {str(e)}', 500)

        try:
            
            cognito_client.admin_delete_user(
                UserPoolId=USER_POOL_ID,
                Username=user_name
            )
            return {'statusCode': 200, 'body': json.dumps('User deleted successfully')}
        except Exception as e:
            return handle_response(f'Cognito deletion failed: {str(e)}', 500)


    except Exception as e:
        logger.error(f"Unexpected error in user deletion: {str(e)}")
        return handle_response(f'Error: {str(e)}', 500)

def change_role(event, context, user_details):
    """
    Changes a user's role in both Cognito and DynamoDB.
    
    Args:
        event (dict): The event data containing role change details.
        context (dict): The Lambda context.
        user_details (dict): Details of the user performing the action.
    
    Returns:
        dict: Response containing status code and success/error message.
    """
    try:
        logger.info(f"Processing role change request {event}")
        user_name=event['pathParameters']['userName']
        logger.info(f"Processing role change request for user {user_name}")
        new_role=event['queryStringParameters']['change-to']

        logger.info(f"Requested role change to: {new_role}")
        current_data={}
        
        try:
            current_data=ddb_users_table.get_item(
                Key={'UserName': user_name},
                ProjectionExpression='RoleName,Email,ConfirmationStatus,UserType'
            ).get('Item', {})
            logger.info(f"Current user data: {current_data}")
            if not current_data:
                return handle_response('User not found', 404)

        except Exception as e:
            return handle_response(f'Fetch failed, {str(e)}', 500)

        logger.info(f"Current user data: {current_data}")
        current_role=current_data['RoleName']
        if current_data['ConfirmationStatus']=='unconfirmed':
            return handle_response("User is not confirmed",200)
        if new_role==current_role:
            return handle_response(f'User is already {new_role}', 200)
        
        if current_data['UserType']=='External':
            return handle_response(f'Cannot change role of external user', 200)
            
        if user_name==user_details['user']:
            return handle_response('Cannot change own role', 403)

        if new_role=='Admin':
            if user_details['role'] not in ['Admin', 'Manager']:
                return handle_response('Unauthorized', 403)
            if current_role=='Manager':
                return handle_response('Cannot demote Manager to Admin', 400)

        elif new_role=='Manager':
            if user_details['role'] != 'Manager' and current_role != 'Admin':
                return handle_response('Unauthorized', 403)
            if current_role != 'Admin':
                return handle_response('Only Admin can become Manager', 400)
            if current_role=='Admin' and user_details['role'] != 'Manager':
                return handle_response('Only Manager can promote Admin to Manager', 403)
            

        elif new_role=='User':
            if user_details['role'] not in ['Admin', 'Manager']:
                return handle_response('Unauthorized', 403)
            if current_role=='Admin' and user_details['role'] != 'Manager':
                return handle_response('Only Manager can demote Admin', 403)

        else:
            return handle_response('Invalid role', 400)

        timestamp=str((datetime.datetime.now() + datetime.timedelta(hours=5, minutes=30)).strftime("%Y-%m-%d %H:%M:%S.%f"))

        try:
            cognito_client.admin_update_user_attributes(
                UserPoolId=USER_POOL_ID,
                Username=user_name,
                UserAttributes=[{'Name': 'custom:role', 'Value': new_role}]
            )
        except Exception as e:
            return handle_response(f'Cognito update failed,{str(e)}', 500)
            
        if new_role=='Manager' and user_details['role']=='Manager' and current_role=='Admin':
            try:
                cognito_client.admin_update_user_attributes(
                    UserPoolId=USER_POOL_ID,
                    Username=user_details['user'],
                    UserAttributes=[{'Name': 'custom:role', 'Value': 'Admin'}]
                )
            except Exception as e:
                return handle_response(f'Cognito update failed, {str(e)}', 500)
            try:
                ddb_users_table.update_item(
                    Key={'UserName': user_details['user']},
                    UpdateExpression="SET RoleName=:role, LastModifiedAt=:time, LastModifiedBy=:modifier",
                    ExpressionAttributeValues={
                        ":role": "Admin",
                        ":time": timestamp,
                        ":modifier": user_details['user']
                    }
                )
            except Exception as e:
                return handle_response(f'DynamoDB update failed, {str(e)}', 500)
        
       
        try:
            ddb_users_table.update_item(
                Key={'UserName': user_name},
                UpdateExpression="SET RoleName=:role, LastModifiedAt=:time, LastModifiedBy=:modifier",
                ExpressionAttributeValues={
                    ":role": new_role,
                    ":time": timestamp,
                    ":modifier": user_details['user']
                }
            )
        except Exception as e:
            return handle_response(f'DynamoDB update failed, {str(e)}', 500)


        return {'statusCode': 200, 'body': json.dumps('Role updated')}

    except Exception as e:
        return handle_response(f'Role change failed,{str(e)}', 500)

def lambda_handler(event, context):
    """
    Main Lambda handler function that routes requests to appropriate functions.
    
    Args:
        event (dict): The event data containing the API Gateway request.
        context (dict): The Lambda context.
    
    Returns:
        dict: Response containing status code and function-specific response or error message.
    """
    try:
        logger.info("Processing new request")
        token_details=event['requestContext']['authorizer']['claims']
        user_details={
            'user': token_details.get('cognito:username'),
            'role': token_details.get('custom:role', 'unknown'),
            'email': token_details.get('email', 'unknown')
        }
        logger.info(f"Request from user {user_details['user']} with role {user_details['role']}")

        response=ddb_users_table.get_item(Key={'UserName': user_details['user']},ProjectionExpression='RoleName,UserStatus').get('Item')
        if response== None or response.get('UserStatus')=='Inactive':
            return handle_response('Accessing User not found', 404)

        user_details['role']=response.get('RoleName')
        
        path=event.get('path', '')
        method=event.get('httpMethod', '')
        logger.info(f"Processing {method} request to {path}")

        if method=='POST' and path=='/users':
            return admin_create_user(event, context, user_details)

        elif method=='GET' and path.startswith('/users'):
            if event.get('pathParameters'):
                return get_user_by_search_param(event, context, user_details)
            return get_users(event, context, user_details)

        elif method=='DELETE' and path.startswith('/users'):
            return admin_delete_user(event, context, user_details)

        elif method=='PATCH' and path.startswith('/users/role/'):
            return change_role(event, context, user_details)
            
        elif method=='PUT' and '/users' in path:
            return admin_update_user_attributes(event, context, user_details)

        logger.warning(f"Invalid method/path combination: {method} {path}")
        return handle_response('Invalid Method', 404)
    except Exception as e:
        logger.error(f"Unexpected error in lambda handler: {str(e)}")
        return handle_response('Server error', 500)


