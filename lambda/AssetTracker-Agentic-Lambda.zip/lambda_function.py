import json
import boto3
import uuid
import datetime
import random
import string
from boto3.dynamodb.conditions import Key
from boto3.dynamodb.conditions import Attr
import logging
import os
import ast

logger=logging.getLogger()
logger.setLevel(logging.INFO)
cognito_client=boto3.client('cognito-idp')
ssm_client = boto3.client('ssm')
bedrock_runtime = boto3.client('bedrock-runtime')
db_client = boto3.client('dynamodb')
ses_client= boto3.client('ses')
asset_table= os.environ.get('ASSETS_TABLE_NAME')
issue_table= os.environ.get('ISSUES_TABLE_NAME')
assigned_table= os.environ.get('ASSIGNMENT_TABLE_NAME')
users_table= os.environ.get('USERS_TABLE_NAME')
groups_table= os.environ.get('GROUPS_TABLE_NAME')
comments_table= os.environ.get('COMMENTS_TABLE_NAME')

comprehend = boto3.client('comprehend')
s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
ddb_issue_table=dynamodb.Table(issue_table)
ddb_asset_table=dynamodb.Table(asset_table)
ddb_assigned_table=dynamodb.Table(assigned_table)
ddb_users_table=dynamodb.Table(users_table)
ddb_groups_table=dynamodb.Table(groups_table)
ddb_comments_resource= dynamodb.Table(comments_table)

S3_BUCKET_NAME= os.environ.get('S3_BUCKET_NAME')
USER_POOL_ID=os.environ['USER_POOL_ID']
USER_POOL_ID= ssm_client.get_parameter(Name=USER_POOL_ID)['Parameter']['Value']

def detect_and_redact_pii(text):
    response = comprehend.detect_pii_entities(Text=text, LanguageCode='en')
    entities = response.get("Entities", [])
    
    redacted_text = text
    for entity in sorted(entities, key=lambda e: e["BeginOffset"], reverse=True):
        start, end = entity["BeginOffset"], entity["EndOffset"]
        redacted_text = redacted_text[:start] + f"[{entity['Type']}]" + redacted_text[end:]

    return redacted_text


# def mask_pii_for_agent(input_text):
#     response = comprehend.detect_pii_entities(Text=input_text, LanguageCode='en')
#     redacted_text = input_text
#     pii_map = []
#     print(response)
#     for entity in sorted(response.get("Entities", []), key=lambda e: e["BeginOffset"], reverse=True):
#         start, end = entity["BeginOffset"], entity["EndOffset"]
#         if entity['Type'] in ['DATE','TIME','DATE_TIME','REDACTED']:
#             continue
#         print("entity type:", entity['Type'])
#         placeholder = f"<PII_{entity['Type']}_{len(pii_map)}>"
#         pii_map.append({"placeholder": placeholder, "value": redacted_text[start:end]})
#         redacted_text = redacted_text[:start] + placeholder + redacted_text[end:]

#     print("redacted text:", redacted_text)
#     return redacted_text, pii_map
def mask_pii_for_agent(input_text):
    print("masking the PIIs")
    response = comprehend.detect_pii_entities(Text=input_text, LanguageCode='en')
    redacted_text = input_text
    pii_map = {}
    print(response)
    for idx, entity in enumerate(sorted(response.get("Entities", []), key=lambda e: e["BeginOffset"], reverse=True)):
    # for entity in sorted(response.get("Entities", []), key=lambda e: e["BeginOffset"], reverse=True):
        start, end = entity["BeginOffset"], entity["EndOffset"]
        if entity['Type'] in ['DATE', 'TIME', 'DATE_TIME',  'URL', 'CREDIT_DEBIT_EXPIRY', 'MAC_ADDRES']:
            continue
        print("entity type:", entity['Type'])
        placeholder = f"<{idx}_PII_{entity['Type']}>"
        original_value = redacted_text[start:end]
        pii_map[placeholder] = original_value
        redacted_text = redacted_text[:start] + placeholder + redacted_text[end:]

    print("redacted text:", redacted_text)
    return redacted_text, pii_map


def build_agent_response(event, text):
    print("building agent response")
    print("detecting PIIs in response to give model for reasoning...")
    redacted_text, pii_map2 = mask_pii_for_agent(text)
    print("text resp before redacting pii:", text)
    print("text resp after redacting pii:", redacted_text)
    print("pii map:", pii_map2)
    # event.get("sessionAttributes", {}).update({"pii_map": str(pii_map2)})
    pii_map2 = json.dumps(pii_map2)
    pii_maps_ssm= os.environ['PII_MAPS']
    ssm_put = ssm_client.put_parameter(
        Name= pii_maps_ssm,
        Description='this stores the PII mappings',
        Value=pii_map2,
        Type='String',
        Overwrite=True,
        DataType='text'
    )
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": event["actionGroup"],
            "function": event.get("function", ""),
            "functionResponse": {
                "responseBody": {
                    "TEXT": {
                        "body": redacted_text
                    }
                }
            },
        },
        "sessionAttributes": event.get("sessionAttributes", {}),
        "promptSessionAttributes": event.get("promptSessionAttributes", {})
    }

def Ingroup(grp_id, username):
    print("checking if user belongs to the accessed group")
    response = ddb_groups_table.get_item(
        Key={
                'GroupId': grp_id
            },
    )
    if response['Item']:
        group = response['Item']
        if username in group['Users']:
            return True
        else:
            return False
    else:
        return False

def IsAssigned(asset_id, user_name):
    print("checking if asset is assigned to the user")
    assigned_response = ddb_assigned_table.scan(
        FilterExpression=Attr('AssetId').eq(asset_id) & Attr('AssignmentStatus').eq('Active') 
    )
    print("assigned response", assigned_response)
    if assigned_response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
        return False

    item = assigned_response.get("Items")
    if item == []:
        return False
  
    item=item[0]
    print("item:", item)
   
    if item.get("HolderId") == user_name :
        print("asset belongs to the user")
        # event["parameters"] = [{"name": "AssetId", "value": asset_id}]
        return True
    elif item.get("HolderId").startswith("GRP_"):
        print("starting with grp")
        if Ingroup(item.get("HolderId"), user_name):
            return True   
    return False


def generate_temporary_password():
    """
    Generates a temporary password that meets AWS Cognito password requirements.
    
    Returns:
        str: A randomly generated password containing uppercase, lowercase, digits, and special characters.
        None: If an error occurs during password generation.
    """
    logger.info("Generating temporary password...")
    try:
        password=[
            random.choice(string.ascii_uppercase),
            random.choice(string.ascii_lowercase),
            random.choice(string.digits),
            random.choice(string.punctuation),
        ]
        characters=string.ascii_letters + string.digits + string.punctuation
        password += random.choices(characters, k=4)
        random.shuffle(password)
        return ''.join(password)
    except Exception as e:
        logger.error(f"Error generating temporary password: {e}")
        return None

def asset_agent_create(event, user_details):
    print("asset create agent called")
    try:
        user_name = user_details.get("username")
        params = {item['name']: item['value'] for item in event.get("parameters", [])}
        print("params:", params)

        item = params
        print(item)

        item["AssetId"] = str(uuid.uuid4())[:16]
        # item.setdefault("Metadata", None)

        required_fields = ['Type', 'Category', 'Cost', 'AssetName']
        for field in required_fields:
            if field in params:
                item[field] = params[field]
                print(f"{field} is given")
            else:
                return build_agent_response(event, f"Error: {field} is required")

        print(item)

        asset_type = item['Type'].lower()
        if asset_type == "physical":
            print("this is a physical asset, so")
            item.pop('Expiry', None)
            if not item.get('ServiceTime'):
                print("service time is not given")
                return build_agent_response(event, "Error: Service time is required for physical assets")
            if not item.get('SerialNumber'):
                print("serial number is not given")
                return build_agent_response(event, "Error: serial number is required for physical assets")

        elif asset_type == "digital":
            print("this is a digital asset, so")
            if item.get('Category').lower().startswith('api'):
                if not item.get('EncryptedKey'):
                    logger.warning("Encrypted Key for Digital Asset not found in request body")
                    return build_agent_response(event, "Error: Encrypted Key is required for digital assets")
            if item.get('SerialNumber'):
                item.pop('SerialNumber', None)
                print("digital asset cannot have serial number")
            if item.get('ServiceTime'):
                item.pop('ServiceTime', None)
                print("digital asset cannot have service time")
            if item.get('Expiry'):
                print(f"expiry is given. {item['Expiry']}")

            else:
                print("expiry is not given")
                return build_agent_response(event, "Error: Expiry is required for digital assets")
        
        created_time = str(datetime.datetime.now() + datetime.timedelta(hours=5, minutes=30))
        item.update({
            'CreatedBy': user_name,
            'LastModifiedBy': user_name,
            'CreatedAt': created_time,
            'LastModifiedAt': created_time,
            'AssetStatus': "Unassigned",
            'Method': 'POST'
        })

        print("item:", item)
        if item["Metadata"]:
            print(type(item["Metadata"]))
        myuuid= item["AssetId"]
        utc_time=datetime.datetime.now()
        offset= datetime.timedelta(hours=5,minutes=30)
        curr_time=str((utc_time+offset).strftime("%Y-%m-%d_%H:%M:%S.%f"))
        object_key = f"assets/{myuuid}/asset_{curr_time}.zip"
        bucket_name = os.environ.get('S3_BUCKET_NAME')
        item['Method'] = 'POST'

        put_url = generate_presigned_url(bucket_name,object_key,3600,item, 'put_object', event)
        print(put_url)

        return build_agent_response(event, json.dumps({
                "message": "upload the asset related files using this presigned_url. then the details will be added to database",
                "put_url": put_url
            }))
    except Exception as e:
        return build_agent_response(event, f"Error: {str(e)}")

def generate_presigned_url(bucket_name, object_key , expiration , item,method,event):
    item['ContentType'] = 'application/zip'
    print("generating presigned url...")
    try:
        params={
                'Bucket': bucket_name,
                'Key': object_key,
                'Metadata': item
        }
        print("params:", params)
        if method == 'put_object':
            item['ContentType'] = 'application/zip'
            if item:
                params['Metadata'] = {k: str(v) if v is not None else '' 
                                    for k, v in item.items()}
        response=s3_client.generate_presigned_url(
            ClientMethod='put_object',
            Params=params,
            ExpiresIn=expiration
        )
        print("generate url resp:", response)
        try:
            return build_agent_response(event, response)
        except Exception as e:
            print("error returning url:", e)
            return build_agent_response(event, f"Error: {str(e)}")
    except Exception as e:
        return build_agent_response(event, f"Error: {str(e)}")



def asset_agent_get(event, user_details):
    print("asset agent get")
    try:
        p = event.get("parameters", [])[0]
        if p['name'] == "AssetName":
            asset_name = p['value']
            print(asset_name)
            if user_details.get("role") == "User":
                print("user is asking for details.")
                response= ddb_asset_table.scan(
                    FilterExpression=Attr('AssetName').eq(asset_name), 
                    ProjectionExpression="AssetName, AssetStatus, AssetId,ServiceTime, Expiry, #type, Category,Metadata",
                    ExpressionAttributeNames={"#type": "Type"}
                )
            elif user_details.get("role") in ["Admin","Manager"]:
                response = ddb_asset_table.scan(
                    FilterExpression=Attr('AssetName').eq(asset_name),
                    ProjectionExpression="AssetName, AssetStatus, AssetId,ServiceTime, Expiry, #type, Category,Metadata, CreatedAt, CreatedBy,LastModifiedAt, LastModifiedBy,Cost, #location, SerialNumber",
                    ExpressionAttributeNames={"#type": "Type", "#location": "Location"}
                )
            print("response:", response)
            item = response.get("Items",[])
            print("item:", item)
            if not item:
                print("no item found")
                return build_agent_response(event, "No item found with the given AssetName")
        elif p['name'] == "AssetId":
            print("asset_id is being sent")
            asset_id = p['value']
            if user_details.get("role") == "User":
                response = ddb_asset_table.get_item(
                    Key={
                        'AssetId': asset_id
                    },
                    ProjectionExpression="AssetName, AssetStatus, AssetId,ServiceTime, Expiry, #type, Category,Metadata",
                    ExpressionAttributeNames={"#type": "Type"}
                )
                print("details from asset table for user:", response)
            elif user_details.get("role") in ["Admin","Manager"]:
                response = ddb_asset_table.get_item(
                    Key={
                        'AssetId': asset_id
                    }
                )

            if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
                return build_agent_response(event,"Item could not be obtained")

            item = response.get("Item")
            if item.get('Type') == 'Digital' and item.get('Category') == 'API Key':
                        encrypted_key = ssm_client.get_parameter(
                            Name=f"/assets/{id}/key",
                            WithDecryption=True
                        )['Parameter']['Value']
                        logger.info(f"Encrypted key for asset {id} is {encrypted_key}")
                        item['EncryptedKey'] = encrypted_key
            if not item:
                return build_agent_response(event,"No item found with the given AssetID")

        return build_agent_response(event, json.dumps(item))

    except Exception as e:
        return build_agent_response(event, f"Error: {str(e)}")

def asset_agent_get_all(event, user_details):
    try:
        print("db scanning...")
        response = ddb_asset_table.scan(
                    ProjectionExpression="AssetName, AssetStatus, AssetId,ServiceTime, Expiry, #type, Category,Metadata, CreatedAt, CreatedBy,LastModifiedAt, LastModifiedBy,Cost, #location, SerialNumber",
                    ExpressionAttributeNames={"#type": "Type", "#location": "Location"}
                )
        print("db scanned")
        print(response)
        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Items could not be obtained")

        # string_response = ""
        # for item in response.get("Items", []):
        #     for key in item:
        #         string_response += f"{key}: {item[key]}, "
        #     string_response += "\n"
        # return build_agent_response(event, string_response)
        return build_agent_response(event, json.dumps(response.get("Items", [])))
    except Exception as e:
        return build_agent_response(event, str(e))

def asset_agent_update(event, user_details):
    print("asset update agent called")
    asset_id=""
    print(len(event.get("parameters", "")))
    for i in range(len(event.get("parameters", ""))):
        print(i)
        if event.get("parameters", "")[i]['name']=='AssetId':
            print("getting the asset id")
            asset_id = event.get("parameters", "")[i]['value']
            print('asset id: ', asset_id)
            break
    logger.info(f"Updating asset for asset: {asset_id}")
        
    # perform = event.get('sessionAttributes', {}).get('query_params', {})
    # perform =(json.loads(perform)).get('perform', "")
    # print("perform:", perform)
    # if perform == 'image-upload':
    #     logger.info(f"Uploading image")
    #     object_key = f"{asset_id}/asset/asset_{curr_time}.zip"
    #     put_url = generate_presigned_url(bucket_name, object_key, 3600,{})

    #     return {
    #         'statusCode' : 200,
    #         'body' : json.dumps({
    #             'put_url' : put_url
    #         })
    #     }
    # else:
    try:
        asset_updates = {}
        params={}
        for param in event.get("parameters", []):
            params[param['name']] = param['value']
        print(params)
        try:
            logger.info(f"Fetching asset details from database")
            asset = ddb_asset_table.get_item(
                Key = {
                    'AssetId' : asset_id
                }
            )
            # print(asset)
        except Exception as e:
            logger.error(f"DynamoDB GET operation failed with response: json.dumps({e.response['Error']['Message']})")
            return build_agent_response(event, json.dumps({e.response['Error']['Message']}))
        if not asset:
            logger.warning(f"Asset {id} does not exist")
            return build_agent_response(event, f"Asset {asset_id} does not exist")

        logger.info(f"Asset details fetched successfully")
        asset = asset.get('Item')

        utc_time=datetime.datetime.now()
        offset= datetime.timedelta(hours=5,minutes=30)
        curr_time=str((utc_time+offset).strftime("%Y-%m-%d %H:%M:%S.%f"))
        asset_updates["LastModifiedBy"] = {"Value": user_details.get('username'), "Action": "PUT"}
        asset_updates["LastModifiedAt"] = {"Value": curr_time, "Action": "PUT"}
        if "AssetName" in params:
            asset_updates["AssetName"] = {"Value": params.get("AssetName"), "Action": "PUT"}
        if "Cost" in params:
            asset_updates["Cost"] = {"Value": str(params.get("Cost")), "Action": "PUT"}
        if "Expiry" in params:
            asset_updates["Expiry"] = {"Value": str(params.get("Expiry")), "Action": "PUT"}
        if "ServiceTime" in params:
            asset_updates["ServiceTime"] = {"Value":str(params.get("ServiceTime")), "Action": "PUT"}
        if "location" in params:
            asset_updates["Location"] = {"Value": params.get("location"), "Action": "PUT"}
        existing_metadata=""
        new_metadata=""
        merged_metadata={}
        if "Metadata" in params:
            existing_metadata= asset.get("Metadata")
            print("existing metadata:", existing_metadata)
            new_metadata = params.get("Metadata")
            print("new metadata:", new_metadata)
            print( existing_metadata.update(new_metadata))
            if isinstance(new_metadata, dict) and isinstance(existing_metadata, dict):
                merged_metadata = {**existing_metadata, **new_metadata}
            asset_updates["Metadata"] = {"Value": merged_metadata, "Action": "PUT"}
        print("asset updates:", asset_updates)
        try:
            logger.info(f"Updating asset details in database")
            if params.get('AssetStatus'):
                if params.get('AssetStatus' , '') == 'Assigned':
                    return build_agent_response(event, 'Cannot assign asset here. Use /assigned/POST')
                
                elif params.get('AssetStatus' , '') == 'Unassigned':
                    latest_assignment = ddb_assigned_resource.query(
                        IndexName='AssetId-index',
                        KeyConditionExpression='AssetId = :asset_id',
                        ExpressionAttributeValues={
                            ':asset_id': asset_id
                        },
                        ScanIndexForward=False,
                        Limit = 1
                    )

                    if 'Items' in latest_assignment:
                        latest_assignment = latest_assignment.get('Items')
                        if latest_assignment[0].get('AssignedStatus') == 'Active':
                            ddb_assigned_resource.update_item(
                                Key={"AssignmentId": latest_assignment[0].get('AssignmentId')},
                                AttributeUpdates={
                                    "AssignedStatus": {"Value": "Inactive", "Action": "PUT"}
                                }
                            )
            print("asset updates:", asset_updates)        
            res = ddb_asset_table.update_item(Key={'AssetId': asset_id}, AttributeUpdates=asset_updates)

            return build_agent_response(event, f'Asset updated successfully by: {user_details.get('username')}')

        except Exception as e:
            logger.error(f"DynamoDB UPDATE operation failed with response: {e.response['Error']['Message']}")
            return build_agent_response(event, f'DynamoDB UPDATE operation failed with response: {e.response['Error']['Message']}')

    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return build_agent_response(event, f"Unexpected error: {str(e)}")

def issue_agent_create(event, user_details):
    try:
        print("issue getting registered")
        username=user_details.get("username")
        item = {}
        item['AssetId']=event.get('parameters')[1].get('value')   
        item['IssueId']=str(uuid.uuid4())[:16]
        item['IssueDescription']=event.get('parameters')[0].get('value') 
        item['CreatedBy'] = username

        createdTime = str(datetime.datetime.now() + datetime.timedelta(hours=5, minutes=30))
        item["CreatedAt"]=createdTime
        item["LastModifiedAt"]=createdTime
        item["LastModifiedBy"]=username
        item["IssuePriority"]="low"
        item["IssueStatus"]="pending"
        item["DeleteRequest"]="False"
        print(item)

        # response = ddb_issue_table.put_item(Item=item)
        # print(response)
        # if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
        #     return build_agent_response(event, "Item could not be added")
        issue_id= item["IssueId"]
        asset_id= item['AssetId']
        utc_time=datetime.datetime.now()
        offset= datetime.timedelta(hours=5,minutes=30)
        curr_time=str((utc_time+offset).strftime("%Y-%m-%d %H:%M:%S.%f"))
        object_key = f"issues/{asset_id}/{issue_id}/issue_{curr_time}.zip"
        bucket_name = os.environ.get('S3_BUCKET_NAME')
        item["httpmethod"]='POST'
        put_url = generate_presigned_url(bucket_name,object_key,3600,item, 'put_object', event)
        print(put_url)

        return build_agent_response(event, json.dumps({
                "message": "upload the asset related files using this presigned_url. then the details will be added to database",
                "put_url": put_url
            }))

        return build_agent_response(event, "Item added successfully")
    except Exception as e:
        return build_agent_response(event, str(e))

def issue_agent_get_by_id(event, user_details):
    try:
        issue_id = event.get("parameters", "")[0]['value']
        response = ddb_issue_table.get_item(
            Key={
                'IssueId': issue_id
            }
        )

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Item could not be obtained")

        item = response.get("Item", {})
        string_response = ", ".join([f"{k}: {v}" for k, v in item.items()])
        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))
    
def issue_agent_get_by_asset(event, user_details, asset_id):
    try:
        print("getting asset first...")
        asset_retired =False
        asset_response = ddb_asset_table.get_item(
                            Key = {
                                'AssetId' : asset_id
                            }
                        )
        print(asset_response)
        if asset_response.get('Item')==None:
            logger.info("No asset with that asset id")
            return build_agent_response(event, "No asset with that asset id")

        if asset_response.get('Item', '').get('AssetStatus')=='Retired':
            asset_retired=True
            logger.info("Asset is retired")

        if asset_retired and user_details.get('role')== 'User':
            print("asset is retired. you cannot get the issue details of it")
            return build_agent_response(event, "Asset is retired. you cannot get the issue details of it")

        print("getting the issues of the asset...") 
      
        response = ddb_issue_table.query(
            IndexName='AssetId-CreatedBy-index',
            KeyConditionExpression='AssetId = :asset_id',
            ExpressionAttributeValues={
                ':asset_id': asset_id  
            }
        )
        print("issues of the asset:", response)

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode")!= 200:
            return build_agent_response(event, "Item could not be obtained")

        string_response = ""
        for item in response.get("Items", []):
            string_response += ", ".join([f"{k}: {v}" for k, v in item.items()]) + "\n"
        print("string response:", string_response)
        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))
   
def issue_agent_get_all(event, user_details):
    try:
        print("getting the issues...")
        response = ddb_issue_table.scan(
            ProjectionExpression="IssueID, AssetID, IssueDescription, IssueStatus"
        )
        print("all issues: ", response)

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Items could not be obtained")

        string_response = ""
        for item in response.get("Items", []):
            string_response += ", ".join([f"{k}: {v}" for k, v in item.items()]) + "\n"
        
        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))


def issue_agent_update(event, user_details, issue_id,asset_id):
    try:
        # issue_id=""
        # for i in range(len(event.get("parameters", ""))):
        #     if event.get("parameters", "")[i]['name']=='IssueId':
        #             print("getting the issue id")
        #             issue_id = event.get("parameters", "")[i]['value']
        #             print('issue id: ', issue_id)
        # asset_id= ddb_issue_table.get_item(
        #     Key={
        #         'IssueId': issue_id
        #     }
        # ).get("Item").get("AssetId")
        # print("asset_id:", asset_id)

        print("Received event:", json.dumps(event))
        print("role of the user: ", user_details.get('role'))
        
        parameters = {p['name']: p['value'] for p in event.get('parameters', [])}
        print("Parameters:", parameters)
        if parameters.get('DeleteRequest'):
            if parameters['DeleteRequest'].lower()=='true':
                parameters['DeleteRequest']==1
            elif parameters['DeleteRequest'].lower()=='false':
                parameters['DeleteRequest']==0
        
        issue_id = parameters.get('IssueId')
        if not issue_id:
            print("Error: IssueId is required")
            return build_agent_response(event, "Error: IssueId is required")
            
        response = ddb_issue_table.get_item(Key={'IssueId': issue_id})
        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200 or 'Item' not in response:
            print("Item not found in issues table")
            return build_agent_response(event, "Item could not be obtained")

        existing_item = response['Item']
        print("Existing item:", existing_item)
        
        if parameters.get('DeleteRequest') and user_details.get('role') in ['Manager', 'Admin']:
            print("Admin/Manager cannot change delete request")
            return build_agent_response(event, "Admin or manager cannot change a delete request")
            
        if parameters.get('DeleteRequest') == 1 and existing_item.get('DeleteRequest') == 1:
            print("Delete request already exists")
            return build_agent_response(event, "Delete request already raised")

        utc_time = datetime.datetime.now()
        offset = datetime.timedelta(hours=5, minutes=30)
        curr_time = str((utc_time + offset).strftime("%Y-%m-%d %H:%M:%S.%f"))
        
        update_expression = "SET LastModifiedBy = :LastModifiedBy, LastModifiedAt = :LastModifiedAt"
        expression_attributes = {
            ":LastModifiedBy": user_details.get('username'),
            ":LastModifiedAt": curr_time
        }

        if user_details.get('role') in ['Admin','Manager']:
            for field in [ 'Notes', 'IssueStatus', 'IssuePriority']: #admin
                if field in parameters:
                    update_expression += f", {field} = :{field}"
                    expression_attributes[f":{field}"] = parameters[field]
            for p in range(len(event.get("parameters", ""))):
                if event.get("parameters", "")[p].get('name') == 'IssueDescription' or event.get("parameters", "")[p].get('name') == 'DeleteRequest':
                    if not IsAssigned(asset_id, user_details.get('username')):
                        return build_agent_response(event, "Admin or manager cannot change this field") 


        if user_details.get('role') == 'User':
            for field in ['IssueDescription', 'DeleteRequest']:
                if field in parameters:
                    update_expression += f", {field} = :{field}"
                    expression_attributes[f":{field}"] = parameters[field]
            for p in range(len(event.get("parameters", ""))):
                if event.get("parameters", "")[p].get('name') == 'Notes' or event.get("parameters", "")[p].get('name') == 'IssueStatus' or event.get("parameters", "")[p].get('name') == 'IssuePriority':
                    print("user cannot change this field: issuestatus or notes")
                    return build_agent_response(event, "user cannot change this field") 

        print("Update expression:", update_expression)
        print("Expression attributes:", expression_attributes)
        
        ddb_issue_table.update_item(
            Key={'IssueId': issue_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attributes
        )
        
        print("Update successful")
        if parameters.get('DeleteRequest') == 1:
            return build_agent_response(event, "Delete request raised successfully")
        return build_agent_response(event, "Update successful")
    # parameters= event.get("parameters", "")
    # print(parameters)
    # params={}
    # for p in parameters:
    #     params[p.get('name')]= p.get('value')
    # print(params)
    # body=json.loads(params)
    # # print(body)
    # #to check if delete-request raised for the already existing delete request
    # item=dynamodb.get_item(
    #     TableName=table_name,
    #     Key={
    #         "IssueId":{"S":id}
    #     }
    # )
    # print(item)
    # if body.get("DeleteRequest") and user_details['role'] in ['Manager', 'Admin']:
    #     logger.warning("Admin or Manager cannot edit a delete request")
    #     return build_agent_response(event, "Admin or manager cannot change a delete request")

    # if body.get('DeleteRequest')=="1" and item.get('Item').get('DeleteRequest').get('N', "")=="1" :
    #     logger.warning("Delete request is already raised")
    #     return build_agent_response(event, "Delete request already raised")

    
    # utc_time=datetime.datetime.now()
    # offset= datetime.timedelta(hours=5,minutes=30)
    # curr_time=str((utc_time+offset).strftime("%Y-%m-%d %H:%M:%S.%f"))
    # expression=["LastModifiedBy = :LastModifiedBy","LastModifiedAt = :LastModifiedAt"]
    # #update user to the current logged in user
    # attributes={":LastModifiedBy":{"S":user_details.get('username')},":LastModifiedAt":{"S":curr_time}}

    # #To check user is updating anything other than delete-request
    # user_flag=True
    # admin_flag=True

    # for text in body:
    #     if text!='DeleteRequest' and text!="IssueDescription":
    #         user_flag=False
    #     if text=='AssetId' or text=='DeleteRequest' or text=='IssueDescription':
    #         logger.info(item)
    #         if text=='IssueDescription':
    #             if item.get('Item').get('RaisedBy').get('S')==user_details.get('username'):
    #                 admin_flag=True
    #         else:
    #             admin_flag=False
    #     column = text[0].upper() + text[1:]
    #     temp = f":{column}"
    #     expression.append(f"{column}={temp}")
    #     if text=='DeleteRequest':
    #         attributes[temp]={"N": body[text]}
    #     else:
    #         attributes[temp]={"S": body[text]}
    # update_expression="SET "+", ".join(expression)
    # try: 
    #     if user_details.get('role') in ['Admin','Manager']:
    #         if admin_flag:
    #             response=dynamodb.update_item(
    #                 TableName=table_name,
    #                 Key={
    #                     "IssueId":{"S":id}
    #                 },
    #                 UpdateExpression=update_expression,
    #                 ExpressionAttributeValues=attributes
    #             ) 
    #             if body.get("IssueStatus")=='Resolved':
                    
    #                 #to notify the user who raised the issue
    #                 user = item.get('Item').get('RaisedBy').get('S')
    #                 response = dynamodb.get_item(
    #                     TableName='UsersTable',
    #                     Key={'Username': {'S': user}}, 
    #                     ProjectionExpression='Email'
    #                 )
    #                 user_email = response['Item']['Email']['S']
    #                 message = f"Issue is resolved"
    #                 res = ses_client.send_email(
    #                     Source=sender_email,
    #                     Destination={'ToAddresses': [user_email]},
    #                     Message={
    #                         'Subject': {'Data': 'Issue Notification'},
    #                         'Body': {
    #                             'Text': {'Data': message},
    #                         }
    #                     }
    #                 )
    #             logger.info("Issue details updated")
    #             return build_agent_response(event, "Issue details updated")

            
    #         else:
    #             logger.warning("Cannot update AssetId or Delete Request")
    #             return build_agent_response(event, "Cannot update AssetId or Delete Request")

    #     elif user_details.get('role')=='User':
    #         if user_flag:
    #             if item.get('Item').get('RaisedBy').get('S', "")!= user_details['username']:
    #                 logger.warning("Cannot edit other's issues")
    #                 return build_agent_response(event, "you cannot update other's issues")

    #             response=dynamodb.update_item(
    #                 TableName=table_name,
    #                 Key={
    #                     "IssueId":{"S":id}
    #                 },
    #                 UpdateExpression=update_expression,
    #                 ExpressionAttributeValues=attributes
    #             )
    #             logger.info("Issue updated")

    #             #send mail to admin
    #             if body.get('DeleteRequest'):
    #                 message=f"Issue delete requested by user: {user_details.get('username')}"
    #                 response = ses_client.send_email(
    #                     Source=sender_email,
    #                     Destination={
    #                         'BccAddresses': admin_emails
    #                     },
    #                     Message={
    #                         'Subject': {'Data': 'Issue Delete Request Notification'},
    #                         'Body': {
    #                             'Text': {'Data': message},
    #                         }
    #                     }
    #                 )
    #             return build_agent_response(event, "Issue updated")

    #         else:
    #             logger.warning("Cannot update these details")
    #             return build_agent_response(event, "Cannot update these details")
    
    except Exception as e:
        print("Error:", str(e))
        return build_agent_response(event, str(e))

def create_assignment(event,user_details):
    print("creating the assignment...")
    try:
        params = {}
        user_name = user_details.get("username")  
        print("username:", user_name)      

        assignment_ID= str(uuid.uuid4())[:16]
        assignment_item = {
            'AssignmentId': assignment_ID,
            'CreatedBy':  user_name,
            'CreatedAt': str(datetime.datetime.now() + datetime.timedelta(hours=5, minutes=30)),
            'AssignmentStatus': "Active"
        }
        assignment_item['HolderId']=event.get('parameters', "")[0].get('value')
        assignment_item['AssetId'] =event.get('parameters', "")[1].get('value')
        assets_response= ddb_asset_table.get_item(Key={'AssetId': assignment_item['AssetId']})
        print("assignment_item: ", assignment_item)
        print("assets respoinse:", assets_response)
        if assets_response.get("Item", "").get('AssetStatus')=='Assigned':
            return build_agent_response(event, "Asset is already assigned to someone else")
        try:
            response = ddb_assigned_table.put_item(Item=assignment_item)
            ddb_asset_table.update_item(
                Key={'AssetId': assignment_item['AssetId']},
                UpdateExpression="SET AssetStatus = :status",
                ExpressionAttributeValues={":status": "Assigned"}
            )
        except Exception as e:
            print(e)
            return build_agent_response(event, "Item could not be added")
        

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Item could not be added")

        return build_agent_response(event, "Item added successfully")

    except Exception as e:
        print(e)
        return build_agent_response(event, str(e))

def get_all_assignments(event, user_details):
    try:
        response = ddb_assigned_table.scan()

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Items could not be obtained")

        string_response = ""
        for item in response.get("Items", []):
            for key, value in item.items():
                string_response += f"{key}: {value}, "
            string_response += "\n"

        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))

def get_assignment_by_ID(event, user_details):
    try:
        print("started")
        assignment_id = event.get("parameters", "")[0]['value']
        print("assignment_id:", assignment_id)
        try:
            response = ddb_assigned_table.get_item(
                Key={
                    'AssignmentId': assignment_id
                }
            )
            print("response:", response)
        except Exception as e:
            print(e)
            return build_agent_response(event, "issue in getting the details")

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Item could not be obtained")

        item = response.get("Item")
        if not item:
            return build_agent_response(event, "No assignment found with the given ID")

        string_response = ""
        for key, value in item.items():
            string_response += f"{key}: {value}, "

        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))

def get_assignment_by_assetID(event, user_details):
    try:
        asset_id = event.get("parameters", "")[0]['value']
        try:
            response = ddb_assigned_table.query(
                IndexName="AssetId-index",
                KeyConditionExpression=Key('AssetId').eq(asset_id)
            )
            print(response)
        except Exception as e:
            print(e)
            return build_agent_response(event, "Item could not be obtained")

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Item could not be obtained")

        items = response.get("Items", [])
       
        if not items:
            return build_agent_response(event, "No assignments found for the given Asset ID")

        string_response = ""
        for item in items:
            for key, value in item.items():
                string_response += f"{key}: {value}, "
            string_response += "\n"

        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))

def get_assignment_by_holderID(event, user_details):
    try:
        print(event)
        holder_id = event.get("parameters", "")[0]['value']
        try:
            response = ddb_assigned_table.query(
                IndexName="HolderId-index",
                KeyConditionExpression=Key('HolderId').eq(holder_id)
            )
            
        except Exception as e:
            
            return build_agent_response(event, "Item could not be obtained")
        if response['ResponseMetadata']['HTTPStatusCode'] != 200:
            return build_agent_response(event, "Item could not be obtained")

        string_response = ""
        for item in response.get("Items", []):
            for key in item:
                string_response += f"{key}: {item[key]}, "
            string_response += "\n"
        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))

def agent_create_group(event, user_details, params):
    logger.info(f"Creating group")
    try:
        print("authorized to create a group...")
        group_name = params.get("GroupName", "")
        users = params.get("Users", "")
        print(users)
        users = users.split(',')  

        print(group_name, users)
        created_time = datetime.datetime.now()
        offset = datetime.timedelta(hours=5, minutes=30)
        created_time = str(created_time + offset)
        id = f"GRP_{str(uuid.uuid4())[:12]}"
        print("group id: ", id)
        grp_type = params.get("Type", "")
        lead = params.get("Lead", "")
        if grp_type == 'Team':
            if lead == '':
                return build_agent_response(event, "Lead cannot be empty")
                
            lead_user = ddb_users_table.get_item(
                Key = {
                    "UserName" : lead
                }
            ).get('Item' , {})

            if not lead_user:
                return build_agent_response(event, "Lead username not found")

            if lead_user.get('Status') == 'Inactive':
                return build_agent_response(event, "Lead user is an inactive now")

            if lead not in users:
                users.append(lead)

        logger.debug(f"Group name: {group_name}")

        users_map = {}
        not_in_sys = ""
        print("before for loop")
        for user in users:
            print("in for loop:", user)
            try:
                sys_user = ddb_users_table.get_item(Key={
                    "UserName":  user
                }).get("Item", {})
            except Exception as e:
                print(e)
                return build_agent_response(event, "Item could not be obtained")
            print(sys_user)
            if not sys_user:
                print("user not in system")
                not_in_sys = not_in_sys + user + ", "
                continue
            print(f"{user} in the system")
            users_map[user] = {"AddedAt" : created_time , "AddedBy" : user_details.get('username')}
            group_list = sys_user.get("Groups", [])
            append_grp= group_list.append(id)
            print(append_grp)
            print("group list of the user:", group_list)
            ddb_users_table.update_item(
                Key = {
                    "UserName" : user
                },
                UpdateExpression="SET #groups = :groups",
                ExpressionAttributeValues={
                    ":groups": [str(g) for g in group_list]
                },
                ExpressionAttributeNames={
                    "#groups" : "Groups"
                }
            )

        group = {
            "GroupId": id,
            "GroupName":  group_name,
            "Users":users_map,
            "Type" : grp_type,
            "Lead" : lead,
            "CreatedAt": created_time,
            "CreatedBy": user_details.get('username'),
            "LastModifiedAt": created_time,
            "LastModifiedBy": user_details.get('username')
        }
        print(f"{group} is being added to the system")

        try:
            print("craeting group")
            res = ddb_groups_table.put_item(Item=group)
            logger.debug(f"Group creation response: {res}")
        except Exception as e:
            print(e)
            return build_agent_response(event, "Group could not be created")
        message = f"Group created successfully. {not_in_sys} are not registered users" if not_in_sys else "Group created successfully"
        return build_agent_response(event, message)

    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return build_agent_response(event, f"Unexpected error: {str(e)} ")

def agent_get_group(event, user_details):
    try:
        group_id = event.get("parameters", "")[0]['value']
        response = ddb_groups_table.get_item(
            Key={
                'GroupId': group_id
            }
        )

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Item could not be obtained")

        item = response.get("Item")
        if not item:
            return build_agent_response(event, "No item found with the given GroupID")

        string_response = ", ".join([f"{k}: {v}" for k, v in item.items()])
        return build_agent_response(event, string_response)
    except Exception as e:
        return build_agent_response(event, str(e))

def agent_get_all_groups(event, user_details):
    try:
        response = ddb_groups_table.scan()

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Items could not be obtained")

        string_response = ""
        for item in response.get("Items", []):
            for key in item:
                string_response += f"{key}: {item[key]}, "
            string_response += "\n"

        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))

def agent_update_group(event, user_details, params):
    logger.info(f"Updating group")
    try:
        grp_id = params.get("GroupId", "")
        add= params.get("Add", "")
        users= params.get("Users", "")
        print(grp_id, add, users)
        if not grp_id:
            logger.error("Group ID not provided")
            raise Exception("Group ID is required")

        user_list = users.split(',') 
        print("users list:", user_list)
        modifiedAt = datetime.datetime.now()
        offset = datetime.timedelta(hours=5, minutes=30)
        modifiedAt = str(datetime.datetime.now() + offset)

        old_group = ddb_groups_table.get_item(Key={
            "GroupId": grp_id
        }).get("Item", {})

        if not old_group:
            logger.warning(f"Group not found")
            raise ValueError("Group not found")

        old_users = old_group.get('Users')
            
        new_list = {}
        not_in_sys = ""
        not_in_list = ""
        removed_users = ""
        logger.debug(f"List of old users : {old_users}")
        logger.debug(f"New list of users for updation")
        
        grp_type = params.get('Type' , '')
        lead = params.get('Lead' , '')
        groupName= params.get('GroupName', '')
        if grp_type == 'Team':
            if lead == '':
                logger.error("Lead cannot be empty")
                return build_agent_response(event, "Lead user cannot be empty")

        if lead:
            lead_user = ddb_users_table.get_item(
                Key = {
                    "UserName" : lead
                }
            ).get('Item', {})
            print("lead user details:", lead_user)
            if not lead_user:
                return build_agent_response(event, "Lead username not found")

            if not lead_user.get('UserStatus') == 'Active':
                logger.error("Lead is inactive")
                return build_agent_response(event, "Lead user is currently inactive")
            
            if lead_user.get('Type') == 'External':
                return build_agent_response(event, "an external user cannot be a Lead user ")

        if add.lower() == 'false':
            logger.info(f"Removing users")
            for user in user_list:
                sys_user = ddb_users_table.get_item(Key={
                    "UserName": user
                }).get("Item", {})
                if not sys_user:
                    print(f"{user} not in system")
                    not_in_sys = not_in_sys + user + ", "
                    continue
                if user in old_users:
                    if old_group.get('Type') == 'Team' and old_group.get('Lead') == user and user == old_group.get('Lead'):
                        return build_agent_response(event, "Lead cannot be removed")
                    removed_users = removed_users + user + ", "
                    old_users.pop(user)
                    print("updated users list:", old_users)
                    group_list = sys_user.get('Groups' , [])
                    print("group list:", group_list)
                    if len(group_list):
                        group_list.remove(grp_id)
                        ddb_users_table.update_item(
                            Key = {
                                "UserName" : user
                            },
                            UpdateExpression="SET #groups = :groups",
                            ExpressionAttributeValues={
                                ":groups": group_list
                            },
                            ExpressionAttributeNames={
                                "#groups" : "Groups"
                            }
                        )
                else:
                    not_in_list = not_in_list + user + ", "

            group_updates = {}        
            if groupName:
                group_updates['GroupName'] = {"Value" : groupName , "Action" : "PUT"}
            if grp_type:
                group_updates['Type'] = {"Value" : grp_type , "Action" : "PUT"}
            if lead:
                group_updates['Lead'] = {"Value" : lead , "Action" : "PUT"}
            
            group_updates['Users'] = {"Value" : old_users , "Action" : "PUT"}
            res = ddb_groups_table.update_item(Key={
                "GroupId": grp_id
            }, UpdateExpression="SET #userlist = :users , LastModifiedAt = :modTime", ExpressionAttributeValues={
                ":users": old_users,
                ":modTime": modifiedAt
            }
            , ExpressionAttributeNames={
                "#userlist": "Users"
            })

            logger.debug(f"Group updation response: {res}")

            message = f"{removed_users} removed successfully. {not_in_sys} are not registered users, {not_in_list} are not members for the group" if not_in_sys or not_in_list else "Users removed successfully"
            return build_agent_response(event, message)
            
        else:
            logger.info(f"Adding users")
            group_updates = {}
            if groupName:
                group_updates["GroupName"] = {"Value" : groupName , "Action" : "PUT"}

            if lead != '':
                if lead not in user_list:
                    user_list.append(lead)
                group_updates['Lead'] = {"Value" : lead , "Action" : "PUT"}

            if user_list:
                for user in user_list:
                    if user in old_users:
                        continue
                    sys_user = ddb_users_table.get_item(Key={
                        "UserName": user
                    }).get("Item", {})
                    print("system user:", sys_user)
                    if not sys_user:
                        print(f"{user} not in system")
                        not_in_sys = not_in_sys + user + ", "
                        continue
                    old_users[user] = {"AddedAt" : modifiedAt, "AddedBy" : user_details.get('username')}
                    group_list = sys_user.get('Groups' , [])
                    group_list.append(grp_id)
                    logger.info(f"updating list of groups in Users")
                    ddb_updated = ddb_users_table.update_item(Key={
                        "UserName": user
                    }, 
                    UpdateExpression="SET #groups = :groups", 
                    ExpressionAttributeValues={
                        ":groups": group_list
                    },
                    ExpressionAttributeNames={
                        "#groups": "Groups"
                    })
                    logger.debug(f"User update response: {ddb_updated}")
                group_updates["Users"] = {"Value" : old_users , "Action" : "PUT"}
        
            group_updates["LastModifiedAt"] = {"Value" : modifiedAt , "Action" : "PUT"}
            group_updates["LastModifiedBy"] = {"Value" : user_details.get('username') , "Action" : "PUT"}
            res = ddb_groups_table.update_item(Key={
                "GroupId": grp_id
            }, AttributeUpdates=group_updates)

            logger.debug(f"Group updation response: {res}")

            message = f"group updated successfully. {not_in_sys} are not registered users" if not_in_sys else "group updated successfully"

            return build_agent_response(event, message)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return build_agent_response(event, str(e))

def agent_get_user_by_role(event, user_details):
    try:
        role = event.get("parameters", "")[0]['value']
        response = ddb_users_table.scan(
            FilterExpression=Attr('role').eq(role),
            ProjectionExpression="username, group"
        )

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Items could not be obtained")

        string_response = ""
        for item in response.get("Items", []):
            for key in item:
                string_response += f"{key}: {item[key]}, "
            string_response += "\n"

        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))

def agent_user_details_update(event, user_details):
    print("updating user details")
    try:
        params = {}
        for param in event.get("parameters", ""):
            params[param['name']] = param['value']
        print("params:", params)
        user_name = params['UserName']
        print(user_name)
        user_updates={}
        user_details=[]
        if "Phone" in params:
            print("phone in params")
            user_updates["Phone"] = {"Value": params.get("Phone"), "Action": "PUT"}
            user_details.append({'Name': "phone_number", 'Value': user_updates["Phone"]["Value"]})
        if "Name" in params:
            print("name in params")
            user_updates["Name"] = {"Value": params.get("Name"), "Action": "PUT"}   
            user_details.append({'Name': "name", 'Value': user_updates["Name"]["Value"]})
        print(user_updates)  
        try:
            cognito_client.admin_update_user_attributes(
                    UserPoolId=USER_POOL_ID,
                    Username=user_name,
                    UserAttributes=user_details
            )   
        except Exception as e:
            print(e)
            return build_agent_response(event, str(e))  
        response = ddb_users_table.update_item(Key={'UserName': user_name}, AttributeUpdates=user_updates)


        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Item could not be updated")

        return build_agent_response(event, f"Details of the user : {user_name} have been updated successfully")

    except Exception as e:
        return build_agent_response(event, str(e))


def agent_get_all_users(event, user_details):
    try:
        response = ddb_users_table.scan()

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Items could not be obtained")

        string_response = ""
        for item in response.get("Items", []):
            for key in item:
                string_response += f"{key}: {item[key]}, "
            string_response += "\n"

        return build_agent_response(event, string_response)

    except Exception as e:
        return build_agent_response(event, str(e))

def agent_get_users_by_username(event, user_details):
    try:
        username = event.get("parameters", "")[0]['value']
        print(f"getting {username} details")
        response = ddb_users_table.get_item(
            Key={
                'UserName': username
            }
        )
        print("details of the user:", response)

        if response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
            return build_agent_response(event, "Item could not be obtained")

        item = response.get("Item")
        if not item:
            return build_agent_response(event, "No item found with the given username")

        string_response = ", ".join([f"{k}: {v}" for k, v in item.items()])
        return build_agent_response(event, string_response)
    except Exception as e:
        return build_agent_response(event, str(e))



def agent_get_by_commentid(event , user_details, comment_id):
    try:
        logger.info(f"Fetching comments")
        if not comment_id:
            logger.error(f"comment not found" , 400)
            return build_agent_response(event, f"comment not found")

        comment = ddb_comments_resource.get_item(Key={'CommentId': comment_id}).get('Item')

        if not comment:
            logger.error(f"comment not found", 400)
            return build_agent_response(event, f"comment not found")    

        return build_agent_response(event, json.dumps(comment))
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return build_agent_response(event, str(e))


def agnet_get_by_assetid(event , user_details, asset_id):
    try:
        asset = ddb_asset_table.get_item(Key={'AssetId': asset_id}).get('Item')
        if not asset:
            logger.warning(f"Asset does not exist")
            return build_agent_response(event, f"Asset does not exist")
        print("asset exists in the system and getting the comments for it...")
        comments = ddb_comments_resource.query(
            IndexName = 'AssetId-index',
            KeyConditionExpression = "AssetId = :a_id",
            ProjectionExpression = 'CommentId , #cmnt , CreatedBy, CreatedAt, LastModifiedBy, LastModifiedAt',
            ExpressionAttributeNames = {
                '#cmnt': 'Comment'
            },
            ExpressionAttributeValues = {
                ':a_id' : asset_id
            },
            ScanIndexForward=False
        ).get('Items', [])
        print("comments:", comments)
        if not comments:
            logger.warning(f"No comments found for the asset")
            return build_agent_response(event, f"No comments found for the asset")
        print("comments found for the asset:", comments)
        return build_agent_response(event, json.dumps(comments))
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return build_agent_response(event, str(e))

def agent_create_comment(event, user_details, params):
    try:
        print("adding your comment...")
        asset_id=params.get('AssetId')
        asset = ddb_asset_table.get_item(
            Key = {
                'AssetId' : asset_id
            }
        ).get('Item')
        if not asset:
            logger.error("Asset not found" , 400)
            return build_agent_response(event, f"asset not found")

        ddb_comments_resource.put_item(
            Item = {
                'CommentId' : str(uuid.uuid4())[:16],
                'AssetId' : asset_id,
                'Comment' : params.get('Comment'),
                'CreatedBy' : user_details.get('username'),
                'CreatedAt' : str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
            }
        )
        print("comment is added")
        return build_agent_response(event, f"Comment created successfully")
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return build_agent_response(event, str(e))

def agent_update_comment(event, user_details, params):
    try:
        print("updating the comment")
        comment_id = params.get('CommentId')
        updated_comment = params.get('Comment')
        print(comment_id, updated_comment)
        if not updated_comment:
            logger.error(f"updated_comment not found", 400)
            return build_agent_response(event, f"updated_comment not found")

        comment = ddb_comments_resource.get_item(
            Key = {
                'CommentId' : comment_id
            }
        ).get('Item')
        if not comment:
            logger.error("Comment not found", 400)
            return build_agent_response(event, f"Comment not found")
        print("comment:", comment)
        if comment.get('CreatedBy') != user_details.get('username'):
            logger.error(f"Comment not created by {user_details.get('username')}", 400)
            return build_agent_response(event, f"Comment not created by you. so cannot update")

        update_comment=ddb_comments_resource.update_item(
            Key = {
                'CommentId' : comment_id
            },
            UpdateExpression = "SET #cmnt = :comment , LastModifiedBy = :lmb , LastModifiedAt = :lma",
            ExpressionAttributeNames = {
                '#cmnt': 'Comment'
            },
            ExpressionAttributeValues = {
                ':comment' : updated_comment,
                ':lmb' : user_details.get('username'),
                ':lma' : str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
            }
        )
        print("comment updated:", update_comment)
        
        return build_agent_response(event, f"Comment updated successfully")
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return build_agent_response(event, str(e))


def restore_pii(parameters, pii_map):
    restored_params = {}
    for key, val in parameters.items():
        if isinstance(val, str):
            for placeholder, real_value in pii_map.items():
                val = val.replace(placeholder, real_value)
        restored_params[key] = val
    return restored_params


def agent_report_asset(event, user_details, params, sender_email, admin_emails):
    user_name=user_details.get('username')
    asset_id=params.get('AssetId')
    utc_time=datetime.datetime.now()
    offset= datetime.timedelta(hours=5,minutes=30)
    curr_time=str((utc_time+offset).strftime("%Y-%m-%d %H:%M:%S.%f"))
    myuuid=str(uuid.uuid4())[:16]

    try:
        Item={
            'IssueId': myuuid,
            'IssueDescription': params.get('IssueDescription'),
            'CreatedBy': user_name,
            'CreatedAt': curr_time,
            'AssetId': asset_id,
            'LastModifiedBy': user_name,
            'LastModifiedAt': curr_time,
            'Report': 'Missing'
        }
        print("Item:", Item)
        dynamodb_response=ddb_issue_table.put_item(
            Item=Item
        )
        logger.info(f"Dynamodb response is: {dynamodb_response}")
        
        try:
            #sending mail to all admins about reported asset
            ses_response=ses_client.send_email(
                Source=sender_email,
                Destination={'ToAddresses': admin_emails},
                Message={
                    'Subject': {'Data': f"Asset reported missing"},
                    'Body': {'Text': {'Data': f"The asset with id: {asset_id} has been reported missing"}}
                }
            )
            logger.info(f"SES response is: {ses_response}")
        except Exception as e:
            logger.error("Error has occured while sending mail to admins")
            print("Error: ", str(e))

        return build_agent_response(event, "Issue reported successfully")
    except Exception as e:
        logger.error("Error has occured while reporting the issue", str(e))
        return build_agent_response(event, "Error has occured while reporting the issue:", str(e))

def lambda_handler(event, context):
    try: 
        print("event:", event)
        parameters = event.get("parameters", {})
        print("parameters:", parameters)
        original_pii_json = event.get("sessionAttributes", {}).get("original_pii", "[]")
        try:
            pii_map = json.loads(original_pii_json)
        except json.JSONDecodeError:
            pii_map = []
        # Extract parameters
        params = {p["name"]: p["value"] for p in event.get("parameters", [])}
        restored = restore_pii(params, pii_map)
        print(restored)
        event["parameters"]=[{"name": key, "type": "string", "value": str(value)} for key, value in restored.items()]
        print("event:", event)
        sessionAttributes=event.get("sessionAttributes", {})
        user_details=json.loads(sessionAttributes.get("user_details", {}))
        print("user_details: " , user_details)
        user_name=user_details.get('username')
        user_role=user_details.get('role')
        function_name = event.get("function", "")
        print("function name:", function_name)
        print(user_role)
        verified_mails=ses_client.list_verified_email_addresses()
        manager_response=ddb_users_table.query(
            IndexName='RoleName-index',
            KeyConditionExpression='RoleName = :role',
            ExpressionAttributeValues={':role': 'Manager'}, 
            ProjectionExpression='Email'
        )
        sender_email=manager_response.get('Items')[0].get('Email')
        logger.info(f"Sender Email: {sender_email}")
        sender_email= "noreply@cloudwick.com"
        admin_mails_response=ddb_users_table.query(
            IndexName='RoleName-index',
            KeyConditionExpression='RoleName = :role',
            ExpressionAttributeValues={':role': 'Admin'},
            ProjectionExpression='Email'
        )
        logger.info(f"Admin Query Response: {admin_mails_response}")
        admin_emails=[item.get('Email') for item in admin_mails_response['Items'] if item.get('Email') in verified_mails.get('VerifiedEmailAddresses')]
        logger.info(f"Admin Emails: {admin_emails}")
        print("checking all action groups")
        if function_name== "CurrentTime":  #working for manager, user
            return build_agent_response(event, str(datetime.datetime.now()))
        elif function_name == "CreateAsset":
            print("creating an asset....")
            if user_details and user_details.get("role") in ["Admin", "Manager"]:
                print("you have perms to create an asset")
                return asset_agent_create(event, user_details)
            else:
                
                return build_agent_response(event, "You are not authorized to perform this action.")
            
        elif function_name=="GetAsset":      #working for manager, user
            print("getting the asset details you asked for..")
            if user_details and user_details.get("role") in ["Admin", "Manager"]:
                return asset_agent_get(event, user_details)
            else:  #if user
            #check if the asset belongs to the user or not, then get it
                for p in event.get("parameters", []):
                    print(p)
                    if p['name'] == "AssetName":
                        asset_name = p['value']
                        print(asset_name)
                        try:
                            response= ddb_asset_table.scan(
                                FilterExpression=Attr('AssetName').eq(asset_name) & Attr('AssetStatus').eq("Assigned"), 
                                ProjectionExpression="AssetId"
                            )
                        except Exception as e:
                            return build_agent_response(event, "Item could not be obtained")
                        print("table scanned")
                    elif p['name'] == "AssetId":
                        asset_id = p['value']
                        print(asset_id)
                        response= ddb_asset_table.scan(
                            FilterExpression=Attr('AssetId').eq(asset_id) & Attr('AssetStatus').eq("Assigned"),
                            ProjectionExpression="AssetId"
                        )
                    print("response ", response)
                    for item in response.get("Items", []):
                        print("for each asset")
                        asset_id = item.get("AssetId")
                        print("asset_id", asset_id)
                        assigned_response = ddb_assigned_table.scan(
                            FilterExpression=Attr('AssetId').eq(asset_id) & Attr('AssignmentStatus').eq('Active') 
                        )
                        print("assigned response", assigned_response)
                        if assigned_response.get("ResponseMetadata", {}).get("HTTPStatusCode") != 200:
                            return build_agent_response(event, "Item could not be obtained")

                        item = assigned_response.get("Items")[0]
                        print("item:", item)
                        if not item:
                            return build_agent_response(event, "No assignment found with the given details")
                        if item.get("HolderId") == user_name :
                            print("asset belongs to the user")
                            event["parameters"] = [{"name": "AssetId", "value": asset_id}]
                            return asset_agent_get(event, user_details)
                        elif item.get("HolderId").startswith("GRP_"):
                            if Ingroup(item.get("HolderId"), user_name):
                                return asset_agent_get(event, user_details)   

                            
                return build_agent_response(event, "You are not authorized to perform this action.")
        
        elif function_name=="GetAllAssets":   #working for manager, user
            if user_details.get('role') not in ["Admin", "Manager"]:
                return build_agent_response(event, "You are not authorized to perform this action.")
            print("you have permissions to get all details of all assets")
            return asset_agent_get_all(event, user_details)

        elif function_name=="RegisterIssue":  #working for manager, user
            print("registering the issue")
            asset_id = event.get("parameters", "")[1]['value']
            if event.get("parameters", "")[1]['name']=="AssetId":
                print("getting the asset id")
                asset_id = event.get("parameters", "")[1]['value']
                print("asset_id", asset_id)
            else:
                return build_agent_response(event, "AssetId is required")
            print("checking the asset id")

            if IsAssigned(asset_id,user_name):
                print("asset is assigned to the user")
                return issue_agent_create(event, user_details)
            else:
                if user_details.get("role") in ['Admin', 'Manager']:
                    asset_status = ddb_asset_table.get_item(
                        Key={
                            'AssetId': asset_id
                        }
                    ).get("Item").get("AssetStatus")
                    if asset_status=='Unassigned':
                        return issue_agent_create(event, user_details)
                return build_agent_response(event, "You are not authorized to perform this action.")
            
        elif function_name=="GetIssuebyID": #working for manager, user
            #check for the asset id related to that issue id
            issue_id = event.get("parameters", "")[0]['value']
            asset_id = ddb_issue_table.get_item(
                Key={
                    'IssueId': issue_id
                }
            ).get("Item").get("AssetId")
            if user_details.get('role') not in ["Admin", "Manager"]:
                if IsAssigned(asset_id, user_name):
                    return issue_agent_get_by_id(event, user_details)
                else:
                    return build_agent_response(event, "You are not authorized to perform this action.")
            return issue_agent_get_by_id(event, user_details)

        elif function_name=="GetIssueByAssetId":   #working for manager, user
            asset_id = event.get("parameters", "")[0]['value']
            print(asset_id)
            if user_details.get('role') not in ["Admin", "Manager"]:
                if IsAssigned(asset_id, user_name):
                    return issue_agent_get_by_asset(event, user_details, asset_id)
                else:
                    return build_agent_response(event, "You are not authorized to perform this action.")
            print("getting the issue by asset id..")
            return issue_agent_get_by_asset(event, user_details, asset_id)
        
        elif function_name=="UpdateAsset":  #working for manager,user
            print("updating the asset")
            for i in range(len(event.get("parameters", ""))):
                print(i)
                if event.get("parameters", "")[i]['name']=='AssetId':
                    print("getting the asset id")
                    asset_id = event.get("parameters", "")[i]['value']
                    print('asset id: ', asset_id)
                    break
            print("updating the asset")
            if user_details.get('role') not in ['Admin', 'Manager']:
                # if IsAssigned(asset_id, user_name):
                #     return asset_agent_update(event, user_details)
                # else:
                #     return build_agent_response(event, "You are not authorized to perform this action.")
                return build_agent_response(event, "You are not authorized to perform this action.")
            return asset_agent_update(event, user_details)

        elif function_name=="GetAllIssues":  #working for manager,user
            if user_details.get('role') not in ["Admin", "Manager"]:
                return build_agent_response(event, "You are not authorized to perform this action.")
            return issue_agent_get_all(event, user_details)
        
        elif function_name=="UpdateIssue":   #working for manager, user
            issue_id=""
            for i in range(len(event.get("parameters", ""))):
                if event.get("parameters", "")[i]['name']=='IssueId':
                    print("getting the issue id")
                    issue_id = event.get("parameters", "")[i]['value']
                    print('issue id: ', issue_id)
            asset_id= ddb_issue_table.get_item(
                Key={
                    'IssueId': issue_id
                }
            ).get("Item").get("AssetId")
            print("asset_id:", asset_id)

            if user_details.get('role') not in ["Admin", "Manager"]:
                if IsAssigned(asset_id, user_name):
                    print("updating the issue")
                    return issue_agent_update(event, user_details, issue_id,asset_id)
                else:
                    return build_agent_response(event, "You are not authorized to perform this action.")
            print("updating the issue")
            return issue_agent_update(event, user_details, issue_id,asset_id)


        elif function_name=="CreateAssignment":   #working for manager, user
            print("Routing to create_assignment()")
            if user_details.get('role') not in ["Admin", "Manager"]:
                return build_agent_response(event, "You are not authorized to perform this action.")
            return create_assignment(event, user_details)

        elif function_name=="GetAllAssignments":  #working for manager,user
            if user_details.get('role') not in ["Admin", "Manager"]:
                return build_agent_response(event, "You are not authorized to perform this action.")
            return get_all_assignments(event, user_details)

        elif function_name=="GetAssignmentById":  #working for manager, user
            print("fetching assignment details by its id")
            if user_details.get('role') not in ["Admin", "Manager"]:
                assigned_res= ddb_assigned_table.get_item(
                    Key={
                        'AssignmentId': event.get("parameters", "")[0]['value']
                    }
                )
                asset_id=assigned_res.get("Item").get("AssetId")
                print("asset id of the assignment is:", asset_id)
                if not IsAssigned(asset_id, user_name):
                    return build_agent_response(event, "You are not authorized to perform this action.")
            return get_assignment_by_ID(event, user_details)

        elif function_name=="GetAssignmentByAssetId": #working for manager, user
            if user_details.get('role') not in ["Admin", "Manager"]:
                if not IsAssigned(event.get("parameters", "")[0]['value'], user_name):
                    return build_agent_response(event, "You are not authorized to perform this action.")
            return get_assignment_by_assetID(event, user_details)

        elif function_name=="GetAssignmentByHolderId":  #working for manager
            holder_id = event.get("parameters", "")[0]['value']
            if user_details.get('role') not in ["Admin", "Manager"]:                
                if holder_id.startswith("GRP_"):
                    if not Ingroup(holder_id, user_name):
                        return build_agent_response(event, "You are not authorized to perform this action.")
                elif user_details.get('username')!= holder_id:
                    return build_agent_response(event, "You are not authorized to perform this action.")
            return get_assignment_by_holderID(event, user_details)
        
        elif function_name=="CreateGroup":  #working for manager, user
            if user_details.get('role') not in ["Admin", "Manager"]:
                return build_agent_response(event, "You are not authorized to perform this action.")
            params={}
            for param in event.get("parameters", ""):
                params[param['name']] = param['value']
            return agent_create_group(event, user_details, params)
        
        elif function_name=="GetByGroupID":  #working for manager, user
            if user_details.get('role') not in ["Admin", "Manager"]:
                if not Ingroup(event.get("parameters", "")[0]['value'], user_details.get("username")):
                    return build_agent_response(event, "You are not authorized to perform this action.")
            return agent_get_group(event, user_details)

        elif function_name=="GetAllGroups":  #working for manager, user
            if user_details.get('role') not in ["Admin", "Manager"]:
                return build_agent_response(event, "You are not authorized to perform this action.")
            return agent_get_all_groups(event, user_details)

        elif function_name=="UpdateGroup":   #working for manager
            if user_details.get('role') not in ["Admin", "Manager"]:
                if not Ingroup(event.get("parameters", "")[0]['value'], user_details.get("username")):
                    return build_agent_response(event, "You are not authorized to perform this action.")
            params={}
            for param in event.get("parameters", ""):
                params[param['name']] = param['value']
            return agent_update_group(event, user_details, params)

        elif function_name=="GetUserById":   #working for manager, user
            print(event.get("parameters", "")[0]['value'])
            if user_details.get('role') not in ["Admin", "Manager"]:
                if user_details.get('username')!=event.get("parameters", "")[0]['value']:
                    return build_agent_response(event, "You are not authorized to fetch details of other users. please recheck your username.")
            print("getting user details by username")
            return agent_get_users_by_username(event, user_details)
        
        elif function_name=="GetUserDetailsByRole":  #working for manager, user
            if user_details.get('role') not in ["Admin", "Manager"]:
                return build_agent_response(event, "You are not authorized to get details of others")
            return agent_get_user_by_role(event, user_details)
        
        elif function_name=="UpdateUserDetails":   #working with manager, user
            if user_details.get('role') not in ["Admin", "Manager"]:
                if user_details.get('username')!=event.get("parameters", "")[0]['value']:
                    return build_agent_response(event, "You are not authorized to update details of other users. please recheck your username.")
            return agent_user_details_update(event, user_details)

        elif function_name=="GetAllUsers":  #working with manager, user
            if user_details.get('role') not in ["Admin", "Manager"]:
                return build_agent_response(event, "You are not authorized to get details of all others")
            return agent_get_all_users(event, user_details)
        
        elif function_name=="GetCommentsByCommentId":   #working with manager, user
            comment_id= event.get("parameters", "")[0]['value']
            if user_details.get('role') not in ['Admin' , 'Manager']:
                logger.error(f"Unauthorized. Users cannot get asset comments")
                return build_agent_response(event, f"Unauthorized. Users cannot get asset comments")
            else:
                return agent_get_by_commentid(event, user_details, comment_id)
        
        elif function_name=="GetCommentsByAssetId":  #working with manager, user
            print('checking your permissions to view assets')
            if user_details.get('role') not in ['Admin' , 'Manager']:
                logger.error(f"Unauthorized. Users cannot get asset comments")
                return build_agent_response(event, f"Unauthorized. Users cannot get asset comments")
            asset_id = event.get("parameters", "")[0]['value']
            return agnet_get_by_assetid(event, user_details, asset_id)
        
        elif function_name=="CreateComments":  #working with manager, user
            print("checking the permissions first to add your comments")
            if user_details.get('role') not in ['Admin' , 'Manager']:
                logger.error(f"Unauthorized. Users cannot create asset comments")
                return build_agent_response(event, f"Unauthorized. Users cannot create asset comments")        
            for i in range(len(event.get("parameters", ""))):
                params[event["parameters"][i]["name"]]= event.get("parameters", "")[i]["value"]
            if not params.get("AssetId"):
                return build_agent_response(event, "Please provide asset id to create its comments")
            print("creating comment for asset:", params.get("AssetId"))
            return agent_create_comment(event, user_details, params)
        
        elif function_name=="UpdateComments":  #working with manager, user
            if user_details.get('role') not in ['Admin' , 'Manager']:
                logger.error(f"Unauthorized. Users cannot update asset comments")
                return build_agent_response(event, f"Unauthorized. Users cannot update asset comments")
            params={}
            for i in range(len(event.get("parameters", ""))):
                params[event["parameters"][i]["name"]]= event.get("parameters", "")[i]["value"]
            if params.get("CommentId"):
                comment_id=params.get("CommentId")
            else:
                return build_agent_response(event, "Please provide asset id to update its comments")
            print("updating the comment:", comment_id)
            return agent_update_comment(event, user_details, params)
        
        elif function_name=="ReportAsset":   #working with manager
            params={}
            for i in range(len(event.get("parameters", ""))):
                params[event["parameters"][i]["name"]]= event.get("parameters", "")[i]["value"]
            asset_id = params.get("AssetId")
            asset_response = ddb_asset_table.get_item(
                Key={
                    'AssetId': asset_id
                }
            )
            logger.info(f"Asset response is: {asset_response.get('Item')}")
            if asset_response.get('Item')==None:
                logger.info("No asset with that asset id")
                return build_agent_response(event, "No asset with that asset id")
            if user_details.get('role') not in ["Manager"]:
                if not IsAssigned(asset_id, user_details.get('username')):
                    logger.warning("Asset is not assigned to you.")
                    return build_agent_response(event, "Asset is not assigned to you.")
                
            return agent_report_asset(event, user_details, params, sender_email, admin_emails)
        else:
            print("No function found")
            return  build_agent_response(event, "Please use ui, this action is not supposed to be done using bot")

    except Exception as e:
        return build_agent_response(event, f"{str(e)}")
