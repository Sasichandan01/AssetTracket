import json
import boto3
import os
from datetime import datetime,timezone,timedelta
import logging

issues_table_name=os.environ['ISSUES_TABLE_NAME']
assets_table_name=os.environ['ASSETS_TABLE_NAME']
users_table_name=os.environ['USERS_TABLE_NAME']

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def lambda_handler(event,context):
    """ 
    Processes overdue issues and asset maintenance alerts, sending emails to admins via SES.  
    Args:
        event (dict): AWS Lambda invocation event data
    Returns:
        dict: Response object with status code and message body
    """
    try:
        dynamodb = boto3.resource('dynamodb')
        issues_table = dynamodb.Table(issues_table_name)
        assets_table = dynamodb.Table(assets_table_name)
        users_table = dynamodb.Table(users_table_name)
        ses=boto3.client('ses')
        verified_mails=ses.list_verified_email_addresses()
        # Get manager email
        sender_email='noreply@cloudwick.com'
        logger.info(f"Sender email: {sender_email}")
        # Get admin emails
        admin_response=users_table.query(
            IndexName='RoleName-index',
            KeyConditionExpression='RoleName=:role',
            ExpressionAttributeValues={':role':'Admin'},
            ProjectionExpression='Email'
        )
        admin_emails=[item.get('Email') for item in admin_response['Items'] if item.get('Email') in verified_mails.get('VerifiedEmailAddresses')]
        logger.info(f"Admin emails: {admin_emails}")
        
        utc_time=datetime.now(timezone.utc)
        offset=timedelta(hours=5,minutes=30)
        curr_time=datetime.now(timezone.utc)+offset
        response = issues_table.query(
            IndexName='IssueStatus-CreatedBy-index',
            KeyConditionExpression='IssueStatus = :status',
            ExpressionAttributeValues={
                ':status': 'Pending'
            }
        )
        issue_list=[]
        for item in response['Items']:
            raised_time=item.get('RaisedAt')
            raised_time=(datetime.now()+timedelta(hours=5,minutes=30)).replace(tzinfo=timezone.utc)
            diff=curr_time-raised_time
            priority=item.get('IssuePriority')
            if diff.days>=3 and priority=='High':
                issue_list.append(item.get("IssueId"))
            elif diff.days>=5 and priority=='Medium':
                issue_list.append(item.get("IssueId"))
                
        issues=", ".join(issue_list)
        logger.info(f"Issues: {issues}")
        assets=assets_table.scan()
        expire_list=[]
        service_list=[]
        for asset in assets.get('Items'):
            expiry_time=asset.get('Expiry')
            if expiry_time!=None:
                expiry_time=((datetime.now()+timedelta(hours=5,minutes=30)).replace(tzinfo=timezone.utc))
                diff=expiry_time-curr_time
                if diff.days>=3:
                    expire_list.append(asset.get('AssetId'))

            service_time=asset.get('ServiceTime')
            if service_time!=None:
                service_time=(datetime.now()+timedelta(hours=5,minutes=30)).replace(tzinfo=timezone.utc)
                diff=service_time-curr_time
                if diff.days>=3:
                    service_list.append(asset.get('AssetId'))
        
        service_assets=", ".join(service_list)
        expire_assets=", ".join(expire_list)

        if not any([issues, service_assets, expire_assets]):
            return {
                'statusCode':200,
                'body':"Nothing of note to be mentioned"
            }

        if not sender_email:
            raise ValueError("No manager found in UsersTable")
        if not admin_emails:
            raise ValueError("No admin users found in UsersTable")

        message=f"Issues {issues} raised for more than 5 days. Please service the issue. Assets about to expire are: {expire_assets}. Assets about to run out of service time are: {service_assets}"

        response=ses.send_email(
            Source=sender_email,
            Destination={'BccAddresses':admin_emails},
            Message={
                'Subject':{'Data':'Issues Notifications'},
                'Body':{'Text':{'Data':message}}
                }
            )
            
        return {
            'statusCode':200,
            'body':json.dumps(response)
        }
    except Exception as e:
        return {
            "statusCode":500,
            "body":json.dumps({"message":str(e)})
        }