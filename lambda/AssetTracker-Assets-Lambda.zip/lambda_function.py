import json
import os 
import boto3
import uuid
import datetime
import time
# import jwt
import logging
from botocore.exceptions import ClientError
from botocore.exceptions import ParamValidationError
from botocore.config import Config
import base64
from boto3.dynamodb.conditions import Attr


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

ddb_assets_resource = boto3.resource('dynamodb').Table(os.environ.get('ASSETS_TABLE_NAME'))
ddb_assignment_resource = boto3.resource('dynamodb').Table(os.environ.get('ASSIGNMENT_TABLE_NAME'))
ddb_groups_resource = boto3.resource('dynamodb').Table( os.environ.get('GROUPS_TABLE_NAME'))
ddb_users_resource = boto3.resource('dynamodb').Table(os.environ.get('USERS_TABLE_NAME'))
ddb_issues_resource = boto3.resource('dynamodb').Table(os.environ.get('ISSUES_TABLE_NAME'))
ddb_comments_resource = boto3.resource('dynamodb').Table(os.environ.get('COMMENTS_TABLE_NAME'))
primary_bucket_name = os.environ.get('S3_FILES_BUCKET')
secondary_bucket_name = os.environ.get('S3_EXPIRED_FILES_BUCKET')
ssm_client = boto3.client('ssm')
s3_client = boto3.client('s3')

dynamodb = boto3.client('dynamodb')

def handle_error(message, status=500):
    """
    Handles error responses by logging the error and returning a formatted response.
    
    Args:
        message (str): The error message to be logged and returned.
        status (int, optional): HTTP status code. Defaults to 500.
    
    Returns:
        dict: A dictionary containing the status code and error message.
    """
    logger.error(message)
    return {'statusCode': status, 'body': json.dumps(message)}

def generate_presigned_url(bucket_name, object_key , expiration , item , method):
    
    try:
        logger.info(f"Generating presigned url for bucket:{bucket_name}, object_key:{object_key}, expiration:{expiration}, method:{method}")
        params={
            'Bucket': bucket_name,
            'Key': object_key,
        }

        if method == 'put_object':
            item['ContentType'] = 'application/zip'
            if item:
                params['Metadata'] = item
            
        response=s3_client.generate_presigned_url(
            ClientMethod=method,
            Params=params,
            ExpiresIn=expiration
        )
        return response
    except Exception as e:
        return handle_error(str(e) , 500)


def get_assets(event, user_details):
    """
    Fetches all assets.

    This function is used to fetch all the assets that are there in the system
    Args:
        event(dict): Request event object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or requested object)
                - 'assets' (list): list of assets
                - 'lastKey' (dict): last response object returned, for pagination

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """

    logger.info(f"Fetching assets for username:{user_details.get('username')}, role:{user_details.get('role')}")
    try:
        if user_details.get('role') in ['Manager', 'Admin']:
            logger.info(f"Admin/Manager flow")
            limit = 20
            last_evaluated_key = None
            qsp=event.get('queryStringParameters', {})
            logger.info(f"Query string parameters: {qsp}")
            asset_status = qsp.get('asset-status', '')

            if not asset_status:
                return handle_error("asset-status is required", 400)

            expression_attribute_values = {
                ':retired': 'Retired',
                ':stolen': 'Stolen',
                ':missing': 'Missing'
            }

            # Define scan_kwargs
            scan_kwargs = {
                'Limit': limit,
                'ProjectionExpression': 'AssetId, AssetName , AssetStatus',
                'ExpressionAttributeValues': expression_attribute_values
            }

            if asset_status == 'in-system':
                scan_kwargs['FilterExpression'] = 'NOT AssetStatus IN (:retired , :stolen , :missing)'
            elif asset_status == 'out-of-system':
                scan_kwargs['FilterExpression'] = 'AssetStatus IN (:retired , :stolen , :missing)'

            if qsp and qsp.get('lastKey'):
                print(qsp)
                last_evaluated_key = event['queryStringParameters'].get('lastKey')
                last_key = {
                        'AssetId':last_evaluated_key
                }
                logger.info(f"Last evaluated key: {last_key}")
                scan_kwargs['ExclusiveStartKey'] = last_key
                logger.info(f"Scan kwargs: {scan_kwargs}")


            try:
                response = ddb_assets_resource.scan(**scan_kwargs)
                # response = dynamodb.scan(TableName=table_name)
                logger.info(f"Response from DynamoDB: {response}")
                result=response.get('Items', [])
                print(result)
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        "Response" : {
                            'assets': result,
                            'lastKey': response.get('LastEvaluatedKey', None)
                        }
                    })
                }
            except ClientError as e:
                logger.error(f"DynamoDB error: {e.response['Error']['Message']}")
                return handle_error(f"DynamoDB error: {e.response['Error']['Message']}", 400)
            except ParamValidationError as e:
                logger.error(f"Invalid parameters: {str(e)}")
                return handle_error('Invalid parameters', 400)
        else:
            logger.warning(f"Unathorized Access by {user_details.get('role')} {user_details.get('username')}")
            return handle_error('Unauthorized. Users cannot get all asset details', 403)
            
            
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return handle_error(str(e),500)

def get_asset_by_id(event, user_details):
    """
    Fetches assets by IDs.

    This function is used to fetch assets based on the provided Asset ID.
    Args:
        event(dict): Request event object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or requested object)
                - 'assets' (list): list of assets

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Fetching assets for username:{user_details.get('username')}, role:{user_details.get('role')}, GET ASSETS")
    try:
        print(event)
        path_params = event.get('pathParameters' , {})
        query_params = event.get('queryStringParameters', {})

        if not path_params or not query_params:
            logger.error("Path parameters and query parameters are required")
            return handle_error('Path parameters and query parameters are required', 400)
        logger.debug(f"Path parameters: {path_params}")
        id = path_params.get('id' , '')
        type = query_params.get('type', '')

        if not id:
            logger.error("id is required in path parameters")
            return handle_error('id is required in path parameters', 400)

        if not type:
            logger.error("type is required in query parameters")
            return handle_error('type is required in query parameters', 400)  
        
        asset = ddb_assets_resource.get_item(
            Key = {
                'AssetId' : id
            },
            ProjectionExpression = 'AssetName, AssetId, AssetStatus, SerialNumber, Expiry, ServiceTime, Category, #type, Metadata , #loc',
            ExpressionAttributeNames = {
                '#type' : 'Type',
                '#loc' : 'Location'
            }
        ).get('Item')


        if not asset:
            logger.warning(f"Asset {id} not found")
            return handle_error(f"Asset {id} not found", 404)
    
        prefix = f"assets/{id}"
        logger.info(f"Prefix: {prefix}")

        bucket_name = primary_bucket_name

        if asset.get('AssetStatus') not in ['Assigned' , 'Unassigned']:
            bucket_name = secondary_bucket_name
        s3_asset_image_list=s3_client.list_objects(
                Bucket=bucket_name,
                Prefix=prefix
            )
        logger.info(f"S3 list is {s3_asset_image_list}")
        contents=[item.get('Key') for item in s3_asset_image_list.get('Contents')]
        logger.info(f"Image key list is {contents}")
        
        if user_details.get('role') not in ['Admin' , 'Manager']:
            if asset.get('AssetStatus') in ['Retired' , 'Stolen' , 'Missing']:
                logger.warning(f"Asset {id} cannot be viewed by users")
                return handle_error(f"Asset {id} cannot be viewed by users", 400)
            logger.info(f"{user_details.get('username')} is not Admin or Manager. Fetching assets assets based on user assignemnts")
            try:
                #get details of the assignement based on that assetid and check if there is any asisgnment to that 
                assignment = ddb_assignment_resource.query(
                    IndexName='AssetId-index',  
                    KeyConditionExpression='AssetId = :asset_id',
                    ExpressionAttributeValues={
                        ':asset_id': id
                    },
                    ScanIndexForward=False,  
                    Limit=1
                ).get('Items', [])
                if not assignment:
                    logger.warning(f"Assignment for asset {id} not found")
                    m= f'Assignment for asset {id} not found'
                    return {
                        "statusCode" : 403,
                        "body" : json.dumps({
                            "Response" : "No assignments for this asset"
                        })
                    }
                logger.info(f"Assignment for asset {id} found: {assignment}")
                
                if assignment[0].get('HolderId').startswith('GRP_'):
                    group = ddb_groups_resource.get_item(
                        Key = {
                            "GroupId" : assignment[0].get('HolderId')
                        }
                    ).get('Item')
                    if assignment[0].get('AssignmentStatus') != 'Active' or user_details.get('username') not in group.get('Users'):
                        logger.warning(f"Assignment for asset {id} not found")
                        return handle_error('Unauthorized. Users can only view the assets assigned to them', 403)
                elif assignment[0].get('AssignmentStatus') != 'Active' or user_details.get('username') != assignment[0].get('HolderId'):
                    logger.warning(f"Assignment for asset {id} not found")
                    return handle_error('Unauthorized. Users can only view the assets assigned to them', 403)
            # GET IMAGE BY KEY
                if type == 'image':
                    file_name = query_params.get('file-name')

                    if not file_name:
                        logger.error("file-name is required in query parameters")
                        return handle_error('file-name is required in query parameters', 400)
                    if not contents:
                        logger.warning(f"Image for asset {id} not found")
                        return handle_error(f"Image for asset {id} not found", 404)
                    logger.info(f"Fetching image for asset {id}")
                    image_key=f"assets/{id}/{file_name}"
                    logger.info(f"Image key is {image_key}")
                    image_url=generate_presigned_url(primary_bucket_name, image_key, 3600, {'Method' : 'GET'}, 'get_object')
                    logger.info(f"Image url is {image_url}")
                    return {
                        'statusCode': 200,
                        'body': json.dumps({
                            "Response" : {
                                {
                                    'Image': image_url
                                }
                            }
                        })
                    }
            # GET ASSET BY ID
                elif type == 'asset':
                    if asset.get('Type') == 'Digital' and asset.get('Category') == 'API Key':
                        encrypted_key = ssm_client.get_parameter(
                            Name=f"/assets/{id}/key",
                            WithDecryption=True
                        )['Parameter']['Value']
                        logger.info(f"Encrypted key for asset {id} is {encrypted_key}")
                        asset['EncryptedKey'] = encrypted_key
                    return {
                        "statusCode" : 200,
                        "body" : json.dumps({
                            "Response" : {
                                "asset" : asset,
                                "images" : contents
                            }
                        })
                    }
            except ClientError as e:
                return handle_error(f"SSM GET operation failed with response: {e.response['Error']['Message']}", 400)
        else:
            # Done
            logger.info(f"{user_details.get('username')} is Admin or Manager. Fetching assets based on asset id")
            #  GET IMAGE BY KEY
            if type == 'image':
                file_name = query_params.get('file-name')

                if not file_name:
                    logger.error("file-name is required in query parameters")
                    return handle_error('file-name is required in query parameters', 400)
                if not contents:
                    logger.warning(f"Image for asset {id} not found")
                    return handle_error(f"Image for asset {id} not found", 404)
                logger.info(f"Fetching image for asset {id}")
                image_key=f"assets/{id}/{file_name}"
                if not contents:
                    logger.warning(f"Image for asset {id} not found")
                    return handle_error(f"Image for asset {id} not found", 404)
                logger.info(f"Fetching image for asset {id}")
                image_key=f"assets/{id}/{file_name}"
                logger.info(f"Image key is {image_key}")
                image_url=generate_presigned_url(primary_bucket_name, image_key, 3600, {'Method' : 'GET'}, 'get_object')
                logger.info(f"Image url is {image_url}")
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        "Response" : {
                            'ImageUrl': image_url
                        }
                    })
                }
            # GET ASSET BY ID
            elif type == 'asset':
                if asset.get('Type') == 'Digital' and asset.get('Category') == 'API Key':
                    encrypted_key = ssm_client.get_parameter(
                        Name=f"/assets/{id}/key",
                        WithDecryption=True
                    )['Parameter']['Value']
                    logger.info(f"Encrypted key for asset {id} is {encrypted_key}")
                    asset['EncryptedKey'] = encrypted_key
                return {
                    "statusCode" : 200,
                    "body" : json.dumps({
                        "Response" : {
                            "asset" : asset,
                            "images" : contents
                        }
                    })
                }
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return handle_error(str(e), 500) 

def register_asset(event, user_details):
    """
    Registers new Assets.

    This function is used to register new assets into the database.
    Args:
        event(dict): Request event object
        body(dict): Request body object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or database response)

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Registering asset for username:{user_details.get('username')}, role:{user_details.get('role')}")
    try:
        if user_details.get('role') not in ['Manager', 'Admin']:
            logger.warning(f"Unauthorized. Users cannot register new assets")
            return handle_error('Unauthorized. Users cannot register new assets', 403)
        logger.info(f"event : {event}")
        body = event.get('body', {})
        body = json.loads(body)
        logger.info(f"Request body: {body}")
        myuuid = str(uuid.uuid4())[:16]
        utc_time=datetime.datetime.now()
        offset= datetime.timedelta(hours=5,minutes=30)
        curr_time=str((utc_time+offset).strftime("%Y-%m-%d_%H:%M:%S.%f"))
        required_params= ["AssetName", "Category", "Type", "Cost"]
        for p in required_params:
            if p not in body:
                logger.warning("path parameters not found")
                return handle_error(f'{p} is required', 400)

        if body.get('Type')=='Physical':
            if body.get('SerialNumber' , '') == '':
                logger.warning("Serial number not found for Physical Asset in request body")
                return handle_error('SerialNumber is required for physical assets', 400)
    
            if body.get('Expiry'):
                logger.warning("Expiry Time for Physical Asset found in request body")
                return handle_error('Expiry Time is not required for physical assets')
            if body.get('EncryptedKey'):
                logger.warning("Encrypted Key for Physical Asset found in request body")
                return handle_error('EncryptedKey is not required for physical assets')
            if not body.get('Location'):
                logger.warning("location of physical Asset not found in request body")
                return handle_error('Location is required for physical assets')                
            
        elif body.get('Type')=='Digital':
            if not body.get('Expiry'):
                logger.warning("Expiry Time for Digital Asset not found in request body")
                return handle_error('ExpiryTime is required for digital assets')
            if not body.get('EncryptedKey'):
                logger.warning("Encrypted Key for Digital Asset not found in request body")
                return handle_error('Encrypted Key is required for digital assets' , 400)
            if body.get('ServiceTime'):
                logger.warning("Service Time for Digital Asset found in request body")
                return handle_error('ServiceTime is not required for digital assets')
            # if body.get('SerialNumber'):
            #     logger.warning("Serial number for Digital Asset found in request body")
            #     return handle_error('SerialNumber is not required for digital assets')

        location = body.get('Location' , {})
        # if not location:
        #     location = {
        #         "InOffice" : {
        #             "Address" : "Cloudwick",
        #             "Date" : curr_time
        #         }
        #     }

        if location.get('InOffice'):
            if location.get('InOffice').get('Address' , '') == '' and location.get('InOffice').get('Date','') == '':
                logger.warning("Address or date not found for InOffice Asset in request body")
                return handle_error('Address and date is required for InOffice assets')
        elif location.get('OutOfOffice'):
            if location.get('OutOfOffice').get('Address','') == '' and location.get('OutOfOffice').get('Date','') == '':
                logger.warning("Address or date not found for OutOfOffice Asset in request body")
                return handle_error('Address and date is required for OutOfOffice assets')

        item={
            "AssetId":  myuuid,
            "SerialNumber": body.get("SerialNumber", None),
            "AssetName": body.get("AssetName"),
            "Category": body.get("Category"),
            "Type": body.get("Type"),
            "Cost": str(body.get('Cost')),
            "Expiry": str(body.get('Expiry',None)),
            "ServiceTime": str(body.get('ServiceTime',None)),
            "Metadata": json.dumps(body.get('Metadata',None)),
            "CreatedBy": user_details.get('username'),
            "CreatedAt": curr_time,
            "LastModifiedBy": user_details.get('username'),
            "LastModifiedAt": curr_time,
            "AssetStatus": "Unassigned",
            "Location" : json.dumps(location),
            "Method" : "POST"
        }

        if body.get('Type')=='Digital':
            item['EncryptedKey'] = body.get('EncryptedKey', None)
    
        try:
            logger.info(f"Adding asset to database")
            
            object_key = f"assets/{myuuid}/asset_{curr_time}.zip"
            put_url = generate_presigned_url(primary_bucket_name,object_key,3600,item,'put_object')

            return {
                "statusCode": 200,
                "body": json.dumps({
                    "Response" : {
                        "PreSignedUrl": put_url
                    }
                })
            }

        except ClientError as e:
            logger.error(f"DynamoDB PUT operation failed with response: {e.response['Error']['Message']}")
            return handle_error(f'DynamoDB PUT operation failed with response: {e.response['Error']['Message']}', 400)

    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return handle_error(str(e), 500)

def update_asset(id, body, event, user_details):
    """
    Update existing assets

    This function is used to update the attributes of assets.
    Args:
        id(str): ID of the asset whose attributes need to be updated
        event(dict): Request event object
        body(dict): Request body object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or database response)

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Updating asset for asset: {id}")
    try:
        if user_details.get('role') not in ['Manager', 'Admin']:
            logger.warning(f"Unauthorized. Users cannot update assets")
            return{
                "statusCode" : 403,
                "body" : json.dumps({
                    "message" : "Unauthorized. Users cannot update assets"
                })
            }

        asset_updates = {}

        utc_time=datetime.datetime.now()
        offset= datetime.timedelta(hours=5,minutes=30)
        curr_time=str((utc_time+offset).strftime("%Y-%m-%d_%H:%M:%S.%f"))
        query_params = event.get('queryStringParameters' , {})
        operation = query_params.get('operation', '')

        asset = ddb_assets_resource.get_item(
            Key = {
                'AssetId' : id
            }
        )
    
        if 'Item' not in asset:
            logger.warning(f"Asset {id} does not exist")
            return handle_error(f'Asset {id} does not exist', 404)

        logger.info(f"Asset details fetched successfully")
        asset = asset.get('Item')

        

        if operation == 'upload':
            if asset.get('AssetStatus') in ['Retired' , 'Stolen' , 'Missing']:
                logger.warning(f"Asset {id} is inactive")
                return handle_error(f'Asset {id} is inactive', 400)
            logger.info(f"Uploading image")
            object_key = f"assets/{id}/asset_{curr_time}.zip"
            item = {
                'Method' : 'PUT'
            }
            put_url = generate_presigned_url(primary_bucket_name, object_key, 3600,item,'put_object')

            return {
                'statusCode' : 200,
                'body' : json.dumps({
                    "Response" : {
                        'PreSignedUrl' : put_url
                    }
                })
            }
        elif operation == 'reactivate':
            logger.info(f"Fetching asset details from database")
            if asset.get('AssetStatus') != 'Retired':
                logger.warning(f"Asset {id} is not inactive")
                return handle_error(f'Asset {id} is not inactive', 400)
            
            ddb_assets_resource.update_item(
                Key = {
                    'AssetId' : id
                },
                UpdateExpression = """
                    SET AssetStatus = :status,
                        LastModifiedBy = :user,
                        LastModifiedAt = :time
                    REMOVE AssetExpirationTime
                """,
                ExpressionAttributeValues={
                    ':status': 'Unassigned',
                    ':user': user_details.get('username'),
                    ':time': curr_time
                }
            )
            
            assignments = ddb_assignment_resource.query(
                IndexName = 'AssetId-index',
                KeyConditionExpression='AssetId = :asset_id',
                ExpressionAttributeValues={
                    ':asset_id': id
                },
            ).get('Items')
            issues = ddb_assignment_resource.query(
                IndexName = 'AssetId-index',
                KeyConditionExpression='AssetId = :asset_id',
                ExpressionAttributeValues={
                    ':asset_id': id
                },
            ).get('Items')
            comments = ddb_comments_resource.query(
                IndexName = 'AssetId-index',
                KeyConditionExpression='AssetId = :asset_id',
                ExpressionAttributeValues={
                    ':asset_id': id
                },
            ).get('Items')

            if assignments:
                for assignment in assignments:
                    ddb_assignment_resource.update_item(
                        Key = {
                            'AssignmentId' : assignment.get('AssignmentId')
                        },
                        UpdateExpression = "REMOVE AssignmentExpirationTime"
                    )
            if issues:
                for issue in issues:
                    ddb_assignment_resource.update_item(
                        Key = {
                            'AssignmentId' : issue.get('AssignmentId')
                        },
                        UpdateExpression = "REMOVE IssueExpirationTime"
                    )
            if comments:
                for comment in comments:
                    ddb_comments_resource.update_item(
                        Key = {
                            'CommentId' : comment.get('CommentId')
                        },
                        UpdateExpression = "REMOVE CommentExpirationTime"
                    )

            # MOVE TO ORIGINAL BUCKET
            move_s3_objects(secondary_bucket_name , primary_bucket_name , f"assets/{id}")

            return {
                "statusCode" : 200,
                "body" : json.dumps({
                    "Response" : f"Asset {id} reactivated successfully"
                })
            }
        
        elif operation == 'update-details':
            
            logger.info(f"Fetching asset details from database")
            asset_updates["LastModifiedBy"] = {"Value": user_details.get('username'), "Action": "PUT"}
            asset_updates["LastModifiedAt"] = {"Value": curr_time, "Action": "PUT"}
            if "AssetName" in body:
                asset_updates["AssetName"] = {"Value": body.get("AssetName"), "Action": "PUT"}
            if "Category" in body:
                asset_updates["Category"] = {"Value": body.get("Category"), "Action": "PUT"}
            if "Type" in body:
                asset_updates["Type"] = {"Value": body.get("Type"), "Action": "PUT"}
            if "AssetStatus" in body:
                if body.get('AssetStatus') == 'Unassigned' and asset.get('AssetStatus') != 'Assinged':
                    return handle_error('Asset is not assigned to anyone. Cannot unassign' , 400)

                asset_updates["AssetStatus"] = {"Value": body.get("AssetStatus"), "Action": "PUT"}
            if "Cost" in body:
                asset_updates["Cost"] = {"Value": str(body.get("Cost")), "Action": "PUT"}
            if "Expiry" in body:
                if asset.get('Type') == 'Physical':
                    return handle_error('Expiry is not required for digital assets', 400)
                asset_updates["Expiry"] = {"Value": str(body.get("Expiry")), "Action": "PUT"}
                raw_time = body.get('Expiry')
                dt = datetime.datetime.strptime(raw_time, "%Y-%m-%d %H:%M:%S.%f")
                iso_format_dt = dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
                ssm_client.put_parameter(
                    Name=f"/assets/{id}/key",
                    Value=metadata_item.get('encryptedkey'),
                    Type='SecureString'
                )
            if "ServiceTime" in body:
                asset_updates["ServiceTime"] = {"Value":str(body.get("ServiceTime")), "Action": "PUT"}
            if "Metadata" in body:
                asset_updates["Metadata"] = {"Value": json.dumps(body.get("Metadata")), "Action": "PUT"}
            if "SerialNumber" in body:
                asset_updates["SerialNumber"] = {"Value": body.get("SerialNumber"), "Action": "PUT"}
            if "Location" in body:
                asset_updates["Location"] = {"Value": json.dumps(body.get("Location")), "Action": "PUT"}

            try:
                logger.info(f"Updating asset details in database")
                if body.get('AssetStatus' , '') == 'Assign':
                    return handle_error('Cannot assign asset here. Use /assignment/POST', 400)

                elif body.get('AssetStatus' , '') == 'Unassigned':
                    latest_assignment = ddb_assignment_resource.query(
                        IndexName='AssetId-index',
                        KeyConditionExpression='AssetId = :asset_id',
                        ExpressionAttributeValues={
                            ':asset_id': id
                        },
                        ScanIndexForward=False,
                        Limit = 1
                    )

                    if 'Items' in latest_assignment:
                        latest_assignment = latest_assignment.get('Items')
                        if latest_assignment[0].get('AssignmentStatus') == 'Active':
                            ddb_assignmrnt_resource.update_item(
                                Key={"AssignmentId": latest_assignment[0].get('AssignmentId')},
                                AttributeUpdates={
                                    "AssignmentStatus = :a_status"
                                },
                                ExpressionAttributeValues = {
                                    ":a_status" : "Inactive"
                                }
                            )
                
                    

                res = ddb_assets_resource.update_item(Key={'AssetId': id}, AttributeUpdates=asset_updates)

                return {
                    "statusCode": 200,
                    "body": json.dumps({
                        "Response" : {
                            "messsage" : f'Asset updated successfully by: {user_details.get('username')}'
                        }
                    })
                }
            except ClientError as e:
                logger.error(f"DynamoDB UPDATE operation failed with response: {e.response['Error']['Message']}")
                return handle_error(f'DynamoDB UPDATE operation failed with response: {e.response['Error']['Message']}', 400)

    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return handle_error(str(e), 500)

def delete_asset(id, event, user_details):
    """
    Deletes assets

    This function is used to delete assets from the database.
    Args:
        id(str): id of the asset that needs to be deleted
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or database response)

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Deleting asset: {id}")
    try:
        if user_details.get('role') not in ['Manager', 'Admin']:
            logger.warning(f"Unauthorized. Users cannot delete assets")
            return handle_error('Unauthorized. Users cannot delete assets', 403)
            
        query_params = event.get('queryStringParameters', {})
        if not query_params:
            return handle_error('Missing query parameters', 400)
        
        delete = query_params.get('delete', '')
        if not delete:
            return handle_error('Missing delete parameter', 400)

        if delete == "image":
            logger.info(f"deleting asset image")
            file_name = query_params.get('file-name','')

            if file_name == '':
                return handle_error('Missing file-name parameter', 400)
            # object_key = id
            object_key = f"assets/{id}/{file_name}"

            print(object_key)
            s3_client.delete_object(Bucket=primary_bucket_name, Key=object_key)
            return {
                "statusCode": 200,
                "body": json.dumps({
                    "Response": "Asset image deleted successfully"
                })
            }
        elif delete in ["Retired" , "Stolen" , "Missing"]:
            logger.info(f"Fetching asset details from database")
            asset = ddb_assets_resource.get_item(
                Key = {
                    'AssetId' : id
                }
            )
    
            if 'Item' not in asset:
                logger.warning(f"Asset {id} does not exist")
                raise ValueError('Asset does not exist')

            if asset.get('AssetStatus') in ['Retired' , 'Missing' , 'Stolen']:
                logger.warning(f"Asset {id} is not in the system. Either retired, missing or stolen")
                return handle_error(f'Asset {id} is not in the system. Either retired, missing or stolen', 400)
            
            logger.info(f"Asset details fetched successfully")
            assignments = ddb_assignment_resource.query(
                IndexName='AssetId-index',
                KeyConditionExpression='AssetId = :asset_id',
                ExpressionAttributeValues={
                    ':asset_id': id
                },
                ScanIndexForward=False
            ).get('Items')

            ttl_value = int(time.time()) + 300
            if asset.get('Type') == 'Digital':
                expiry_string = asset.get('Expiry')
                expiry_date = datetime.strptime(expiry_str, '%d-%m-%Y %H:%M:%S.%f')
                expiry_unix = int(expiry_date.timestamp())

                ttl_value = min(ttl_value, expiry_unix)
            if assignments:
                for assignment in assignments:
                    # if assignment.get('AssignedStatus') == 'Active':
                    #     logger.info(f"Asset is currently assigned to {assignment.get('HolderId')}")
                    #     ddb_assigned_resource.update_item(
                    #         Key={
                    #             'AssignmentId': assignment.get('AssignmentId')
                    #         },
                    #         AttributeUpdates={
                    #             'AssignedStatus': {
                    #                 'Value': 'Inactive',
                    #                 'Action': 'PUT'
                    #             }
                    #         }
                    #     )
                    #     logger.info(f"Assignment status updated to Inactive")
                    # ddb_assigned_deleted_resource.put_item(
                    #     Item = assignment
                    # )
                    ddb_assignment_resource.update_item(
                        Key = {
                            "AssignmentId" : assignment.get('AssignmentId')
                        },
                        UpdateExpression = "SET AssignmentExpirationTime = :d_time , AssignmentStatus = :a_status" ,
                        ExpressionAttributeValues = {
                            ":d_time" : ttl_value,
                            ":a_status" : "Inactive"
                        }
                    )
                    # ddb_assigned_resource.delete_item(
                    #     Key = {
                    #         'AssignmentId': assignment.get('AssignmentId')
                    #     }
                    # )
            
            issues= ddb_issues_resource.query(
                IndexName='AssetId-CreatedBy-index',
                KeyConditionExpression='AssetId = :asset_id',
                ExpressionAttributeValues={
                    ':asset_id': id
                }
            ).get('Items')
            if issues:
                for issue in issues:
                    logger.info(f"Deleting issue {issue.get('IssueId')}")
                    
                    ddb_issues_resource.update_item(
                        Key = {
                            "IssueId" : issue.get('IssueId')
                        },
                        UpdateExpression = "SET IssueExpirationTime = :d_time",
                        ExpressionAttributeValues = {
                            ":d_time" : ttl_value
                        }
                    )
                    logger.info(f"Asset added to deleted issues successfully")
    
            comments = ddb_comments_resource.query(
                IndexName='AssetId-index',
                KeyConditionExpression='AssetId = :asset_id',
                ExpressionAttributeValues={
                    ':asset_id': id
                }
            ).get('Items')
            if comments:
                for comment in comments:
                    logger.info(f"Deleting comment {comment.get('CommentId')}")
                    ddb_comments_resource.update_item(
                        Key = {
                            "CommentId" : comment.get('CommentId')
                        },
                        UpdateExpression = "SET CommentExpirationTime = :ttl",
                        ExpressionAttributeValues = {
                            ":ttl" : ttl_value
                        }
                    )
                    # ddb_comments_resource.delete_item(Key={'CommentId': comment.get('CommentId')})
                    logger.info(f"Comment {comment.get('CommentId')} deleted successfully")
    
            # MOVE TO EXPIRED FILES BUCKET
            logger.info(f"Moving asset to retired bucket")
            move_s3_objects(primary_bucket_name , secondary_bucket_name , f"assets/{id}")
            
            deleted_asset = ddb_assets_resource.update_item(
                Key={
                    'AssetId': id
                },
                UpdateExpression="SET AssetStatus=:s , AssetExpirationTime = :d_time",
                ExpressionAttributeValues={
                    ':s': delete,
                    ':d_time' : ttl_value
                },
                ReturnValues="UPDATED_NEW"
            )
    
            
            return {
                "statusCode": 200,
                "body": json.dumps({
                    "Response": "asset is retired now"
                })
            }
    
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return handle_error(str(e), 500)

def get_assignment_by_id(event , user_details):
    """
    Fetch Assignments

    This function is used to fetch assignments based on IDs. The provided ID can be either an AssetId or a HolderId
    Args:
        event(dict): Request event object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or database response)

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Fetching assignment details")
    try:
        path_params = event.get('pathParameters', None)
        query_params = event.get('queryStringParameters', None)

        if not path_params or not query_params:
            logger.warning(f"Invalid path parameters or query parameters")
            return handle_error('Invalid path parameters or query parameters', 400)

        id = path_params.get('id', None)
        get_by = query_params.get('get-by', None)

        if not id or not get_by:
            logger.warning(f"Invalid path parameters or query parameters")
            return handle_error('Invalid path parameters or query parameters', 400)

        if user_details.get('role') in ['Manager', 'Admin']: 
            logger.info(f"Fetching assignment details for {user_details.get('role')}")   
            if get_by=='assignment-id':
                try:
                    logger.info(f"Fetching assignment details by assignment id")
                    response=ddb_assignment_resource.get_item(
                        Key={
                            'AssignmentId':id
                        }
                    )

                    if 'Item' not in response:
                        logger.warning(f"Assignment does not exist")
                        return handle_error('Assignment does not exist', 404)
                    logger.info(f"Assignment details fetched successfully")
                    item = response.get('Item')
                    return {
                        'statusCode':200,
                        'body': json.dumps({
                            "Response" : item
                        })
                    }
                except ClientError as e:
                    logger.error(f"DynamoDB GET operation failed with response: {e.response['Error']['Message']}")
                    return handle_error(f'DynamoDB GET operation failed with response: {e.response['Error']['Message']}', 400)
            elif get_by=='asset-id':
                try:
                    logger.info(f"Fetching assignment details by Asset Id")
                    response=ddb_assignment_resource.query(
                        IndexName='AssetId-index',
                        KeyConditionExpression='AssetId=:assetid',
                        ExpressionAttributeValues={
                            ':assetid':id
                        }
                    )

                    if 'Items' not in response:
                        logger.warning(f"No assignments for this asset")
                        return handle_error('No assignments for this asset', 404)
                    logger.info(f"Assignment details fetched successfully")
                    response=response.get('Items')
                    return {
                        'statusCode':200,
                        'body': json.dumps({
                            "Response" : response
                        })
                    }
                except ClientError as e:
                    logger.error(f"DynamoDB GET operation faile with response: {e.response['Error']['Message']}")
                    raise handle_error(f'DynamoDB QUERY operation failed with response: {e.response['Error']['Message']}', 400)
            elif get_by=='holder-id':
                try:
                    logger.info(f"Fetching assignments by Holder Id")
                    holder = ddb_users_resource.get_item(
                        Key={
                            'UserName':id
                        }
                    )

                    if 'Item' not in holder:
                        logger.warning(f"User does not exist")
                        return handle_error('User does not exist', 404)
                    response=ddb_assignment_resource.query(
                        IndexName='HolderId-index',
                        KeyConditionExpression='HolderId=:holderid',
                        ExpressionAttributeValues={
                            ':holderid':id
                        }
                    )

                    if 'Items' not in response:
                        logger.warning(f"No assignments for this user")
                        return handle_error('No assignments for this user', 404)
                    response=response.get('Items')
                    logger.info(f"Assignment details fetched successfully")
                    return {
                        'statusCode':200,
                        'body': json.dumps({
                            "Response" : response
                        })
                    }
                except ClientError as e:
                    logger.error(f"DynamoDB GET operation failed with response: {e.response['Error']['Message']}")
                    return handle_error(f'DynamoDB QUERY operation failed with response: {e.response['Error']['Message']}', 400)
            elif get_by=='created-by':
                try:
                    logger.info(f"Fetching assignments by Creater")
                    response=ddb_assets_resource.query(
                        IndexName='CreatedBy-index',
                        KeyConditionExpression='CreatedBy=:c_by',
                        ScanIndexForward=False,
                        ExpressionAttributeValues={
                            ':c_by':id
                        }
                    )

                    if 'Items' not in response:
                        logger.warning(f"No assignments for this user")
                        return handle_error('No assignments for this user', 404)
                    logger.info(f"Assignment details fetched successfully")
                    response=response.get('Items')
                    return {
                        'statusCode':200,
                        'body': json.dumps({
                            "Response" : response
                        })
                    }
                except ClientError as e:
                    logger.error(f"DynamoDB GET operation failed with response: {e.response['Error']['Message']}")
                    return handle_error(f'DynamoDB QUERY operation failed with response: {e.response['Error']['Message']}', 400)
            else:
                logger.warning(f"Invalid get_by")
                return handle_error('Invalid get_by', 400)
        elif user_details.get('role')=='User':
            logger.info(f"Fetching assignment details for {user_details.get('role')}")
            username=user_details.get('username')
            if get_by == 'assignment-id':
                logger.info(f"Fetching assignment details by assignment id")
                try:
                    assignment=ddb_assignment_resource.get_item(
                        Key={
                            'AssignmentId':id
                        }
                    )

                    if 'Item' not in assignment:
                        logger.warning(f"Assignment does not exist")
                        return{
                            "statusCode": 403,
                            "body": json.dumps({
                                "message": "The assignment you are looking for does not exist"
                            })
                        }

                    logger.info(f"Assignment details fetched successfully")
                    assignment = assignment.get('Item')

                    if assignment.get('AssignmentStatus') != 'Active':
                        logger.warning(f"Assignment does not belong to you")
                        return handle_error("The assignment you are looking for does not belong to you",403)
                        
                    elif assignment.get('HolderId').startswith('GRP_'):
                        group = ddb_groups_resource.get_item(
                            Key = {
                                "GroupId" : assignment.get('HolderId')
                            }
                        )
                        if 'Item' not in group:
                            return handle_error('The group corresponding to the assignment you are looking for does not exist', 404)
                        group = group.get('Item')
                        if user_details.get('username') not in group.get('Users'):
                            logger.warning(f"Assignment: {assignment.get('AssignmentId')} does not belong to {user_details.get('username')}")
                            return handle_error('Unauthorized. Users can only view assigments with assets that are assigned to them', 403)
                    elif assignment.get('HolderId') != user_details.get('username'):
                        logger.warning(f"Assignment: {assignment.get('AssignmentId')} does not belong to {user_details.get('username')}")
                        return handle_error('Unauthorized. Users can only view assigments with assets that are assigned to them', 403)

                    else:
                        logger.info(f"Assignment details fetched successfully")
                        return {
                        'statusCode':200,
                        'body': json.dumps({
                            "Response" : assignment
                        })
                    }
                except ClientError as e:
                    logger.error(f"DynamoDB GET operation failed with response: {e.response['Error']['Message']}")
                    return handle_error(f'DynamoDB GET operation failed with response: {e.response['Error']['Message']}', 400)
            elif get_by=='asset-id':
                print("get_by", get_by)
                try:
                    logger.info(f"Fetching assignment details by Asset Id")
                    response=ddb_assignment_resource.query(
                        IndexName='AssetId-index',
                        KeyConditionExpression='AssetId=:assetid',
                        ExpressionAttributeValues={
                            ':assetid':id
                        },
                        ScanIndexForward=False,  
                        Limit=1
                    )
                    if 'Items' not in response:
                        logger.warning(f"Assignment does not exist")
                        return handle_error('The assignment you are looking for does not exist', 404)
                    response = response.get('Items')
                    item = response[0]
                    logger.info(f"Assignment details fetched successfully")
                    
                    if item.get('AssignmentStatus') != 'Active':
                        logger.warning(f"Assignment: {item.get('AssignmentId')} does not belong to {user_details.get('username')}")
                        return handle_error("The assignment you are looking for does not belong to you", 403)
                        
                    if item.get('HolderId').startswith('GRP_'):
                        print("Holder is a group")
                        group = ddb_groups_resource.get_item(
                            Key = {
                                'GroupId' : item.get('HolderId')
                            }
                        )
                        print("group", group)

                        if 'Item' not in group:
                            return handle_error('The group corresponding to the assignment you are looking for does not exist' , 400)
                            raise ValueError('The group corresponding to the assignment you are looking for does not exist')
                        group = group.get('Item')

                        if user_details.get('username') not in group.get('Users'):
                            logger.warning(f"Assignment: {item.get('AssignmentId')} does not belong to {user_details.get('username')}")
                            return handle_error('Unauthorized. Users can only view the assignments they are a part of', 403)
                    elif user_details.get('username') != item.get('HolderId'):
                        logger.warning(f"Assignment: {item.get('AssignmentId')} does not belong to {user_details.get('username')}")
                        print(user_details.get('username') , 'username holder id not equal')
                        print(item.get('HolderId'))
                        return handle_error('Unauthorized. Users can only view the assignments they are a part of', 403)
                    else:
                        logger.info(f"Assignment details fetched successfully")
                        return {
                        'statusCode':200,
                        'body': json.dumps({
                            "Response" : item
                        })
                    }
                    
                except ClientError as e:
                    logger.warning(f"DynamoDB GET operation failed with response: {e.response['Error']['Message']}")
                    return handle_error(f'DynamoDB GET operation failed with response: {e.response['Error']['Message']}', 400)
            elif get_by=='holder-id':
                try:
                    logger.info(f"Fetching assignment details by Holder Id")
                    if id.startswith('GRP_'):
                        group = ddb_groups_resource.get_item(
                            Key = {
                                "GroupId" : id
                            }
                        )

                        if 'Item' not in group:
                            logger.warning(f"Group does not exist")
                            return handle_error('The group corresponding to the assignment you are looking for does not exist', 404)

                        group = group.get('Item')

                        if username not in group.get('Users'):
                            logger.warning(f"Assignment does not belong to {user_details.get('username')}")
                            return handle_error('Unauthorized. Users can only view the assignments they are a part of', 403)

                    elif id != username:
                        logger.warning(f"Assignment does not belong to {username}")
                        return handle_error('Unauthorized. Users can only view the assignments they are a part of', 403)
                    assignments=ddb_assignment_resource.query(
                        IndexName='HolderId-index',
                        KeyConditionExpression='HolderId=:holderid',
                        ExpressionAttributeValues={
                            ':holderid':id
                        },
                        ScanIndexForward=False
                    ).get('Items' , [])

                    group_assignments = []

                    user = ddb_users_resource.get_item(
                        Key = {
                            'UserName' : id
                        }
                    ).get('Item', {})
                    
                    if user: 
                        for group_id in user.get('Groups', []):

                            group_assignments = ddb_assignment_resource.query(
                                IndexName='HolderId-index',
                                KeyConditionExpression='HolderId=:holderid',
                                ExpressionAttributeValues={
                                    ':holderid':group_id
                                },
                                ScanIndexForward=False
                            ).get('Items', [])

                    if not assignments and not group_assignments:
                        return handle_error('The assignment you are looking for does not exist', 404)

                    print(assignments[0])

                    res=[]

                    for assignment in assignments:
                        if assignment.get('AssignmentStatus') == 'Active':
                            res.append(assignment)
                            logger.info(f"Assignment details fetched successfully")
                    for assignment in group_assignments:
                        if assignment.get('AssignmentStatus') == 'Active':
                            res.append(assignment)
                            logger.info(f"Assignment details fetched successfully")

                    return {
                        'statusCode':200,
                        'body': json.dumps({
                            "Response" : res
                        })
                    }
                except ClientError as e:
                    logger.error(f"DynamoDB GET operation failed with response: {e.response['Error']['Message']}")
                    return handle_error(f'DynamoDB GET operation failed with response: {e.response['Error']['Message']}', 400)
            else:
                logger.warning(f"Invalid get_by")
                return handle_error(json.dumps({'message': 'Access Denied: Users can only access their own assignment.'}), 400)
                
    
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return handle_error(str(e), 500)

def get_all_assignments(user_details):
    """
    Fetch all assignments

    This function is used to get the assignment history.
    Args:
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or database response)

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Fetching all assignments")
    try:

        if user_details.get('role') == 'User':
            logger.error(f"Access Denied: Users can only access their own assignment.")
            return handle_error(str({'message': 'Access Denied: Users can not fetch all assignments'}), 403)
        else:
            assignments = ddb_assignment_resource.scan(
                ProjectionExpression = 'AssetId , HolderId'
            ).get('Items')
            return {
                "statusCode" : 200,
                "body" : json.dumps({
                    "Response" : assignments
                })
            }

    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return handle_error(str(e), 500)

def create_assignment(event,body, user_details):
    """
    Assign/Reassign/Unassign assets

    This function is used to assign, unassign or resassign assets to users.
    Args:
        event(dict): Request event object
        body(dict): Request body object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or database response)

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    try:
        logger.info(f"Creating assignment")
        if user_details.get('role') not in ['Manager', 'Admin']:
            logger.warning(f"Access Denied: Only Managers and Admins can create assignments")
            return handle_error(str({'message': 'Access Denied: Only Managers and Admins can create assignments'}), 403)
            
        utc_time=datetime.datetime.now()
        offset= datetime.timedelta(hours=5,minutes=30)
        curr_time=str((utc_time+offset).strftime("%Y-%m-%d %H:%M:%S.%f"))
        asset_id=body.get('AssetId')
        holder_id=body.get('HolderId')
            
        if not asset_id or not holder_id:
            logger.warning(f"AssetId and HolderId are required")
            return handle_error(json.dumps({'message': 'AssetId and HolderId are required'}), 400)

        # CHECK IF THE PROVIDED ASSET ID AND HOLDER ID EXIST OR NOT.
        asset = ddb_assets_resource.get_item(
            Key = {
                'AssetId' : asset_id
            }
        )
        print("asset", asset)
        if 'Item' not in asset:
            logger.warning(f"Asset does not exist")
            return handle_error(json.dumps({'message': 'Asset does not exist'}), 400)
        asset = asset.get('Item')

        if asset.get('AssetStatus') in ['Retired' , 'Missing' , 'Stolen']:
            logger.warning(f"Asset is retired. Cannot assign retired assets")
            return handle_error(json.dumps({'message': 'Asset is retired. Cannot assign retired assets'}), 400)

        if holder_id.startswith('GRP_'):
            group = ddb_groups_resource.get_item(
                Key = {
                    'GroupId' : holder_id
                }
            )
            if not group:
                logger.warning(f"Group does not exist")
                return handle_error(json.dumps({'message': 'Group does not exist'}), 400)
        else:
            user = ddb_users_resource.get_item(
                Key = {
                    'UserName' : holder_id
                }
            )
            if not user:
                logger.warning(f"User does not exist")
                return handle_error(json.dumps({'message': 'User does not exist'}), 400)

        # CHECK IF THE ASSET THAT IS BEING ASSIGNED/REASSIGNED ASSET IS ALREADY HELD BY THE PROVIDED HOLDER ID.
        assignment = ddb_assignment_resource.query(
            IndexName = 'AssetId-index',
            KeyConditionExpression = "AssetId = :a_id",
            ExpressionAttributeValues = {
                ':a_id' : asset_id
            },
            ScanIndexForward=False,
            Limit = 1
        ).get('Items', [])

        if assignment and assignment[0].get('HolderId') == holder_id and assignment[0].get('AssignmentStatus') == 'Active':
            logger.info(f"Asset is already assigned to the provided holder {holder_id}")
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'Response': f'Asset is already assigned to the provided holder {holder_id}'
                })
            }

        #CAN ONLY ASSIGN ASSETS WITH NO PENDING ISSUES 
        issue_progress=ddb_issues_resource.query(
            IndexName='AssetId-CreatedBy-index',
            KeyConditionExpression='AssetId=:assetid',
            FilterExpression='( IssueStatus=:status1 OR IssueStatus=:status2 ) AND ( IssuePriority=:priority1 OR IssuePriority=:priority2 )',
            ExpressionAttributeValues={
                ':assetid':asset_id,
                ':status1':'Pending',
                ':status2':'InProgress',
                ':priority1':'High',
                ':priority2':'Medium'
            },
            ScanIndexForward=False,
            Limit=1
        ).get('Items', [])
        if issue_progress:
            return handle_error(json.dumps({'message': 'Asset cannot be reassigned until all issues are resolved'}), 403)
            

        if assignment != []:    
            ddb_assignment_resource.update_item(
                Key = {
                    'AssignmentId' : assignment[0].get('AssignmentId')
                },
                UpdateExpression = "SET AssignmentStatus = :status",
                ExpressionAttributeValues = {
                    ':status' : 'Inactive'
                }
            )
        
        item={
            'AssignmentId': str(uuid.uuid4())[:16],
            'AssetId':asset_id,
            'HolderId':holder_id,
            'CreatedAt':curr_time,
            'CreatedBy':user_details.get('username'),
            'AssignmentStatus':'Active'
        }

        if asset.get('AssetStatus') == 'Unassigned':
            ddb_assets_resource.update_item(
                Key = {
                    'AssetId' : asset_id
                },
                UpdateExpression = "SET AssetStatus = :status",
                ExpressionAttributeValues = {
                    ':status' : 'Assigned'
                }
            )
        
        response=ddb_assignment_resource.put_item(
            Item=item
        )
        
        return {
            'statusCode':200,
            'body':json.dumps({
                "Response" : response
            })
        }

    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return handle_error(str(e), 500)

def ddb_put(record):
    try:
        logger.info(f"Adding asset")
        object_key = record['s3']['object']['key']
        print(object_key)
        object_key = object_key.replace('%3A' , ':')
        print(object_key)
        key_type = object_key.split('/')[0]
        print(key_type)
        s3_object = s3_client.head_object(Bucket=primary_bucket_name, Key=object_key)
        print("s3_object", s3_object)
        metadata_item = s3_object.get('Metadata', {})
        print(metadata_item)
        logger.debug(f"Metadata received: {metadata_item}")

        asset_id = object_key.split('/')[1]
        print(f"asset_id : {asset_id}")

        if metadata_item.get('method') != "POST":
            logger.info(f"Asset already exists")
            return handle_error(json.dumps({'message': 'Asset already exists'}), 200)
        item = {
            'AssetId': asset_id,
            'AssetName': metadata_item.get('assetname'),
            'Type': metadata_item.get('type'),
            'Location': metadata_item.get('location'),
            'AssetStatus': metadata_item.get('assetstatus'),
            'Cost': metadata_item.get('cost'),
            'Category': metadata_item.get('category'),
            'CreatedAt': metadata_item.get('createdat'),
            'CreatedBy': metadata_item.get('createdby'),
            'LastModifiedAt': metadata_item.get('lastmodifiedat'),
            'LastModifiedBy': metadata_item.get('lastmodifiedby'),
        }

        if metadata_item.get('serialnumber'):
            item['SerialNumber'] = metadata_item.get('serialnumber')

        if metadata_item.get('expiry'):
            item['Expiry'] = metadata_item.get('expiry')

        if metadata_item.get('servicetime'):
            item['ServiceTime'] = metadata_item.get('servicetime')

        if metadata_item.get('location'):
            item['Location'] = metadata_item.get('location')
        
            

        try:
            raw_time = metadata_item.get('expiry')
            dt = datetime.datetime.strptime(raw_time, "%Y-%m-%d %H:%M:%S.%f")
            iso_format_dt = dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
            if metadata_item.get('type') == 'Digital':
                ssm_client.put_parameter(
                    Name=f"/assets/{asset_id}/key",
                    Value=metadata_item.get('encryptedkey'),
                    Type='SecureString'
                )
            response = ddb_assets_resource.put_item(
                Item=item   
            )
        except Exception as e:
            logger.error(f"Error: {str(e)}")
            return handle_error(str(e), 500)


    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return handle_error(str(e), 500)

def get_comments_by_id(event , user_details):
    try:
        logger.info(f"Fetching comments")
        query_params = event.get('queryStringParameters')
        path_params = event.get('pathParameters')

        if not query_params or not path_params:
            logger.error(f"path parameters or query string parameters not found")
            return handle_error(f"path parameters or query string parameters not found", 400)
        if 'get-by' not in query_params or 'id' not in path_params:
            logger.warning(f"query string parameter or path parameter missing")
            return handle_error(json.dumps({'message': 'query string parameter or path parameter missing'}), 400)
        
        get_by = query_params.get('get-by' , '')

        if get_by == 'asset-id':
            asset_id = path_params.get('id')
            asset = ddb_assets_resource.get_item(Key={'AssetId': asset_id}).get('Item')

            if not asset:
                logger.warning(f"Asset does not exist")
                return handle_error(json.dumps({'message': 'Asset does not exist'}), 400)

            comments = ddb_comments_resource.query(
                IndexName = 'AssetId-index',
                KeyConditionExpression = "AssetId = :a_id",
                ProjectionExpression = 'CommentId , #cmnt , CreatedBy',
                ExpressionAttributeNames = {
                    '#cmnt': 'Comment'
                },
                ExpressionAttributeValues = {
                    ':a_id' : asset_id
                },
                ScanIndexForward=False
            ).get('Items', [])

            logger.info(f"Comments fetched successfully: {comments}")
            return {
                "statusCode" : 200,
                "body" : json.dumps({
                    "Response" : comments
                })
            }
        elif get_by == 'comment-id':
            comment_id = path_params.get('id' , '')
            if not comment_id:
                logger.error(f"comment not found" , 400)
                return handle_error(f"comment not found" , 400)

            comment = ddb_comments_resource.get_item(Key={'CommentId': comment_id}).get('Item')

            if not comment:
                logger.error(f"comment not found", 400)
                return handle_error(f"comment not found", 400)

            return {
                "statusCode" : 200,
                "body" : json.dumps({
                    "Response" : comment
                })
            }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return handle_error(str(e), 500)

def create_comment(event, user_details):
    try:
        if user_details.get('role') not in ['Admin' , 'Manager']:
            logger.error(f"Unauthorized. Users cannot make comments")
            return handle_error(f"Unauthorized. Users cannot make comments" , 400)

        path_params = event.get('pathParameters' , {})
        
        if not path_params:
            logger.error(f"path parameters not found")
            return handle_error(f"path parameters not found" , 400)

        id = path_params.get('id' , None)

        if not id:
            logger.error(f"id not found in path parameters")
            return handle_error(f"id not found in path parameters" , 400)

        body = json.loads(event.get('body' , {}))

        asset = ddb_assets_resource.get_item(
            Key = {
                'AssetId' : id
            }
        ).get('Item')

        if not asset:
            logger.error("Asset not found" , 400)
            return handle_error(f"asset not found" , 400)

        ddb_comments_resource.put_item(
            Item = {
                'CommentId' : str(uuid.uuid4())[:16],
                'AssetId' : id,
                'Comment' : body.get('Comment'),
                'CreatedBy' : user_details.get('username'),
                'CreatedAt' : str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
            }
        )
        return {
            "statusCode" : 200,
            "body" : json.dumps({
                "Response" : "Comment created successfully"
            })
        }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return handle_error(str(e), 500)

def update_comment(event, user_details):
    try:
        if user_details.get('role') not in ['Admin' , 'Manager']:
            logger.error(f"Unauthorized. Users cannot update comments")
            return handle_error(f"Unauthorized. Users cannot update comments", 400) 
        path_params = event.get('pathParameters' , {})
        
        if not path_params:
            logger.error(f"path parameters not found")
            return handle_error(f"path parameters not found" , 400)

        id = path_params.get('id' , None)

        if not id:
            logger.error(f"id not found in path parameters")
            return handle_error(f"id not found in path parameters" , 400)

        body = json.loads(event.get('body', {}))
        if not body:
            logger.error(f"body not found")
            return handle_error(f"body not found", 400)
        
        message = body.get('Comment', None)
        if not message:
            logger.error(f"message not found")
            return handle_error(f"message not found", 400)

        comment = ddb_comments_resource.get_item(
            Key = {
                'CommentId' : id
            }
        ).get('Item')

        if not comment:
            logger.error("Comment not found", 400)
            return handle_error(f"Comment not found", 400)

        if comment.get('CreatedBy') != user_details.get('username'):
            logger.error(f"Comment not created by {user_details.get('username')}")
            return handle_error(f"Comment not created by {user_details.get('username')}", 400)

        ddb_comments_resource.update_item(
            Key = {
                'CommentId' : id
            },
            UpdateExpression = "SET #cmnt = :comment , LastModifiedBy = :lmb , LastModifiedAt = :lma",
            ExpressionAttributeNames = {
                '#cmnt': 'Comment'
            },
            ExpressionAttributeValues = {
                ':comment' : body.get('Comment'),
                ':lmb' : user_details.get('username'),
                ':lma' : str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
            }
        )
        return {
            "statusCode" : 200,
            "body" : json.dumps({
                "Response" : "Comment updated successfully"
            })
        }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return handle_error(str(e), 500)

def delete_comment(event, user_details):
    try:
        if user_details.get('role') not in ['Admin' , 'Manager']:
            logger.error(f"Unauthorized. Users cannot delete comments")
            return handle_error(f"Unauthorized. Users cannot delete comments", 400)
        path_params = event.get('pathParameters' , {})
        
        if not path_params:
            logger.error(f"path parameters not found")
            return handle_error(f"path parameters not found" , 400)

        id = path_params.get('id' , None)

        if not id:
            logger.error(f"id not found in path parameters")
            return handle_error(f"id not found in path parameters" , 400)

        comment = ddb_comments_resource.get_item(
            Key = {
                'CommentId' : id
            }
        )

        if 'Item' not in comment:
            logger.error("Comment not found")
            return handle_error(f"Comment not found", 400)
        comment = comment.get('Item')

        ddb_comments_resource.delete_item(
            Key = {
                'CommentId' : id
            }
        )

        return {
            "statusCode" : 200,
            "body" : json.dumps({
                "Response" : "Comment deleted successfully"
            })
        }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return handle_error(str(e), 500)

def move_s3_objects(source_bucket , destination_bucket , prefix):
    try:
        paginator = s3_client.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=source_bucket,Prefix=prefix):
            for obj in page.get('Contents', []):
                source_key = obj['Key']
                destination_key = source_key
                s3_client.copy_object(
                    Bucket=destination_bucket,
                    CopySource={'Bucket': source_bucket, 'Key': source_key},
                    Key=destination_key
                )
                s3_client.delete_object(Bucket=source_bucket, Key=source_key)
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return handle_error(str(e), 500)

def lambda_handler(event, context):
    
    try:
        print(event)
        if 'Records' in event:
            record = event['Records'][0]
            print('triggered by s3')
            print(record)

            if record.get('eventName') == 'ObjectCreated:Put':
                print("adding details to dynamodb...")
                try:
                    return ddb_put(record)
                except Exception as e:
                    logger.error(f"Error: {str(e)}")
                    print("couldnt add details to ddb")
            return {
                "statusCode" : 200,
                "body" : json.dumps({
                    "Response" : {
                        "message" : "could not add details to DB",
                        "record": record
                    }
                })
            }
            
        else:
            body = event.get('body', None)
            logger.info(f"Request body: {body}")
            if body:
                body = json.loads(body)
                # print(body)
                invalid_params = ['CreatedBy' , 'CreatedAt' , 'LastModifiedBy' , 'LastModifiedAt']

                for param in invalid_params:
                    if param in body:
                        return {
                            'statusCode' : 400,
                            'body' : json.dumps({
                                'Response' : f'Invalid parameter: {param}'
                            })
                        }

            path_params = event.get("pathParameters")
            # print(path_params)
            path = event.get('path')
            method = event.get('httpMethod')
            # print(method)



            token_details=event['requestContext']['authorizer']['claims']
            user_details={
                'username': token_details.get('cognito:username'),
                'role': token_details.get('custom:role', 'unknown'),
                'email': token_details.get('email', 'unknown')
            }
            logger.info(f"Request from user {user_details['username']} with role {user_details['role']}")

            response=ddb_users_resource.get_item(Key={'UserName': user_details['username']},ProjectionExpression='RoleName,UserStatus').get('Item')
            if response== None or response.get('UserStatus')=='Inactive':
                return handle_response('Accessing User not found', 404)

            user_details['role']=response.get('RoleName')

            if path_params: 
                print(path_params.get('id'))
                if path.startswith('/assets'):
                    if (event['resource']=='/assets/{id}' and method== 'GET'):
                        print("getting asset details by id")
                        return get_asset_by_id(event, user_details)
                    elif (event['resource']=='/assets/{id}' and method== 'PUT'):
                        logger.info("updating asset details by id. Asset PUT call")
                        body = json.loads(event['body'])
                        return update_asset(path_params.get('id'), body, event, user_details)
                    elif (event['resource']=='/assets/{id}' and method== 'DELETE'):
                        return delete_asset(path_params.get('id'),event, user_details)  

                #for assignment table
                elif path.startswith('/assignment'):
                    if event.get('resource')=='/assignment/{id}':
                        if method=='GET':
                            return get_assignment_by_id(event , user_details) 

                elif path.startswith('/comments'):
                    if event.get('resource') == '/comments/{id}':
                        if method == 'GET':
                            return get_comments_by_id(event, user_details)
                        elif method == 'POST':
                            return create_comment(event, user_details)
                        elif method == 'PUT':
                            return update_comment(event, user_details)
                        elif method == 'DELETE':
                            return delete_comment(event, user_details)
                        
            

            else:
                if (event['resource']=='/assets' and method== 'POST'):
                    return register_asset(event, user_details)
                elif (event['resource']=='/assets' and method== 'GET'):
                    return get_assets(event , user_details)
                elif event.get('resource')=='/assignment':
                    if method=='GET':
                        return get_all_assignments(user_details)
                    elif method=='POST':
                        body = json.loads(event['body'])
                        return create_assignment(event,body, user_details)  
                else:
                    return handle_error(json.dumps({'error': 'Resource not found'}) , 404)

    except Exception as e:
        return handle_error(str(e) , 500)

        