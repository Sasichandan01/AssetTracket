import json
import os
import boto3
import datetime
import uuid
import logging
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

ddb_groups_resource = boto3.resource('dynamodb').Table(os.environ.get('GROUPS_TABLE_NAME'))
ddb_users_resource = boto3.resource('dynamodb').Table(os.environ.get('USERS_TABLE_NAME'))
ddb_assignment_resource = boto3.resource('dynamodb').Table(os.environ.get('ASSIGNMENT_TABLE_NAME'))
ddb_assets_resource = boto3.resource('dynamodb').Table(os.environ.get('ASSETS_TABLE_NAME'))
dynamodb = boto3.client('dynamodb')

def handle_error(message, status=500):
    """
    Handles error responses by logging the error and returning a formatted response.
    
    Args:
        message (str): The error message to be logged and returned.
        status (int, optional): HTTP status code. Defaults to 500.
    
    Returns:
        dict: A dictionary containing the status code and error message.
    """
    logger.error(message)
    return {'statusCode': status, 'body': json.dumps(message)}

def get_groups(event , user_details):
    """
    Fetches all groups

    This function is used to fetch all the groups that are there in the system
    Args:
        event(dict): Request event object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or requested object)
                - 'groups' (list): list of groups
                - 'lastKey' (dict): last response object returned, for pagination

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Fetching groups")
    try:
        
        limit = 2
        last_evaluated_key = None
        qsp=event.get('queryStringParameters', {})
        print(qsp)


        groups = []
        if user_details.get('role') == 'User':
            user = ddb_users_resource.get_item(Key={'UserName': user_details.get('username')})
            if 'Item' not in user:
                return handle_error("User not found", status=404)
            if user.get('UserStatus') == 'Inactive':
                return handle_error("User is inactive", status=400)
            if user.get('Item'):
                user_groups = user.get('Item', {}).get('Groups', [])
                if user_groups:
                    logger.debug(f"User groups: {user_groups}")
                    for group_id in user_groups:

                        group = ddb_groups_resource.get_item(Key={'GroupId': group_id})
                        if group.get('Item'):
                            groups.append(group.get('Item'))
        elif user_details.get('role') in ['Admin' , 'Manager']:
            response = ddb_groups_resource.scan()
            groups = response.get('Items' , []) 
        
        logger.debug(f"Groups: {groups}")
                
        return {
            "statusCode": 200,
            "body": json.dumps({
                "Response" : groups
            })
        }
    except ClientError as e:
        logger.error(f"Error fetching groups: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": str(e)
            })
        }
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return handle_error("Unexpected error", status=500)

def get_group_by_id(event , user_details):
    """
    Fetches all groups

    This function is used to fetch groups by IDs
    Args:
        event(dict): Request event object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or requested object)
                - group (dict) : request group object

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Fetching group by ID")
    try:
        path_parameters = event.get("pathParameters", {})

        if not path_parameters:
            logger.error("Path parameters not provided")
            return handle_error("Path parameters not provided", status=400)
        
        id = path_parameters.get("id", "")
        if not id:
            logger.error("Group ID not provided")
            return handle_error("Group ID not provided", status=400)

        group = ddb_groups_resource.get_item(Key={
            "GroupId": id
        })

        if user_details.get('role') in ['User'] and user_details.get('username') not in group.get("Item", {}).get("Users", {}):
            logger.warning("Unauthorized. User cannot view this group")
            return handle_error("Unauthorized. User cannot view this group", status=403)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "Response": group.get("Item", {})
            })
        }
    except ClientError as e:
        logger.error(f"Error fetching group: {e}",403)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return handle_error("Unexpected error", status=500)

def create_group(event , user_details):
    """
    Creates a new group

    This function is used to create a new group.
    Args:
        event(dict): Request event object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or database response object)

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Creating group")
    try:
        if user_details.get('role') in ['Admin', 'Manager']:
            body = json.loads(event.get("body", {}))
            if not body:
                return {
                    "statusCode" : 200,
                    "body" : json.dumps({
                        "Response" : "Group created successfully"
                    })
                }
            group_name = body.get("GroupName", "")
            users = body.get("Users", [])
            created_time = datetime.datetime.now()
            offset = datetime.timedelta(hours=5, minutes=30)
            created_time = str(created_time + offset)
            id = f"GRP_{str(uuid.uuid4())[:12]}"
            type = body.get("Type", "")
            lead = body.get("Lead", "")

            if type == 'Team':
                if lead == '':
                    return handle_error("Lead cannot be empty", status=400)
                    
                lead_user = ddb_users_resource.get_item(
                    Key = {
                        "UserName" : lead
                    }
                ).get('Item' , {})

                if not lead_user:
                    return handle_error("Lead not found", status=404)

                if lead_user.get('UserStatus') == 'Inactive':
                    return handle_error("Lead is inactive", status=400)

                if lead_user.get('Type') == 'External':
                    return handle_error("External users cannot be team leads" , status=400)

                if lead not in users:
                    users.append(lead)

            logger.debug(f"Group name: {group_name}")

            users_map = {}
            not_in_sys = ""

            for user in users:
                sys_user = ddb_users_resource.get_item(
                    Key={
                        "UserName" :  user
                    }
                ).get("Item", {})
                if  sys_user.get('UserStatus','') != 'Active':
                    not_in_sys = not_in_sys + user + ", "
                    continue
                users_map[user] = {"AddedAt" : created_time , "AddedBy" : user_details.get('username')}
                group_list = sys_user.get("Groups", [])
                group_list.append(id)
                ddb_users_resource.update_item(
                    Key = {
                        "UserName" : user
                    },
                    UpdateExpression="SET #groups = :groups",
                    ExpressionAttributeValues={
                        ":groups": group_list
                    },
                    ExpressionAttributeNames={
                        "#groups" : "Groups"
                    }
                )

            group = {
                "GroupId": id,
                "GroupName":  group_name,
                "Type" : type,
                "Users":users_map,
                "CreatedAt": created_time,
                "CreatedBy": user_details.get('username')
            }

            if type == 'Team':
                group['Lead'] = lead

            res = ddb_groups_resource.put_item(Item=group)
            logger.debug(f"Group creation response: {res}")
            message = f"Group created successfully. {not_in_sys} are not registered users" if not_in_sys else "Group created successfully"
            return {
                "statusCode": 200,
                "body": json.dumps({
                    "Response" : {
                        "message" : message,
                        
                    }
                })
            }
        else:
            logger.warning("Unauthorized. User cannot create groups")
            return handle_error("Unauthorized. User cannot create groups", status=403)
    except ClientError as e:
        logger.error(f"Error creating group: {e}")
        return handle_error(str(e), status=500)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return handle_error("Unexpected error", status=500)

def update_group(event , context , user_details):
    """
    Updates a pre-existing group

    This function is used to update an already existing group. Changes can be made to the Group Name or to the list of Users. Can add new Users or remove already existing ones
    Args:
        event(dict): Request event object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or database response object)

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Updating group")
    try:
        if user_details.get('role') not in ['Admin', 'Manager']:
            group = ddb_groups_resource.get_item(Key={
                "GroupId": id
            }).get("Item", {})

            if not group:
                logger.warning("Group not found")
                return handle_error("Group not found", status=404)
            if group.get('Type') == 'Team' and user_details.get('username') != group.get('Lead'):
                logger.warning("Unauthorized. User cannot update groups")
                return handle_error("Unauthorized. User cannot update groups")

        body = json.loads(event.get("body", {}))
        id = event.get("pathParameters", {}).get('id')

        if not id:
            logger.error("Group ID not provided")
            return handle_error("Group ID is required")

        groupName = body.get("GroupName", "")
        user_list = body.get("Users", [])
        query_params = event.get("queryStringParameters", {})
        offset = datetime.timedelta(hours=5, minutes=30)
        modifiedAt = str(datetime.datetime.now() + offset)

        old_group = ddb_groups_resource.get_item(Key={
            "GroupId": id
        }).get("Item", {})

        if not old_group:
            logger.warning(f"Group not found")
            return handle_error("Group not found", status=404)

        old_users = old_group.get('Users')
            
        new_list = {}
        not_in_sys = ""
        not_in_list = ""
        removed_users = ""
        logger.debug(f"List of old users : {old_users}")
        logger.debug(f"New list of users for updation")

        type = body.get('Type' , '')
        lead = body.get('Lead' , '')
        if type == 'Team':
            if lead == '':
                logger.error("Lead cannot be empty")
                return handle_error("Lead cannot be empty", status=400)
            if old_group.get('Type') == 'Group':
                return handle_error("Cannot change group type", status=400)

        if lead:
            lead_user = ddb_users_resource.get_item(
                Key = {
                    "UserName" : lead
                }
            ).get('Item', {})

            if not lead_user:
                return handle_error("Lead not found", status=404)

            if not lead_user.get('UserStatus') == 'Active':
                return handle_error("Lead is inactive", status=400)

            if lead_user.get('Type') == 'External':
                return handle_error('External Users cannot be team leads' , status=400)
        

        if query_params and query_params.get("operation") == "remove-users":
            logger.info(f"Removing users")
            for user in user_list:
                sys_user = ddb_users_resource.get_item(Key={
                    "UserName": user
                }).get("Item", {})
                if sys_user.get('UserStatus' , '') != 'Active':
                    not_in_sys = not_in_sys + user + ", "
                    continue
                if user in old_users:
                    if old_group.get('Type') == 'Team' and old_group.get('Lead') == user and user == old_group.get('Lead'):
                        return handle_error("Lead cannot be removed", status=400) 
                    removed_users = removed_users + user + ", "
                    old_users.pop(user)
                    group_list = sys_user.get('Groups' , [])
                    if len(group_list):
                        group_list.remove(id)
                        ddb_users_resource.update_item(
                            Key = {
                                "UserName" : user
                            },
                            UpdateExpression="SET #groups = :groups",
                            ExpressionAttributeValues={
                                ":groups": group_list
                            },
                            ExpressionAttributeNames={
                                "#groups" : "Groups"
                            }
                        )
                else:
                    not_in_list = not_in_list + user + ", "

            group_updates = {}
            if groupName:
                group_updates['GroupName'] = {"Value" : groupName , "Action" : "PUT"}
            if type:
                group_updates['Type'] = {"Value" : type , "Action" : "PUT"}
            if lead:
                group_updates['Lead'] = {"Value" : lead , "Action" : "PUT"}
            group_updates['Users'] = {"Value" : old_users , "Action" : "PUT"}

            res = ddb_groups_resource.update_item(
                Key={
                    "GroupId": id
                },
                AttributeUpdates = group_updates
            )

            logger.debug(f"Group updation response: {res}")

            message = f"{removed_users} removed successfully. {not_in_sys} are not registered users, {not_in_list} are not members for the group" if not_in_sys or not_in_list else "Users removed successfully"
            return {
                "statusCode": 200,
                "body": json.dumps({
                    "Response": message
                })
            }
            
        elif query_params and query_params.get('operation') == 'add-users':
            logger.info(f"Adding users")
            group_updates = {}

            if groupName:
                group_updates["GroupName"] = {"Value" : groupName , "Action" : "PUT"}

            if lead != '':
                if lead not in user_list:
                    user_list.append(lead)
                group_updates['Lead'] = {"Value" : lead , "Action" : "PUT"}

            if user_list:
                for user in user_list:
                    if user in old_users:
                        continue
                    sys_user = ddb_users_resource.get_item(Key={
                        "UserName": user
                    }).get("Item", {})
                    if sys_user.get('UserStatus') != 'Active':
                        logger.info(f"{sys_user.get('UserStatus')}")
                        not_in_sys = not_in_sys + user + ", "
                        continue
                    old_users[user] = {"AddedAt" : modifiedAt, "AddedBy" : user_details.get('username')}
                    group_list = sys_user.get('Groups' , [])
                    group_list.append(id)
                    logger.info(f"updating list of groups in Users")
                    ddb_updated = ddb_users_resource.update_item(
                        Key={
                            "UserName": user
                        }, 
                        UpdateExpression="SET #groups = :groups", 
                        ExpressionAttributeValues={
                            ":groups": group_list
                        },
                        ExpressionAttributeNames={
                            "#groups": "Groups"
                        }
                    )
                    logger.debug(f"User update response: {ddb_updated}")
                group_updates["Users"] = {"Value" : old_users , "Action" : "PUT"}
            
            group_updates["LastModifiedAt"] = {"Value" : modifiedAt , "Action" : "PUT"}
            group_updates["LastModifiedBy"] = {"Value" : user_details.get('username') , "Action" : "PUT"}
            

            res = ddb_groups_resource.update_item(Key={
                "GroupId": id
            }, AttributeUpdates=group_updates)

            logger.debug(f"Group updation response: {res}")

            message = f"group updated successfully. {not_in_sys} are not registered users" if not_in_sys else "group updated successfully"

            return {
                "statusCode": 200,
                "body": json.dumps({
                    "Response": message
                })
            }  
    except ClientError as e:
        logger.error(f"Error updating group: {e}")
        return handle_error(str(e), status=500)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return handle_error("Unexpected error", status=500)

def delete_group(event, user_details):
    """
    Deletes a group

    This function is used to delete a group
    Args:
        event(dict): Request event object
        user_detaisl(dict): details of the user(username and custom:role) from the decoded jwt tokemn

    Returns:
        dict: A dictionary with keys:
            - 'statusCode' (str): an http status code
            - 'body' (str): stringified dictinary containing response(Error response or database response object)

    Raises:
        ValueError: If the token format is invalid (does not contain exactly two periods).
        ClientError: If any DynamoDB call fails
    """
    logger.info(f"Deleting group")
    try:
        if user_details.get('role') not in ['Admin', 'Manager']:
            logger.warning("Unauthorized. User cannot delete groups")
            return handle_error("Unauthorized. User cannot delete groups")

        path_parameters = event.get("pathParameters", {})

        if not path_parameters:
            logger.warning("Path parameters not provided")
            return handle_error("Path parameters not provided", status=400)
        id = path_parameters.get('id' , '')
        if not id:
            logger.warning("Group ID not provided")
            return handle_error("Group ID not provided", status=400)

        group = ddb_groups_resource.get_item(
            Key = {
                "GroupId" : id
            }
        )

        if 'Item' not in group:
            logger.error(f"Group not found")
            return handle_error(f"Group not found" , 400)
        
        group = group.get('Item')

        logger.debug(f"Group details: {group}")

        user_map = group.get('Users' , {})

        for user_name in user_map.keys():
            user = ddb_users_resource.get_item(Key={
                "UserName": user_name
            }).get("Item", {})

            group_list = user.get('Groups', [])
            if len(group_list) and id in group_list:
                group_list.remove(id)
                logger.info(f"updating list of groups in Users")
                ddb_users_resource.update_item(
                    Key = {
                        "UserName" : user_name
                    },
                    UpdateExpression="SET #groups = :groups",
                    ExpressionAttributeValues={
                        ":groups": group_list
                    },
                    ExpressionAttributeNames={
                        "#groups" : "Groups"
                    }
                )

        logger.info(f"Deleting group")
        res = ddb_groups_resource.delete_item(Key={
            "GroupId": id
        })

        logger.debug(f"Group deletion response: {res}")

        assignments = ddb_assignment_resource.scan(
            ProjectionExpression="AssignmentId, GroupId",
        )

        if 'Items' in assignments:
            assignments = assignments.get('Items', [])
            for assignment in assignments:
                if assignment.get('AssignmentStatus') in ['Inactive'] or assignment.get('HolderId', {}) != id:
                    continue
                logger.info(f"Updating status of assets that were assigned to the group")
                ddb_assignment_resource.update_item(
                    Key={
                        "AssignmentId": assignment.get("AssignmentId", {})
                    },
                    UpdateExpression="SET LastModifiedAt = :modTime , LastModifiedBy = :modBy , AssignmentStatus = :new_status",
                    ExpressionAttributeValues={
                        ":modTime": str(datetime.datetime.now()),
                        ":new_status": "Inactive",
                        ":modBy" : user_details.get('username')
                    }
                )
                ddb_assets_resource.update_item(
                    Key={
                        "AssetId": assignment.get("AssetId", {})
                    },
                    UpdateExpression="SET LastModifiedAt = :modTime , LastModifiedBy = :modBy , AssetStatus = :new_status",
                    ExpressionAttributeValues={
                        ":modTime": str(datetime.datetime.now()),
                        ":new_status": "Unassigned",
                        ":modBy" : user_details.get('username')
                    }
                )

        return {
            "statusCode": 200,
            "body": json.dumps({
                "Response": "group deleted successfully"
            })
        }
    except ClientError as e:
        logger.error(f"Error deleting group: {e}")
        return handle_error(str(e) , 400)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return handle_error("Unexpected error", 500)

def lambda_handler(event, context):
    try:
        print(event)

        token_details=event['requestContext']['authorizer']['claims']
        user_details={
            'username': token_details.get('cognito:username'),
            'role': token_details.get('custom:role', 'unknown'),
            'email': token_details.get('email', 'unknown')
        }
        logger.info(f"Request from user {user_details['username']} with role {user_details['role']}")

        response=ddb_users_resource.get_item(Key={'UserName': user_details['username']},ProjectionExpression='RoleName,UserStatus').get('Item')
        if response== None or response.get('UserStatus')=='Inactive':
            return handle_response('Accessing User not found', 404)

        user_details['role']=response.get('RoleName')

        path_parameters = event.get("pathParameters", {})
        method = event.get("httpMethod", "")

        invalid_parameters = ["CreatedBy" , "CreatedAt" , "LastModifiedBy" , "LastModifiedAt"]

        body = event.get('body' , {})
        if body:
            body = json.loads(body)

            for param in invalid_parameters:
                if param in body:
                    logger.warning(f"Invalid parameter {param}")
                    return handle_error(f"Invalid parameter {param}", status=400)
                    

       
        
        if not path_parameters:
            if method == "GET":
                return get_groups(event , user_details)
            elif method == "POST":
                return create_group(event , user_details)
        else:
            if method == "GET":
                return get_group_by_id(event , user_details)
            elif method == "PUT":
                return update_group(event , context , user_details)
            elif method == "DELETE":
                return delete_group(event, user_details)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return handle_error("Unexpected error", status=500)
